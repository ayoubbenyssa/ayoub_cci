import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/user.dart';
import 'package:medz/user/myprofile.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:intl/intl.dart';

class HeaderMenuDrawer extends StatefulWidget {
  HeaderMenuDrawer(this.user, this.chng, this.lat, this.lng, {Key key})
      : super(key: key);
  User user;
  var chng;
  var lat;
  var lng;

  @override
  _HeaderMenuState createState() => new _HeaderMenuState();
}

class _HeaderMenuState extends State<HeaderMenuDrawer> {
  // RoutesFunctions routesFunctions = new RoutesFunctions();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Widget avatar(image) => GestureDetector(
        onTap: () {
          print("ddd");

          Navigator.push(context, new PageRouteBuilder(pageBuilder:
              (BuildContext context, Animation<double> _,
                  Animation<double> __) {
            return Scaffold(
                appBar: AppBar(
                  title: Text(
                    toBeginningOfSentenceCase(widget.user.firstname) +
                        " " +
                        widget.user.fullname.toUpperCase(),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                body: new MyProfile(widget.user, false, true, widget.lat,
                    widget.lng, [], null, widget.chng));
          }));
        },
        child: new Container(
            width: 65.0,
            height: 65.0,
            child: new Center(
                child: new ClipOval(
                    child: image == null
                        ? new Image.asset("images/logo.png",
                            width: 65.0, height: 65.0, fit: BoxFit.cover)
                        : new Image.network(image,
                            width: 65.0, height: 65.0, fit: BoxFit.cover)))));

    Widget head() =>
        /* new StreamBuilder<DocumentSnapshot>(
        stream: Firestore.instance
            .collection('users')
            .document(widget.user.id)
            .snapshots(),
        builder:
            (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (!snapshot.hasData)
            return new Container(
                alignment: FractionalOffset.center,
                child: new CircularProgressIndicator());

          widget.user = new User.fromDoc(snapshot.data);
*/
        new Container(
            // padding: new EdgeInsets.only(left: 16.0),
            child: new Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
              // new Container(height: 8.0),
              widget.user == null ? new Container() : avatar(widget.user.image),
              new Container(height: 8.0),
              new Text(
                  toBeginningOfSentenceCase(widget.user.firstname.toString()) +
                      " " +
                      widget.user.fullname.toUpperCase(),
                  style: new TextStyle(
                      // color: Fonts.color_app_fonc,
                      fontWeight: FontWeight.w700)),
              new Container(height: 8.0),
              new Text(widget.user.email.toString(),
                  style: new TextStyle(
                      // color: Fonts.color_app_fonc,
                      ))
            ]));

    return new GestureDetector(
        onTap: () =>
            null /* Routes.goto(context,"profile", id: widget.user.id),*/,
        // Routes.gotoparams2("profile", context, widget.user,widget.user.id),
        child: new Container(

            //decoration: Widgets.back,
            child: new Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
              Container(
                height: 16,
              ),
              head(),
              new Container(
                height: 16.0,
              ),
            ])));
  }
}
