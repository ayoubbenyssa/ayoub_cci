import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:medz/biblio_videos/BiblioThequevideos.dart';
import 'package:medz/commandes/commandes_list.dart';
import 'package:medz/communities/communities.dart';
import 'package:medz/communities/federations.dart';
import 'package:medz/filter/filter_by_region.dart';
import 'package:medz/home/conventions.dart';
import 'package:medz/home/entreprise_view.dart';
import 'package:medz/home/events.dart';
import 'package:medz/home/revuepress.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/products/products_services.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/apebi_pre.dart';
import 'package:medz/widgets/services_pre.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:medz/youtube_videos/views/youtubeList.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/annonces/annonces_tabs.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/home/opportunite.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/auth.dart';
import 'package:medz/services/routes.dart';
import 'package:medz/widgets/header_menu.dart';
import 'package:medz/home/publications.dart';
import 'package:medz/widgets/invite_friends.dart';
import 'package:medz/services/app_services.dart';

var API_KEY = "AIzaSyDCB1z3cOQuIaf9LxLI6adVYjsSJC5TpDU";

class Menu extends StatefulWidget {
  Menu(
      this.user,
      this.id,
      this.auth,
      this.onSignedIn,
      this.lat,
      this.lng,
      this.list_partner,
      this.analytics,
      this.gotocompanies,
      this.index,
      this.ctrl,
      this.onLocaleChange);

  var auth;
  var onSignedIn;
  User user;
  String id;
  var lat;
  var lng;
  List list_partner;
  var analytics;
  var gotocompanies;
  var func;
  int index = 0;
  var onLocaleChange;
  var ctrl;

  @override
  _MenuState createState() => new _MenuState();
}

class _MenuState extends State<Menu> {
  Auth auth = new Auth();
  var colo1 = Fonts.col_app_fonn;
  var colo2 = Fonts.col_app_fonn;
  ParseServer parse_s = new ParseServer();

  /*Future<User> getcurrentuser() async {
    FirebaseUser a = await FirebaseAuth.instance.currentUser();
    id = a.uid;
    DocumentSnapshot snap =
    await Firestore.instance.collection('users').document(a.uid).get();
    setState(() {
      widget.user = new User.fromDocument(snap);
    });
    return new User.fromDocument(snap);
  }*/

  /**
   *
   * Map
   */

  /**
   *
   *
   * Map code
   *
   *
   *
   */

  bool en = false;
  bool ar = false;

  Widget AR() => ScopedModelDescendant<AppModel1>(
      builder: (context, child, model) => InkWell(
          //elevation: 18.0,
          onTap: () {
            print("1234567");
            print(model.locale);
            if (model.locale == "en") {
              setState(() {
                ar = true;
                en = false;
              });
              model.changeDirection();
              widget.onLocaleChange(
                  Locale(model.locale, ""), model.textDirection);
            }
          },
          child: new Text(
            "العربية", //
            style: new TextStyle(
                color: ar == false ? Colors.grey[800] : Fonts.col_app,
                fontSize: 13.0),
          )));

  Widget EN() => ScopedModelDescendant<AppModel1>(
      builder: (context, child, model) => InkWell(
          //elevation: 18.0,
          onTap: () {
            if (model.locale == "ar") {
              setState(() {
                ar = false;
                en = true;
              });
              model.changeDirection();
              widget.onLocaleChange(
                  Locale(model.locale, ""), model.textDirection);
            }
          },
          child: new Text(
            "Français",
            style: new TextStyle(

                ///  fontFamily: "",
                color: en == false ? Colors.grey[800] : Fonts.col_app,
                fontSize: 13.0),
          )));

/*

Navigator.push(context,
            new MaterialPageRoute<String>(builder: (BuildContext context) {
              return new Cities();
            }));
 */

  String verify;

  getUser(id) async {
    var a = await parse_s
        .getparse('users?where={"objectId":"$id"}&include=respons');
    if (!this.mounted) return;
    print(a);

    setState(() {
      verify = a["results"][0]["verify"].toString();
      print(verify);
    });
  }

  @override
  void initState() {
    //getcurrentuser();

    super.initState();

    getUser(widget.user.id);
  }

  tap(a) {
    if (a == "a") {
      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new Presentation();
      }));
    } else if (a == "b") {
      //ServicesPre
      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new ServicesPre(
            widget.lat, widget.lng, widget.user, widget.onLocaleChange);
      }));
    } else if (a == "c") {
      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new CommunitiesCGEM(null, null, [], false, false, widget.lat,
            widget.lng, widget.onLocaleChange,
            user: widget.user);
      }));
    } else if (a == "e") {
      Navigator.push(
        context,
        new PageRouteBuilder(
          pageBuilder: (BuildContext context, Animation<double> _,
              Animation<double> __) {
            return RegionStream(widget.user, widget.lat, widget.lng, [], null,
                widget.onLocaleChange, false);
          },
        ),
      );
    } else {
      //FedCGEM

      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new FedCGEM(
          null,
          null,
          [],
          false,
          false,
          widget.lat,
          widget.lng,
          widget.onLocaleChange,
          user: widget.user,
        );
      }));
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget lang = new ListTile(
      dense: true,
      trailing: Container(
        width: MediaQuery.of(context).size.width * 0.25,
        child: Row(
          children: <Widget>[
            EN(),
            Container(
              width: 6,
            ),
            AR()
          ],
        ),
      ),
      leading: new Image.asset(
        "images/language.png",
        color: colo1,
        width: 30.0,
        height: 30.0,
      ),
      title: new Text(LinkomTexts.of(context).language()),
    );

    _showDialog1() async {
      return await showDialog(
          context: context,
          child: new AlertDialog(
              contentPadding: const EdgeInsets.all(16.0),
              content: Container(
                  height: 160,
                  child: Column(children: <Widget>[
                    Text(LinkomTexts.of(context).option()),
                  ]))));
    }

    Widget notif = new ListTile(
      dense: true,
      onTap: () {
        // Routes.goto(context,"login");
      },
      leading: new Icon(Icons.notifications, color: colo1),
      title: new Text(LinkomTexts.of(context).not(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget lst(img, text, tp, w, h) => ListTile(
          dense: true,
          //contentPadding: EdgeInsets.only(left: 68, right: 60),
          onTap: () {
            if (text == LinkomTexts.of(context).CGEM()) {
              tap("a");
            } else if (text == LinkomTexts.of(context).services()) {
              tap("b");
            } else if (text == LinkomTexts.of(context).comms()) {
              tap("c");
            } else if (text == "CGEM-Régions") {
              tap("e");
            } else {
              tap("d");
            }
          },
          /* leading: new Image.asset(
        img,
        color: colo1,
        width: w,
        height: h,
      ),*/
          title: new Text(text,
              style: new TextStyle(
                  color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
        );

    Widget powered = Container(
        padding: EdgeInsets.all(12.0),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          new RichText(
            text: new TextSpan(
              text: LinkomTexts.of(context).po() + " ",
              style: new TextStyle(color: Colors.grey[700]),
              children: <TextSpan>[
                /* new TextSpan(
                  recognizer: new TapGestureRecognizer()
                    ..onTap = () => Navigator.push(context,
                        new MaterialPageRoute<String>(builder: (BuildContext context) {
                          return   new WebviewScaffold(
                            url: "http://www.linkommunity.com/",
                            appBar: new AppBar(
                              title: new Text("Linkommunity"),
                            ),
                          );
                        },
                        )),
                  text:
                  "Linkcommunity",
                  style: new TextStyle(
                      fontWeight:
                      FontWeight
                          .bold,
                      color: Colors
                          .blue[
                      600])),*/
              ],
            ),
          ),
          Padding(
              padding: EdgeInsets.only(top: 4.0),
              child: InkWell(
                child: Image.asset(
                  "images/linko.png",
                  height: 32.0,
                  width: 140.0,
                ),
                onTap: () {
                  Navigator.push(context, new MaterialPageRoute<String>(
                      builder: (BuildContext context) {
                    return new WebviewScaffold(
                      url: "http://www.linkommunity.com/",
                      appBar: new AppBar(
                        title: new Text("Linkommunity"),
                      ),
                    );
                  }));
                },
              ))
        ]));

    Widget parc = new ExpansionTile(
      initiallyExpanded: true,
      title: new ListTile(
        contentPadding: EdgeInsets.all(0),
        dense: true,

        /* Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EtudiantHome(
                              widget.user.user_id,
                              widget.user.student_id,
                              widget.user.token_user)));*/

        /* leading: new Image.asset(
          "images/pub.png",
          color: colo1,
          width: 23.0,
          height: 23.0,
        ),*/
        /* title: new Text(LinkomTexts.of(context).CGEM(),
            style: new TextStyle(
                color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),*/
      ),
      children: <Widget>[
        // lst("images/ab.png", "Absences", tap, 25.0, 25.0),
        // lst("images/calen.png", "Emploi du temps", tap, 20.0, 20.0),
      ],
    );

    /*

    CommunitiesCGEM(this.auth, this.sign, this.list_partner, this.show, this.view,{this.user})
     */
    Widget Publication = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new Publications(
              widget.lat,
              widget.lng,
              widget.user,
              widget.list_partner,
              widget.auth,
              0,
              widget.analytics,
              widget.onLocaleChange);
        }));
      },
      /* leading: new Image.asset(
        "images/pp.png",
        color: colo1,
        width: 22.0,
        height: 22.0,
      ),*/
      title: new Text(LinkomTexts.of(context).actu(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget companies = new ListTile(
      dense: true,
      onTap: () {
        // Navigator.pop(context);
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return EntrepriseStream(widget.user, widget.lat, widget.lng, [], null,
              widget.onLocaleChange);
        }));

        /*widget.index = 1;
        widget.gotocompanies(1);

        new Timer(const Duration(milliseconds: 200), () {
          widget.ctrl.animateToPage(1,
              duration: const Duration(milliseconds: 300), curve: Curves.ease);
        });*/
      },
      /* leading: new Image.asset(
        "images/visit.png",
        color: colo1,
        width: 30.0,
        height: 30.0,
      ),*/
      title: new Text("Membres",
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );
    Widget Agenda = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new Events(
              widget.lat,
              widget.lng,
              widget.user,
              widget.list_partner,
              widget.auth,
              0,
              widget.analytics,
              widget.onLocaleChange);
        }));
      },
      /*  leading: new Image.asset(
        "images/icons/appointment.png",
        color: colo1,
        width: 26.0,
        height: 26.0,
      ),*/
      title: new Text(LinkomTexts.of(context).agenda(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    //HomePageFormation
    Widget con = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new Conventions(
              widget.lat,
              widget.lng,
              widget.user,
              widget.list_partner,
              widget.analytics,
              "cgem",
              widget.onLocaleChange);
        }));
      },
      /* leading: new Image.asset(
        "images/sale.png",
        color: colo1,
        width: 30.0,
        height: 30.0,
      ),*/
      title: new Text(LinkomTexts.of(context).tarifs(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget av = new ListTile(
      dense: true,
      onTap: () {
        if (verify == "1")
          Navigator.push(context,
              new MaterialPageRoute(builder: (BuildContext context) {
            return new Conventions(
                widget.lat,
                widget.lng,
                widget.user,
                widget.list_partner,
                widget.analytics,
                "linkommunity",
                widget.onLocaleChange);
          }));
        else
          _showDialog1();
      },
      /*leading: new Image.asset(
        "images/mic.png",
        color: colo1,
        width: 30.0,
        height: 30.0,
      ),*/
      title: new Text(LinkomTexts.of(context).ava(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget opportunites = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new Opportunite(widget.lat, widget.lng, widget.user,
              widget.list_partner, widget.analytics, widget.onLocaleChange);
        }));
      },
      /* leading: new Image.asset(
        "images/icons/opportunity.png",
        color: colo1,
        width: 28.0,
        height: 28.0,
      ),*/
      title: new Text(LinkomTexts.of(context).oppo(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget cmnd = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new CommandesList(widget.lat, widget.lng, widget.user,
              widget.list_partner, widget.analytics, widget.onLocaleChange);
        }));
      },
      /* leading: new Image.asset(
        "images/order.png",
        color: colo1,
        width: 28.0,
        height: 28.0,
      ),*/
      title: new Text("1ère Commande",
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget prod = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new ProductServices(widget.lat, widget.lng, widget.user,
              widget.list_partner, widget.analytics, widget.onLocaleChange);
        }));
      },
      /*leading: new Image.asset(
        "images/icons/serv.png",
        color: colo1,
        width: 28.0,
        height: 28.0,
      ),*/
      title: new Text(LinkomTexts.of(context).prodss(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget ann = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new AnnoncesTabs(
              widget.user,
              widget.auth,
              widget.onSignedIn,
              widget.lat,
              widget.lng,
              widget.list_partner,
              0,
              widget.analytics,
              widget.onLocaleChange);
        }));
        // Routes.goto(context,"login");
      },
      /* leading: new Image.asset(
        "images/ad.png",
        color: colo1,
        width: 29.0,
        height: 29.0,
      ),*/
      title: new Text(LinkomTexts.of(context).ann(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    Widget video = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new YoutubeBody(widget.user, widget.lat, widget.lng,
              widget.list_partner, widget.analytics, widget.onLocaleChange);
        }));
      },
      /*leading: new Image.asset(
        "images/youtu.png",
        //color: colo1,
        width: 29.0,
        height: 29.0,
        color: colo1,

      ),*/
      title: new Text("CGEM TV",
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    /* Widget revue = new ListTile(
      dense: true,
      onTap: () {
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
              return new RevuePress(widget.user, widget.lat, widget.lng,
                  widget.list_partner, widget.analytics, widget.onLocaleChange);
            }));
        //RevuePress

        // Routes.goto(context,"login");
      },
      leading: new Image.asset(
        "images/icons/newspaper.png",
        color: colo1,
        width: 29.0,
        height: 29.0,
      ),
      title: new Text("Revue de presse",
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );
*/

    make_user_offline() async {
      Map<String, dynamic> map = new Map<String, dynamic>();
      map["online"] = false;
      map["last_active"] = new DateTime.now().millisecondsSinceEpoch;
      Firestore.instance
          .collection('users')
          .document(widget.user.auth_id)
          .updateData(map);

      FirebaseDatabase.instance
          .reference()
          .child("status")
          .update({widget.user.auth_id: false});

      FirebaseDatabase.instance
          .reference()
          .child("status")
          .update({widget.user.auth_id: false});
    }

    Widget share = new ListTile(
      dense: true,
      onTap: () {
        //Invitrefriends
        // Routes.goto(context,"login");
        Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new Invitrefriends();
        }));
      },
      /*leading: new Image.asset("images/ch.png",
          color: colo1, width: 25.0, height: 25.0),*/
      title: new Text(LinkomTexts.of(context).invite(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    /* Widget pro = new ListTile(
      onTap: () {
        // Routes.goto(context,"login");
        Navigator.push(context, new MaterialPageRoute(
            builder: (BuildContext context) {
              return new EditProfile(widget.auth,widget.onSignedIn);
            }));

      },
      leading: new Icon(Icons.settings, color:  colo),
      title: new Text("Mon Profil",style: new TextStyle(color: colo)),
    );*/

    ParseServer parse_s = new ParseServer();

    Widget logout = new ListTile(
      dense: true,
      onTap: () async {
        Widgets.onLoading(context);
        await make_user_offline();
        await Firestore.instance
            .collection('user_notifications')
            .document(widget.user.auth_id)
            .updateData({"send": "no"});
        var js = {
          "token": "",
        };
        await parse_s.putparse("users/" + widget.user.id, js);

        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.clear();
        prefs.setString("Slides", "yess");
        prefs.setString("cov", "cov");
        prefs.setString("homes", "homes");
        prefs.setString("con", "con");
        prefs.setString("par", "par");
        prefs.setString("pub", "pub");
        prefs.setString("shop", "shop");

        await FirebaseAuth.instance.signOut();
        Navigator.of(context, rootNavigator: true).pop('dialog');

        Routes.go_login(context, widget.auth, widget.onSignedIn,
            widget.list_partner, widget.analytics, widget.onLocaleChange);
      },
      /* leading: new Icon(Icons.exit_to_app, color: colo1),*/
      title: new Text(LinkomTexts.of(context).logout(),
          style: new TextStyle(
              color: colo2, fontSize: 15, fontWeight: FontWeight.w500)),
    );

    return Container(
        color: Fonts.col_grey.withOpacity(0.16),
        child: new ListView(
          children: <Widget>[
            widget.id.toString() == ""
                ? new Container()
                : new HeaderMenuDrawer(
                    widget.user, widget.onLocaleChange, widget.lat, widget.lng),
            //reseau,
            // messages,
            // notif,
            // revue,

            Container(
                padding: EdgeInsets.only(left: 12, right: 12),
                margin: EdgeInsets.only(top: 8, left: 12, right: 12),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    // border: new Border.all(color: Colors.grey[100], width: 1.0),
                    borderRadius: new BorderRadius.circular(12.0)),
                child: Column(children: <Widget>[
                  ///WWWWQ cmnd,
                ])),
            Container(
                padding: EdgeInsets.only(left: 12, right: 12),
                margin: EdgeInsets.only(top: 8, left: 12, right: 12),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    border: new Border.all(color: Colors.grey[100], width: 1.0),
                    borderRadius: new BorderRadius.circular(12.0)),
                child: Column(children: <Widget>[
                  Container(child: Publication),
                  Container(child: Agenda),
                  Container(child: video),
                ])),

            Container(
                padding: EdgeInsets.only(left: 12, right: 12),
                margin: EdgeInsets.only(top: 8, left: 12, right: 12),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    border: new Border.all(color: Colors.grey[100], width: 1.0),
                    borderRadius: new BorderRadius.circular(12.0)),
                child: Column(children: <Widget>[
                  companies,
                  Container(child: opportunites),
                  //ss    prod,
                  //  Container(child: con),
                ])),

            /*
                Container(child: ann),
             */

            Container(
                padding: EdgeInsets.only(left: 12, right: 12),
                margin: EdgeInsets.only(top: 8, left: 12, right: 12),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    border: new Border.all(color: Colors.grey[100], width: 1.0),
                    borderRadius: new BorderRadius.circular(12.0)),
                child: Column(children: <Widget>[
                  // Container(child: parc),
                  lst("images/morocco.png", LinkomTexts.of(context).CGEM(), tap,
                      25.0, 25.0),
                  Container(
                      child: lst("images/area-with-pins.png", "CGEM-Régions",
                          tap, 25.0, 25.0)),
                  Container(
                      child: lst("images/icons/fed.png",
                          LinkomTexts.of(context).fids(), tap, 25.0, 25.0)),
                  Container(
                      child: lst("images/icons/team.png",
                          LinkomTexts.of(context).comms(), tap, 25.0, 25.0)),

                  lst("images/icons/servic.png",
                      LinkomTexts.of(context).services(), tap, 25.0, 25.0),
                ])),
            //shop,
            //  die,
            // cov,
            // pro,
            Container(
                padding: EdgeInsets.only(left: 12, right: 12),
                margin: EdgeInsets.only(top: 8, left: 12, right: 12),
                decoration: new BoxDecoration(
                    color: Colors.white,
                    border: new Border.all(color: Colors.grey[100], width: 1.0),
                    borderRadius: new BorderRadius.circular(12.0)),
                child: Column(children: <Widget>[share, logout])),
            Container(
              height: 40,
            ),
          ],
        ));
  }
}
