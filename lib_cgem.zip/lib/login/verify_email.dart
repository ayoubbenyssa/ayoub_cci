import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/login/login_entreprise.dart';
import 'package:medz/login/login_w.dart';
import 'package:medz/models/membre.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/email_verify_services.dart';
import 'package:medz/services/routes.dart';
import 'package:medz/services/send_email_service.dart';
import 'package:medz/services/validators.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:random_string/random_string.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class Email_Verify extends StatefulWidget {
  Email_Verify(this.chng);

  var chng;

  @override
  _Email_VerifyState createState() => _Email_VerifyState();
}

class _Email_VerifyState extends State<Email_Verify> {
  final _contactcontroller = new TextEditingController();
  FocusNode _focuscontact = new FocusNode();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  bool _autovalidate = false;
  String _authHint = "";
  bool load = false;
  String code = "";
  final _textController = new TextEditingController();

  send_code(Contact contact) async {
    setState(() {
      load = true;
    });

    print("yess");
    code = randomAlphaNumeric(4);

    await EmailService.sendCustomMail(
        _contactcontroller.text,
        "Code de vérification",
        ""
                "Code de vérification " +
            code);
    setState(() {
      load = false;

      _authHint = "";
    });

    print(contact.nom);
    print(contact.membre);
    contact.new_membre = false;

    _showDialog(contact, email: _contactcontroller.text);
    /*_showDialog(
        "Nous avons envoyé un code de vérificaton à ce compte " +
            email.toString().substring(0, 4) +
            "*************@" +
            email.split("@")[1] +
            " , veuillez entrer le "
                "code de vérification ici ! ",
        contact,
        email: email,
        id: id);*/
  }

  _showDialog(Contact contact, {email}) async {
    return await showDialog(
      context: context,
      child: new AlertDialog(
        contentPadding: const EdgeInsets.all(24.0),
        content: Container(
            height: MediaQuery.of(context).size.height * 0.6,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  "$code" "      " +
                      "Afin de verifier votre appartenance à ${contact.membre.name},  "
                          "un email de validation a été envoyé à votre administrateur de compte sur le mail " +
                      _contactcontroller.text.toString().substring(0, 4) +
                      "*************@" +
                      _contactcontroller.text.split("@")[1] +
                      ". sa validation est "
                          "nécessaire avant que vous puissiez rejoindre la communauté MyCGEM!.",
                  textAlign: TextAlign.justify,
                  style: new TextStyle(
                      height: 1.2,
                      fontSize: 16.5,
                      fontWeight: FontWeight.w700,
                      color: Fonts.col_ap_fonn),
                ),
                new Row(
                  children: <Widget>[
                    Container(
                      height: 16.0,
                    ),
                    new Expanded(
                      child: new TextFormField(
                        autofocus: true,
                        controller: _textController,
                        decoration: new InputDecoration(
                            hintText: "Entrer le code de vérification"),
                      ),
                    )
                  ],
                ),
              ],
            )),
        actions: <Widget>[
          new Container(
              child: new Material(
                  elevation: 12.0,
                  shadowColor: clr,
                  borderRadius: new BorderRadius.circular(12.0),
                  color: clr,
                  child: new MaterialButton(
                      child: new Text(
                        "Vérification",
                        style: style,
                      ),
                      onPressed: () async {
                        if (code == _textController.text) {
                          Navigator.pop(context);
                          setState(() {
                            _authHint = "Votre compte a été vérifié";
                          });

                          try {
                            contact.email = email;
                            Routes.goto(context, "register", null, null, [],
                                null, widget.chng,
                                id_ent: contact.membre.objectId,
                                contact: contact);

                            /* */
                          } catch (e) {
                            Navigator.pop(context);
                            print('Error: $e');

                            if (e.message.toString() ==
                                "The email address is already in use by another account.") {
                              setState(() {
                                _authHint =
                                    "Cet email est déja utilisé par un autre compte";
                              });
                            }

                            print(e.message.toString());
                          }
                        } else {
                          // Navigator.pop(context);

                          _scaffoldKey.currentState.showSnackBar(new SnackBar(
                            content: new Text("Code incorrect!"),
                          ));
                        }
                      }))),
        ],
      ),
    );
  }

  getcontactbyemail(email) async {
    setState(() {
      load = true;
    });
    dynamic result = await EmailverifyServices.get_contact_by_email(email);
    if (!this.mounted) return;

    print(result);

    if (result == "No internet" || result == "error") return;

    if (result.length > 0) {
      print("yessskskks");

      print(result.length);

      Contact contact = new Contact.fromMap(result[0]);

      send_code(contact);
      setState(() => load = false);
    } else {
      setState(() {
        load = false;
      });
      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return LoginEntreprise(widget.chng, _contactcontroller.text);
      }));
    }
  }

  /**
   *
      Container(
      padding: EdgeInsets.only(
      left: 16.0, right: 16.0),
      child: RichText(
      textAlign:
      TextAlign.justify,
      text: new TextSpan(
      text: "",
      children: <TextSpan>[
      new TextSpan(
      text:
      "Si vous n'avez pas trouvé votre organisme sur la liste, ",
      style: TextStyle(
      color: Colors
      .grey[600],
      fontSize: 16),
      ),
      new TextSpan(
      text: //(dans une entreprise déjà inscrite au niveau de la plateforme)
      "cliquez ici pour l'ajouter  ",
      recognizer:
      new TapGestureRecognizer()
      ..onTap = () {
      sub();
      },
      style: new TextStyle(
      decoration:
      TextDecoration
      .underline,
      color:
      Colors.blue,
      fontSize: 16.0,
      fontWeight:
      FontWeight
      .w500))
      ],
      ))),
   */

  ParseServer parse_s = new ParseServer();

  alert_login() {
    Alert(
        context: context,
        title: "",
        content: Column(
          children: <Widget>[
            Text("Cet email est déja utilisé par un autre compte ! "),
            Container(
              height: 16,
            ),
            new InkWell(
                onTap: () {
                  Routes.goto(
                    context,
                    "reset",
                    null,
                    null,
                    [],
                    null,
                    widget.chng,
                  );
                },
                child: new Row(
                  children: <Widget>[
                    new Expanded(child: new Container()),
                    new Text(
                      LinkomTexts.of(context).forgot_pass(),
                      style: new TextStyle(
                          color: Colors.grey[700],
                          decoration: TextDecoration.underline),
                    )
                  ],
                )),
          ],
        ),
        buttons: [
          DialogButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text(
              "LOGIN",
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
          )
        ]).show();
  }

  void _handleSubmitted() async {
    final FormState form = _formKey.currentState;
    if (!form.validate()) {
      _autovalidate = true; // Start validating on every change.
      //showInSnackBar("Veuillez corriger les erreurs en rouge");
    } else {
      print("jihad");
      setState(() {
        _authHint = "";
      });
      var a = await parse_s
          .getparse('users?where={"email":"${_contactcontroller.text}"}');

      print(a);

      if (a == "error" || a == "No") return;
      setState(() {
        load = false;
      });

      if (a["results"].length > 0) {
        alert_login();
      } else {
        getcontactbyemail(_contactcontroller.text);
      }
    }
  }

  var style = new TextStyle(
      color: const Color(0xffeff2f7),
      fontSize: 20.0,
      fontWeight: FontWeight.w500);
  var clr = Fonts.col_app_fon;

  @override
  Widget build(BuildContext context) {
    Validators val = new Validators(context: context);

    Widget btn_log = new Padding(
        padding: new EdgeInsets.only(left: 36.0, right: 36.0),
        child: new Material(
            elevation: 12.0,
            shadowColor: clr,
            borderRadius: new BorderRadius.circular(12.0),
            color: clr,
            child: new MaterialButton(
                // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  _handleSubmitted();
                },
                child:
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  load
                      ? Container(
                          width: 20,
                          height: 20,

                          // padding: EdgeInsets.all(8),
                          child: CircularProgressIndicator(
                            valueColor:
                                new AlwaysStoppedAnimation<Color>(Colors.white),
                          ))
                      : Container(),
                  load
                      ? Container(
                          width: 12,
                        )
                      : Container(),
                  new Text("Enregistrer".toUpperCase(), style: style)
                ]))));

    Widget contact = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Email", _focuscontact, "", _contactcontroller,
            TextInputType.emailAddress, val.validateEmail));

    Widget hintText() {
      return _authHint == ""
          ? new Container()
          : new Container(
              //height: 80.0,
              padding: const EdgeInsets.all(32.0),
              child: new Text(_authHint,
                  key: new Key('hint'),
                  style: new TextStyle(
                      height: 1.2,
                      fontSize: 16.5,
                      fontWeight: FontWeight.w700,
                      color: Fonts.col_ap_fonn),
                  textAlign: TextAlign.justify));
    }

    return Scaffold(
        key: _scaffoldKey,
        /* appBar: new AppBar(
          iconTheme: IconThemeData(color: Fonts.col_app_fon),
          backgroundColor: Fonts.col_app_shadow,
          title: new Text(
            "Confirmer vos informations",
            style: TextStyle(color: Fonts.col_app_fon),
          ),
          elevation: 0.0,
        ),*/
        body: new Container(
            decoration: new BoxDecoration(
              /*image: new DecorationImage(
                    fit: BoxFit.cover,
                    colorFilter: new ColorFilter.mode(
                        Colors.white.withOpacity(0.3), BlendMode.dstATop),
                    image: new AssetImage("images/back.jpg"))*/
            ),
            child: new Stack(fit: StackFit.expand, children: <Widget>[
              ListView(children: <Widget>[
                new Container(
                    height: 900.0,
                    child: new LoginBackground(
                      Widgets.kitGradients1,
                      showIcon: true,
                    ))
              ]),
              ListView(children: <Widget>[
                Column(children: <Widget>[
                  new Padding(
                      padding: new EdgeInsets.only(
                          top: 154.0, left: 12.0, right: 12.0, bottom: 18.0),
                      child: SizedBox(
                          width: MediaQuery.of(context).size.width * 0.98,
                          child: new Material(
                              color: Colors.white.withOpacity(0.9),
                              elevation: 20.0,
                              borderRadius: new BorderRadius.circular(12.0),
                              shadowColor: Fonts.col_app_fon,
                              child: Form(
                                  key: _formKey,
                                  autovalidate: _autovalidate,
                                  child: Column(
                                    children: [
                                      new Container(height: 18.0),
                                      new Center(
                                          child: Widgets.subtitle5(
                                              Fonts.col_app_fonn,
                                              "Saisissez votre email")),
                                      new Container(height: 32.0),
                                      Container(
                                        height: 8,
                                      ),
                                      contact,
                                      Container(
                                        height: 8,
                                      ),
                                      hintText(),
                                      Container(
                                        height: 16,
                                      ),
                                      btn_log,
                                      Container(height: 42,)
                                    ],
                                  ))))),
                ])
              ])
            ])));
  }
}
