import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:medz/entreprise/resp_list.dart' as prefix0;
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/login/login_w.dart';
import 'package:medz/models/alphabets.dart';
import 'package:medz/models/membre.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/user.dart';
import 'package:medz/pages/conditions.dart';
import 'package:medz/pages/politique.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/auth.dart';
import 'package:medz/services/block.dart';
import 'package:medz/services/login_services.dart';
import 'package:medz/services/send_email_service.dart';
import 'package:medz/services/validators.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:random_string/random_string.dart';

class Register extends StatefulWidget {
  Register(
      this.list_partner, this.analytics, this.chng, this.id_ent, this.contact);

  List list_partner;
  var analytics;
  var chng;
  String id_ent;
  Contact contact;

  @override
  _LoginState createState() => new _LoginState();
}

class _LoginState extends State<Register> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  bool _autovalidate = false;
  FocusNode _focuspassword = new FocusNode();
  FocusNode _focusemail = new FocusNode();
  FocusNode _focusname = new FocusNode();
  FocusNode _focustitre = new FocusNode();
  FocusNode _focusorganise = new FocusNode();
  FocusNode _focuspre = new FocusNode();
  FocusNode _focusphone = new FocusNode();
  FocusNode _focusconfirm = new FocusNode();
  final _confirmcontroller = new TextEditingController();
  bool _isChecked = false;
  bool _isChecked1 = false;

  final GlobalKey<FormFieldState<String>> _passwordFieldKey =
      new GlobalKey<FormFieldState<String>>();
  String _authHint = '';
  final _passcontroller = new TextEditingController();
  final _titrecontroller = new TextEditingController();
  final _organismecontroller = new TextEditingController();

  final _emailcontroller = new TextEditingController();
  final _namecontroller = new TextEditingController();
  final _precontroller = new TextEditingController();
  final _phonecontroller = new TextEditingController();
  BaseAuth auth;
  VoidCallback onSignedIn;

  User user = new User();
  var deviceSize;
  var clr = Colors.grey[600];
  var part;
  String rep = "";
  final _textController = new TextEditingController();

  bool verify = false;
  bool load = false;

  void showInSnackBar(String value) {
    _scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  void onLoading(context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        child: new Dialog(
          child: new Container(
            padding: new EdgeInsets.all(16.0),
            width: 40.0,
            color: Colors.transparent,
            child: new Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                new RefreshProgressIndicator(),
                new Container(height: 8.0),
                new Text(
                  "En cours .. ",
                  style: new TextStyle(
                    color: Fonts.col_app,
                  ),
                ),
              ],
            ),
          ),
        ));

    // Navigator.pop(context); //pop dialog
    //  _handleSubmitted();
  }

  String validateMobile(String value) {
// Indian Mobile number are of 10 digit only
    if (value.length <= 0)
      return "Entrez le numéro de téléphonne";
    else if (value.length != 10 && value.length != 12)
      return 'Le numéro de téléphone n est pas valid';
    else if (value[0] != "0" && value[0] != "+")
      return 'Le numéro de téléphone n est pas valid';

    return null;
  }

  void _handleSubmitted() async {
    if (_isChecked.toString() == "false") {
    } else {
      final FormState form = _formKey.currentState;
      if (!form.validate()) {
        _autovalidate = true; // Start validating on every change.
        showInSnackBar("Veuillez corriger les erreurs en rouge");
      } else {
        onLoading(context);
        try {
          //RegisterService.onLoading(context);
          AuthResult userId = await FirebaseAuth.instance
              .createUserWithEmailAndPassword(
                  email: _emailcontroller.text.replaceAll(' ', ''), password: _passcontroller.text);
          String alpha = _precontroller.text[0].toString().toLowerCase();
          await Block.insert_block(
              userId.user.uid, userId.user.uid, null, null);

          print("--------------------------------------");
          print(part);

          await RegisterService.insert_user(
              _precontroller.text,
              _namecontroller.text,
              _emailcontroller.text,
              context,
              userId.user.uid,
              Alphabets.list[0][alpha],
              _titrecontroller
                  .text /*widget.contact.objectId == '' ? widget.contact.fonction : ""*/,
              widget.contact.membre == null
                  ? ""
                  : widget.contact.membre
                      .name /* widget.contact.objectId == '' ? widget.contact.organisme : ""*/,
              null,
              null,
              widget.list_partner,
              widget.analytics,
              widget.chng,
              membre_new: widget.contact.new_membre,

              ///if the organisme is newly created
              verify: rep,
              contact_id: widget.contact.objectId,
              id_ent: widget.id_ent,
              phone: _phonecontroller.text,
              resp: type);
          //Communities

          /***
           * jiya
           */
          /*  Navigator.pushReplacement(context,
              new MaterialPageRoute(builder: (BuildContext context) {
                return new Communities(widget.auth, widget.onSignedIn,
                    widget.list_partner,widget.analytics);
              }));*/

          //widget.onSignedIn();
        } catch (e) {
          Navigator.pop(context);
          print('Error: $e');

          if (e.message.toString() ==
              "The email address is already in use by another account.") {
            setState(() {
              _authHint = "Cet email est déja utilisé par un autre compte";
            });
          }

          print(e.message.toString());
        }
      }
    }
  }

  _onChecked(value) {
    setState(() {
      _isChecked = value;
      print(_isChecked);
    });
    if (_isChecked.toString() == "false") {
      setState(() {
        clr = Colors.grey[600];
      });
    } else {
      setState(() {
        clr = Fonts.col_app_fon;
      });
    }

    if (value == true)
      setState(() {
        value = false;
      });
    else
      setState(() {
        value = true;
      });
  }

  bool ch = false;
  List type = [];

  Widget tpe_profile() => type == "Laquelle ??"
      ? Container()
      : new InkWell(
          child: new Container(
              padding: EdgeInsets.all(8),
              margin: EdgeInsets.only(bottom: 8),
              decoration: new BoxDecoration(
                color: const Color(0xffeff2f7),
                gradient: new LinearGradient(
                    begin: FractionalOffset.bottomCenter,
                    end: FractionalOffset.topCenter,
                    colors: [
                      Colors.white,
                      Colors.grey[100],
                    ]),
                borderRadius: new BorderRadius.circular(4.0),
                boxShadow: <BoxShadow>[
                  new BoxShadow(
                    spreadRadius: 0.5,
                    color: Colors.grey[400],
                    blurRadius: 0.5,
                    offset: new Offset(0.0, 1.0),
                    // color: const Color(0xffedd9ac)
                  ),
                ],
              ),
              child: new Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Container(width: 8.0),
                    new Container(
                        child: new Text(
                            type.toString() != "[]" && type.toString() != "null"
                                ? type[1].toString()
                                : "Choisir une responsabilté",
                            style: new TextStyle(
                                fontSize: 14.0,
                                fontWeight: FontWeight.w500,
                                color: Colors.grey[600]))),
                    new Expanded(child: new Container()),
                    new Icon(
                      Icons.arrow_drop_down,
                      color: Fonts.col_app_fon,
                    )
                  ])),
          onTap: () {
            resp();
          });

  resp() async {
    // Navigator.pop(widget.context);
    type = await Navigator.push(context,
        new MaterialPageRoute(builder: (BuildContext context) {
      return new prefix0.RespList(null, null);
    }));

    setState(() {
      type = type;

      print("99999");

      print(type);

      if (type.length == 2) {
        print(type[0]);
        print(type[1]);
      }
    });
  }

  _onChecked1(value) {
    setState(() {
      _isChecked1 = value;
    });
    if (_isChecked1.toString() == "false") {
      setState(() {
        ch = false;
      });
    } else {
      setState(() {
        ch = true;
      });
    }
  }

  check() => new Checkbox(
        activeColor: Colors.grey,
        value: _isChecked,
        onChanged: (bool value) {
          print(value);
          _onChecked(value);
        },
      );

  check1() => new Checkbox(
        activeColor: Colors.blue,
        value: _isChecked1,
        onChanged: (bool value) {
          print(value);
          _onChecked1(value);
        },
      );

  _showDialog(text, {result}) async {
    return await showDialog(
      context: context,
      child: new AlertDialog(
        contentPadding: const EdgeInsets.all(24.0),
        content: Container(
            height: 180,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  text,
                  textAlign: TextAlign.justify,
                ),
                verify == true
                    ? new Row(
                        children: <Widget>[
                          Container(
                            height: 16.0,
                          ),
                          new Expanded(
                            child: new TextFormField(
                              autofocus: true,
                              controller: _textController,
                              decoration: new InputDecoration(
                                  hintText: 'Code de vérification'),
                            ),
                          )
                        ],
                      )
                    : Container(),
              ],
            )),
        actions: <Widget>[
          new FlatButton(
              child: new Text(verify == true ? "Vérification" : 'Ok'),
              onPressed: () async {
                if (verify == true) {
                  if (code == _textController.text) {
                    Navigator.pop(context);
                    setState(() {
                      rep = "Votre compte a été vérifié";
                    });

                    onLoading(context);
                    try {
                      //RegisterService.onLoading(context);
                      AuthResult userId = await FirebaseAuth.instance
                          .createUserWithEmailAndPassword(
                              email: _emailcontroller.text,
                              password: _passcontroller.text);
                      String alpha =
                          _precontroller.text[0].toString().toLowerCase();
                      await Block.insert_block(
                          userId.user.uid, userId.user.uid, null, null);

                      print("--------------------------------------");
                      print(part);

                      await RegisterService.insert_user(
                          _precontroller.text,
                          _namecontroller.text,
                          _emailcontroller.text,
                          context,
                          userId.user.uid,
                          Alphabets.list[0][alpha],
                          "",
                          "",
                          null,
                          null,
                          widget.list_partner,
                          widget.analytics,
                          widget.chng,
                          verify: rep,
                          id_ent: part,
                          phone: _phonecontroller.text,
                          resp: type);
                      //Communities

                      /***
                       * jiya
                       */
                      /*  Navigator.pushReplacement(context,
              new MaterialPageRoute(builder: (BuildContext context) {
                return new Communities(widget.auth, widget.onSignedIn,
                    widget.list_partner,widget.analytics);
              }));*/

                      //widget.onSignedIn();
                    } catch (e) {
                      Navigator.pop(context);
                      print('Error: $e');

                      if (e.message.toString() ==
                          "The email address is already in use by another account.") {
                        setState(() {
                          _authHint =
                              "Cet email est déja utilisé par un autre compte";
                        });
                      }

                      print(e.message.toString());
                    }
                  } else {
                    // Navigator.pop(context);

                    _scaffoldKey.currentState.showSnackBar(new SnackBar(
                      content: new Text("Code incorrect!"),
                    ));
                  }
                } else {
                  Navigator.pop(context);
                }
              }),
        ],
      ),
    );
  }

  ParseServer parse_s = new ParseServer();
  String code = "";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    print(widget.contact.fonction.toString());

    _emailcontroller.text = widget.contact.email;
    _namecontroller.text = widget.contact.nom.toString() == "null"
        ? ""
        : widget.contact.nom.toString();
    _precontroller.text = widget.contact.prenom.toString() == "null"
        ? ""
        : widget.contact.prenom.toString();
    _titrecontroller.text = widget.contact.fonction.toString() == "null"
        ? ""
        : widget.contact.fonction.toString();

    // _fir.text= widget.contact.name[1];
  }

  @override
  Widget build(BuildContext context) {
    Validators val = new Validators(context: context);

    Widget hintText() {
      return _authHint == ""
          ? new Container()
          : new Container(
              //height: 80.0,
              padding: const EdgeInsets.all(32.0),
              child: new Text(_authHint,
                  key: new Key('hint'),
                  style: new TextStyle(fontSize: 14.0, color: Colors.red[700]),
                  textAlign: TextAlign.center));
    }

    Widget email = new Container(
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Email", _focusemail, user.email,
            _emailcontroller, TextInputType.emailAddress, val.validateEmail));

    Widget Nom = new Container(
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Nom", _focusname, user.fullname,
            _namecontroller, TextInputType.text, val.validatename));

    Widget prenom = new Container(
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Prenom", _focuspre, user.prenom,
            _precontroller, TextInputType.text, val.validatename));

    /* Widget phone = new Container(
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield0("GSM ( 06 ** ** ** **)", _focusphone,
            user.phone, _phonecontroller, TextInputType.phone));
*/
    Widget organisme = new Container(
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Organisme", _focusorganise, user.organisme,
            _organismecontroller, TextInputType.text, val.validateorganisme));

    Widget titre = new Container(
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Fonction", _focustitre, user.titre,
            _titrecontroller, TextInputType.text, val.validatetitre));

    Widget password = new Container(
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: new TextFormField(
            style: new TextStyle(fontSize: 15.0, color: Colors.black),
            focusNode: _focuspassword,
            obscureText: true,
            controller: _passcontroller,
            validator: val.validatePassword,
            key: _passwordFieldKey,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: new EdgeInsets.all(8.0),
              hintText: "Mot de passe",
              hintStyle: new TextStyle(
                  fontSize: 15.0,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey),
            ),
            onFieldSubmitted: (String value) {
              setState(() {
                user.password = value;
              });
            }));

    String _validatePassword2(String value) {
      final FormFieldState<String> passwordField =
          _passwordFieldKey.currentState;
      if (passwordField.value == null || passwordField.value.isEmpty)
        return "Les mots de passe saisis ne correspondent pas";
      if (passwordField.value != value)
        return "Les mots de passe saisis ne correspondent pas";
      return null;
    }

    Widget confirmpassword = Widgets.textfield(
        "Confirmer le mot de passe",
        _focusconfirm,
        user.confirm,
        _confirmcontroller,
        TextInputType.text,
        _validatePassword2,
        obscure: true);

    var style = new TextStyle(
        color: const Color(0xffeff2f7),
        fontSize: 20.0,
        fontWeight: FontWeight.w500);

    Widget btn_log = new Padding(
        padding: new EdgeInsets.only(left: 36.0, right: 36.0, top: 12),
        child: new Material(
            elevation: 12.0,
            shadowColor: clr,
            borderRadius: new BorderRadius.circular(12.0),
            color: clr,

            /*decoration: new BoxDecoration(
            border: new Border.all(color: const Color(0xffeff2f7), width: 1.5),
            borderRadius: new BorderRadius.circular(6.0)),*/
            child: new MaterialButton(
                // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  _handleSubmitted();
                },
                child: new Text(LinkomTexts.of(context).sve(), style: style))));
    deviceSize = MediaQuery.of(context).size;

    return new Scaffold(
        key: _scaffoldKey,
        body: new Center(
            child: new Container(
                decoration: new BoxDecoration(
                    /*image: new DecorationImage(
                        fit: BoxFit.cover,
                        colorFilter: new ColorFilter.mode(
                            Colors.white.withOpacity(0.7), BlendMode.dstATop),
                        image: new AssetImage("images/back.jpg"))*/
                    ),
                child: new Stack(fit: StackFit.expand, children: <Widget>[
                  ListView(children: <Widget>[
                    new Container(
                        height: 700.0,
                        child: new LoginBackground(
                          Widgets.kitGradients1,
                          showIcon: true,
                        ))
                  ]),
                  ListView(children: <Widget>[
                    Row(children: <Widget>[
                      IconButton(
                          icon: Icon(Icons.close),
                          color: Colors.white,
                          onPressed: () {
                            Navigator.pop(context);
                          })
                    ]),
                    Column(children: <Widget>[
                      new Padding(
                          padding: new EdgeInsets.only(
                              top: 62.0, left: 18.0, right: 18.0, bottom: 18.0),
                          child: SizedBox(
                              width: deviceSize.width * 0.98,
                              child: new Material(
                                  color: Colors.white.withOpacity(0.9),
                                  elevation: 20.0,
                                  borderRadius: new BorderRadius.circular(12.0),
                                  shadowColor: Fonts.col_app,
                                  child: new Form(
                                      key: _formKey,
                                      autovalidate: _autovalidate,
                                      //onWillPop: _warnUserAboutInvalidData,
                                      child: new Container(
                                          padding: new EdgeInsets.all(12.0),
                                          child: new Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                new Container(height: 8.0),
                                                new Center(
                                                    child: Widgets.subtitle2(
                                                        Fonts.col_app)),
                                                hintText(),
                                                new Container(height: 18.0),
                                                Nom,
                                                new Container(height: 8.0),
                                                prenom,
                                                new Container(height: 8.0),
                                                //phone,
                                                //new Container(height: 8.0),
                                                /* Container(
                                                  child: Text(
                                                    "Mentionnez votre mail professionnel pour "
                                                    "activer automatiquement votre compte premium MyCGEM",
                                                    style: TextStyle(
                                                        color: Fonts.col_app),
                                                  ),
                                                ),*/

                                                Container(
                                                  width: MediaQuery.of(context)
                                                      .size
                                                      .width,
                                                  child: email,
                                                ),
                                                /*Container(
                                                      width: 2,
                                                    ),
                                                    RaisedButton(
                                                      padding:
                                                          EdgeInsets.all(0),
                                                      color: Fonts.col_app,
                                                      child: Row(
                                                        children: <Widget>[
                                                          Text(
                                                            "Vérifier",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white),
                                                          ),
                                                          load
                                                              ? CircularProgressIndicator(
                                                                  backgroundColor:
                                                                      Colors
                                                                          .white,
                                                                )
                                                              : Container()
                                                        ],
                                                      ),
                                                      onPressed: () {
                                                        verifyy();
                                                      },
                                                    )*/
                                                new Container(
                                                  height: 8.0,
                                                ),
                                                titre,
                                                new Container(
                                                  height: 8.0,
                                                ),
                                                ch
                                                    ? tpe_profile()
                                                    : Container(),
                                                password,
                                                new Container(height: 8.0),
                                                new Container(
                                                    decoration: new BoxDecoration(
                                                        border: new Border.all(
                                                            color: Colors
                                                                .grey[400],
                                                            width: 1.0),
                                                        borderRadius:
                                                            new BorderRadius
                                                                .circular(4.0)),
                                                    child: confirmpassword),
                                                new Container(height: 8.0),
                                                new Row(
                                                  children: <Widget>[
                                                    check(),
                                                    new Container(
                                                        width: 240.0,
                                                        child: new RichText(
                                                          text: new TextSpan(
                                                            text:
                                                                "J'accepte les ",
                                                            style: new TextStyle(
                                                                color: Colors
                                                                    .grey[700]),
                                                            children: <
                                                                TextSpan>[
                                                              new TextSpan(
                                                                  recognizer: new TapGestureRecognizer()
                                                                    ..onTap = () => Navigator.push(
                                                                        context,
                                                                        new MaterialPageRoute(
                                                                            builder: (BuildContext context) =>
                                                                                new Conditions())),
                                                                  text:
                                                                      "conditions d'utilisation",
                                                                  style: new TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                      color: Colors
                                                                              .blue[
                                                                          600])),
                                                              new TextSpan(
                                                                  text:
                                                                      ' et la '),
                                                              new TextSpan(
                                                                  recognizer: new TapGestureRecognizer()
                                                                    ..onTap = () => Navigator.push(
                                                                        context,
                                                                        new MaterialPageRoute(
                                                                            builder: (BuildContext context) =>
                                                                                new Potique())),
                                                                  text:
                                                                      "politique de confidentialité",
                                                                  style: new TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                      color: Colors
                                                                              .blue[
                                                                          600])),
                                                            ],
                                                          ),
                                                        ))
                                                  ],
                                                ),
                                                btn_log,
                                                new Container(height: 12.0),
                                              ]))))))
                    ])
                  ])
                ]))));
  }
}
