import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/login/create_new_entreprise.dart';
import 'package:medz/models/membre.dart';
import 'package:medz/services/contacts_services.dart';
import 'package:medz/services/routes.dart';
import 'package:medz/services/send_email_service.dart';
import 'package:medz/user/edit_my_profile.dart';
import 'package:random_string/random_string.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/login/login_w.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/validators.dart';
import 'package:medz/widgets/widgets.dart';
import 'list_entreprise_inscription.dart';

class LoginEntreprise extends StatefulWidget {
  LoginEntreprise(this.chng, this.email);

  var chng;
  String email;

  bool show_myprofile = true;

  @override
  _InvitrefriendsState createState() => _InvitrefriendsState();
}

class _InvitrefriendsState extends State<LoginEntreprise> {
  final _titrecontroller = new TextEditingController();
  final _namecontroller = new TextEditingController();
  final _contactcontroller = new TextEditingController();

  final _raisonc = new TextEditingController();
  FocusNode _focustitre = new FocusNode();

  final _organismecontroller = new TextEditingController();
  Membre type_profile;

  Membre type;
  FocusNode _focusraison = new FocusNode();
  FocusNode _focusname = new FocusNode();
  FocusNode _focuscontact = new FocusNode();
  String email = "";
  String id = "";
  FocusNode _focusorganise = new FocusNode();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  bool _autovalidate = false;
  String _authHint = '';
  ParseServer parse_s = new ParseServer();
  String id_organisme;
  Contact contactt;

  ///List<Contact> contacts = [];
  String choice_email = "";

  var my_id = "";

  getId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    my_id = prefs.getString("id");
  }

  bool yes_or = false;

  @override
  void initState() {
    getId();
  }

  sub() {
    Navigator.pushReplacement(context,
        new MaterialPageRoute(builder: (BuildContext context) {
          return new CreateNewEntrepriseForm(widget.email,id, widget.chng);
        }));
  }

  /* gotoprofile() {
    Navigator.pushReplacement(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              //new HomePage(widget.auth,widget.sign)
              new EditMyProfile(
                  /*com,*/
                  null,
                  null,
                  [],
                  widget.chng,
                  true),
        ));
  }*/

  /*update_user_entreprise(id, entreprise) async {
    String t = _titrecontroller.text;
    String ra = _raisonc.text;

    var js_org = {
      "entreprise": {
        "__type": "Pointer",
        "className": "partners",
        "objectId": '$id'
      },
      "titre": "$t",
      "raison": "$ra",
      "organisme": "$entreprise"
    };

    await parse_s.putparse('users/' + my_id, js_org);
  }*/

  create_entreprise(owner, name, contact, entreprise) async {
    var res = await parse_s.postparse('partners/', {
      "name": "$name",
      "email": "$contact",
      "type": "$owner",
      "confirm": true
    });
    id_organisme = res["objectId"];
    // await update_user_entreprise(res["objectId"], entreprise);
    //Navigator.pop(context);
  }

  Widget hintText() {
    return _authHint == ""
        ? new Container()
        : new Container(
      //height: 80.0,
        padding: const EdgeInsets.all(32.0),
        child: new Text(_authHint,
            key: new Key('hint'),
            style: new TextStyle(fontSize: 14.0, color: Colors.red[700]),
            textAlign: TextAlign.center));
  }

  Widget tpe_profile() => new InkWell(
      child: new Container(
          margin: EdgeInsets.only(left: 12.0, right: 12.0),
          decoration: new BoxDecoration(
            color: const Color(0xffeff2f7),
            gradient: new LinearGradient(
                begin: FractionalOffset.bottomCenter,
                end: FractionalOffset.topCenter,
                colors: [
                  Colors.white,
                  Colors.grey[100],
                ]),
            borderRadius: new BorderRadius.circular(4.0),
            boxShadow: <BoxShadow>[
              new BoxShadow(
                spreadRadius: 0.5,
                color: Colors.grey[400],
                blurRadius: 0.5,
                offset: new Offset(0.0, 1.0),
                // color: const Color(0xffedd9ac)
              ),
            ],
          ),
          height: 40.0,
          child: new Row(children: <Widget>[
            new Container(width: 8.0),
            new Container(
                child: new Text(
                    type_profile.toString() != "null"
                        ? type_profile.name.toString()
                        : LinkomTexts.of(context).cent(),
                    style: new TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500,
                        color: Colors.grey[600]))),
            new Container(
              width: 4.0,
            ),
            new Container(
              width: 8.0,
            ),
            new Expanded(child: new Container()),
            new Icon(
              Icons.arrow_drop_down,
              color: Fonts.col_app_fon,
            )
          ])),
      onTap: () {
        goto_types();
      });

  String code = "";

  bool load = false;
  bool verify = false;
  String rep = "";
  final _textController = new TextEditingController();

  _showDialog(text, Contact contact, {email, id}) async {
    return await showDialog(
      context: context,
      child: new AlertDialog(
        contentPadding: const EdgeInsets.all(24.0),
        content: Container(
            height: 180,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  text,
                  textAlign: TextAlign.justify,
                ),
                verify == true || verify2 == true
                    ? new Row(
                  children: <Widget>[
                    Container(
                      height: 16.0,
                    ),
                    new Expanded(
                      child: new TextFormField(
                        autofocus: true,
                        controller: _textController,
                        decoration: new InputDecoration(
                            hintText: 'Code de vérification'),
                      ),
                    )
                  ],
                )
                    : Container(),
              ],
            )),
        actions: <Widget>[
          new FlatButton(
              child: new Text(
                  verify == true || verify2 == true ? "Vérification" : 'Ok'),
              onPressed: () async {
                if (verify == true || verify2 == true) {
                  if (code == _textController.text) {
                    Navigator.pop(context);
                    setState(() {
                      rep = "Votre compte a été vérifié";
                    });

                    try {
                      /*await RegisterService.insert_user(
                          _precontroller.text,
                          _namecontroller.text,
                          _emailcontroller.text,
                          context,
                          userId.user.uid,
                          Alphabets.list[0][alpha],
                          "",
                          "",
                          null,
                          null,
                          widget.list_partner,
                          widget.analytics,
                          widget.chng,
                          verify: rep,
                          part: part,
                          phone: _phonecontroller.text,
                          resp: type);
                      //Communities*/

                      /***
                       * jiya
                       */
                      /*  Navigator.pushReplacement(context,
              new MaterialPageRoute(builder: (BuildContext context) {
                return new Communities(widget.auth, widget.onSignedIn,
                    widget.list_partner,widget.analytics);
              }));*/

                      //widget.onSignedIn();

                      print('gooooooooooooooooooooooooo');
                      print(email);
                      contact.email = email;
                      contact.new_membre= false;
                      Routes.goto(context, "register", null, null, [], null,
                          widget.chng,
                          id_ent: id, contact: contact);

                      /* */
                    } catch (e) {
                      Navigator.pop(context);
                      print('Error: $e');

                      if (e.message.toString() ==
                          "The email address is already in use by another account.") {
                        setState(() {
                          _authHint =
                          "Cet email est déja utilisé par un autre compte";
                        });
                      }

                      print(e.message.toString());
                    }
                  } else {
                    // Navigator.pop(context);

                    _scaffoldKey.currentState.showSnackBar(new SnackBar(
                      content: new Text("Code incorrect!"),
                    ));
                  }
                } else {
                  Navigator.pop(context);
                }
              }),
        ],
      ),
    );
  }

  onchanged(emai) {
    email = emai;
  }

  alert_login() {
    Alert(
        context: context,
        title: "",
        content: Column(
          children: <Widget>[
            Text("Cet email est déja utilisé par un autre compte ! "),
            Container(
              height: 16,
            ),
            new InkWell(
                onTap: () {
                  Routes.goto(
                    context,
                    "reset",
                    null,
                    null,
                    [],
                    null,
                    widget.chng,
                  );
                },
                child: new Row(
                  children: <Widget>[
                    new Expanded(child: new Container()),
                    new Text(
                      LinkomTexts.of(context).forgot_pass(),
                      style: new TextStyle(
                          color: Colors.grey[700],
                          decoration: TextDecoration.underline),
                    )
                  ],
                )),
          ],
        ),
        buttons: [
          DialogButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text(
              "LOGIN",
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
          )
        ]).show();
  }

  send_code(Contact contact) async {
    setState(() {
      load = true;
    });

    print("yess");
    print(code);

    await EmailService.sendCustomMail(
        email,
        "Code de vérification",
        ""
            "Code de vérification " +
            code);
    setState(() {
      load = false;
    });

    _showDialog(
        "Nous avons envoyé un code de vérificaton à ce compte " +
            email.toString().substring(0, 4) +
            "*************@" +
            email.split("@")[1] +
            " , veuillez entrer le "
                "code de vérification ici ! ",
        contact,
        email: email,
        id: id);
  }

  dialogContent(BuildContext context, Contact contact) async {
    return await showDialog(
        context: context,
        child: Container(
            height: 300,
            margin: EdgeInsets.only(top: 50.0, bottom: 50.0),
            alignment: Alignment.center,
            child: Dialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(20.0),
                  ),
                ),
                elevation: 25.0,
                backgroundColor: Colors.white,
                child: Container(
                  child: Column(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.all(5.0),
                        alignment: Alignment.topRight,
                        child: Icon(
                          Icons.close,
                          color: Colors.grey,
                          size: 20.0,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 5.0, bottom: 5.0),
                        color: Colors.white,
                        child: Text(
                            'Vous voulez recevoir votre code sur quelle adresse ?',
                            style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            )),
                      ),
                      Container(
                        height: 32,
                      ),
                      Expanded(
                        child: new MyDialogContent(contact.emails,
                            onchanged: onchanged), //Custom ListView
                      ),
                      SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: FlatButton(
                          color: Fonts.col_app_fon,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(20.0),
                              bottomRight: Radius.circular(20.0),
                            ),
                          ),
                          onPressed: () async {
                            print(email);

                            Navigator.pop(context);

                            var a = await parse_s
                                .getparse('users?where={"email":"$email"}');

                            if (a == "error" || a == "No") return;
                            setState(() {
                              load = false;
                            });

                            if (a["results"].length > 0) {
                              alert_login();
                            } else {
                              send_code(contact);
                            }
                          },
                          //color: AppColors.dialogTitleColor,
                          textColor: Colors.black,
                          child: Text(
                            "Envoyer le code",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w800),
                            // fontWeight: FontWeight.bold,
                            //fontSize: 16.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ))));
  }

  void _handleSubmitted(id, Contact contact) async {
    code = randomAlphaNumeric(4);

    if (contact.emails.length == 0) {
      email = contact.emails[0];
      send_code(contact);
    } else if (contact.emails.length == 1) {
      email = contact.emails[0];
      send_code(contact);
    } else {
      dialogContent(context, contact);
    }

    /* */
  }

  bool verify2 = false;

  goto_types() async {
    setState(() {
      verify = false;
      verify2 = false;
      _authHint = "";
    });
    // Navigator.pop(widget.context);
    type = await Navigator.push(context,
        new MaterialPageRoute(builder: (BuildContext context) {
          return new EntreproseListInscription(widget.email);
        }));
    setState(() {
      type_profile = type;
    });

    print("yessss");

    /* contacts =
        await Contacts_services.get_list_contacts_by_id_membre(type.objectId);
    setState(() {
      type_profile = type;
      print(contacts.length);

      if (contacts.length == 0) {
        setState(() {
          _authHint = "Aucun représentant trouvé !";
        });
      } else if (contacts.length == 1) {
        setState(() {
          verify2 = true;
          email = contacts[0].email;
          contactt = contacts[0];
          id = type_profile.objectId;
        });
      } else {
        email = contacts[0].email;
        id = type_profile.objectId;
        contactt = contacts[0];

        setState(() {
          verify = true;
        });
      }
    });*/
  }

  @override
  Widget build(BuildContext context) {
    Validators val = new Validators(context: context);

    /*  Widget organisme = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield(
            widget?.type == "Entreprise" ? "ICE" : "ICE/RNAE",
            _focusorganise,
            "",
            _organismecontroller,
            TextInputType.text,
            val.validateorganisme));*/

    gooo() async {
      var a = await parse_s.getparse('users?where={"email":"$email"}');

      if (a == "error" || a == "No") return;
      setState(() {
        load = false;
      });

      if (a["results"].length > 0) {
        alert_login();
      } else {
        ///  _handleSubmitted(id, contactt);
        ///  contact.new_membre= null;

        /// contact.email = email;
        Routes.goto(context, "register", null, null, [], null, widget.chng,
            id_ent: type_profile.objectId,
            contact: Contact(
                object_id: "",
                objectId: "",
                new_membre: false,
                name: "",
                email: widget.email,
                fonction: "",
                membre: type_profile));
      }
    }

    Widget titre = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Votre titre / Fonction", _focustitre, "",
            _titrecontroller, TextInputType.text, val.validatetitre));

    Widget company = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Raison sociale", _focusname, "",
            _namecontroller, TextInputType.text, val.validaten));

    Widget contact = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Email", _focuscontact, "", _contactcontroller,
            TextInputType.emailAddress, val.validatecont));

    var style = new TextStyle(
        color: const Color(0xffeff2f7),
        fontSize: 20.0,
        fontWeight: FontWeight.w500);
    var clr = Fonts.col_app_fon;

    Widget btn_log = new Padding(
        padding: new EdgeInsets.only(left: 36.0, right: 36.0),
        child: new Material(
            elevation: 12.0,
            shadowColor: clr,
            borderRadius: new BorderRadius.circular(12.0),
            color: clr,
            child: new MaterialButton(
              // color:  const Color(0xffa3bbf1),
                onPressed: () async {
                  print(email);

                  gooo();
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    load
                        ? new Container(
                        width: 26.0,
                        height: 26.0,
                        child: new CircularProgressIndicator(
                          valueColor: new AlwaysStoppedAnimation<Color>(
                              Colors.white),
                          strokeWidth: 2.0,
                        ))
                        : new Container(),
                    load
                        ? Container(
                      width: 8,
                    )
                        : Container(),
                    Container(),
                    new Text(LinkomTexts.of(context).confirm(), style: style)
                  ],
                ))));

    return Scaffold(
        key: _scaffoldKey,
        /* appBar: new AppBar(
          iconTheme: IconThemeData(color: Fonts.col_app_fon),
          backgroundColor: Fonts.col_app_shadow,
          title: new Text(
            "",
            style: TextStyle(color: Fonts.col_app_fon),
          ),
          elevation: 0.0,
        ),*/
        body: new Container(
            decoration: new BoxDecoration(
              color: Colors.grey[300],
              /* image: new DecorationImage(
                    fit: BoxFit.cover,
                    colorFilter: new ColorFilter.mode(
                        Colors.white.withOpacity(0.3), BlendMode.dstATop),
                    image: new AssetImage("images/back.jpg"))*/
            ),
            child: new Stack(fit: StackFit.expand, children: <Widget>[
              ListView(children: <Widget>[
                new Container(
                    height: 840.0,
                    child: new LoginBackground(
                      Widgets.kitGradients1,
                      widget: Padding(
                          padding: EdgeInsets.only(top: 8, bottom: 22),
                          child: Row(
                            children: [
                              Container(
                                  padding: EdgeInsets.all(22),
                                  child: GestureDetector(
                                    // color: Colors.white,
                                    child: Icon(
                                      Icons.arrow_back,
                                      color: Colors.white,
                                    ),
                                    onTap: () {
                                      Navigator.pop(context);
                                    },
                                  )),
                            ],
                          )),
                    ))
              ]),
              ListView(children: <Widget>[
                Column(children: <Widget>[
                  new Padding(
                      padding: new EdgeInsets.only(
                          top: 150.0, left: 18.0, right: 18.0, bottom: 18.0),
                      child: SizedBox(
                        //width: deviceSize.width * 0.98,
                          child: new Material(
                              color: Colors.white.withOpacity(0.95),
                              elevation: 20.0,
                              borderRadius: new BorderRadius.circular(6.0),
                              shadowColor: Fonts.col_app,
                              child: new Form(
                                  key: _formKey,
                                  autovalidate: _autovalidate,
                                  //onWillPop: _warnUserAboutInvalidData,
                                  child: new Column(
                                    //mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: <Widget>[
                                        new Container(height: 18.0),
                                        new Center(
                                            child: Widgets.subtitle5(
                                                Fonts.col_app_fonn,
                                                "Choisir votre organisme")),
                                        new Container(height: 32.0),
                                        hintText(),
                                        //   titre,
                                        Container(
                                          height: 12.0,
                                        ),

                                        Container(
                                          height: 12.0,
                                        ),
                                        tpe_profile(),
                                        Container(
                                          height: 12.0,
                                        ),
                                        /*Container(
                                            padding: EdgeInsets.only(
                                                left: 16.0, right: 16.0),
                                            child: RichText(
                                                textAlign: TextAlign.justify,
                                                text: new TextSpan(
                                                  text: "",
                                                  children: <TextSpan>[
                                                    new TextSpan(
                                                      text:
                                                          "Si vous n'avez pas trouvé votre entreprise sur la liste,  ",
                                                      style: TextStyle(
                                                          color:
                                                              Colors.grey[600],
                                                          fontSize: 16),
                                                    ),
                                                    new TextSpan(
                                                        text: //(dans une entreprise déjà inscrite au niveau de la plateforme)
                                                            "cliquez ici pour l'ajouter  ",
                                                        recognizer:
                                                            new TapGestureRecognizer()
                                                              ..onTap = () {
                                                                sub();
                                                              },
                                                        style: new TextStyle(
                                                            decoration:
                                                                TextDecoration
                                                                    .underline,
                                                            color: Colors.blue,
                                                            fontSize: 16.0,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500))
                                                  ],
                                                ))),*/

                                        /*verify == true || verify2 == true
                                            ? Text(
                                                "Est ce que vous êtes ",
                                                style: TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold),
                                              )
                                            : Container(),*/
                                        Container(
                                          height: 16,
                                        ),
                                        /*verify2
                                            ? Text(
                                                contacts[0].name,
                                                style: TextStyle(fontSize: 15),
                                              )
                                            : Container(),*/

                                        /*verify == true
                                            ? Container(
                                                height: MediaQuery.of(context)
                                                        .size
                                                        .height *
                                                    0.1,
                                                child: CupertinoPicker(
                                                    backgroundColor:
                                                        Colors.white,
                                                    itemExtent: 40,
                                                    onSelectedItemChanged:
                                                        (int i) {
                                                      setState(() {
                                                        print(contacts[i].name);

                                                        email =
                                                            contacts[i].email;
                                                        contactt = contacts[i];

                                                        id = type_profile
                                                            .objectId;

                                                        // selected = i;
                                                      });
                                                    },
                                                    looping: false,
                                                    children:
                                                        List<Contact>.from(
                                                                contacts)
                                                            .map((Contact
                                                                    cnt) =>
                                                                Text(cnt.name))
                                                            .toList()))
                                            : Container(),*/

                                        /*   yes_or ? company : Container(),
                                        yes_or
                                            ? new Container(
                                                height: 12.0,
                                              )
                                            : Container(),
                                        yes_or ? contact : Container(),
                                        yes_or
                                            ? new Container(
                                                height: 12.0,
                                              )
                                            : Container(),*/

                                        Container(
                                          height: 12,
                                        ),
                                        type_profile.toString() != "null"
                                            ? Container()
                                            : yes_or == true
                                            ? Container()
                                            : yes_or == true
                                            ? Container()
                                            : Container(
                                            padding:
                                            EdgeInsets.only(
                                                left: 16.0,
                                                right: 16.0),
                                            child: RichText(
                                                textAlign: TextAlign
                                                    .justify,
                                                text: new TextSpan(
                                                  text: "",
                                                  children: <
                                                      TextSpan>[
                                                    new TextSpan(
                                                      text:
                                                      "Si vous n'avez pas trouvé votre organisme sur la liste, ",
                                                      style: TextStyle(
                                                          color: Colors
                                                              .grey[
                                                          600],
                                                          fontSize:
                                                          16),
                                                    ),
                                                    new TextSpan(
                                                        text: //(dans une entreprise déjà inscrite au niveau de la plateforme)
                                                        "cliquez ici pour l'ajouter  ",
                                                        recognizer:
                                                        new TapGestureRecognizer()
                                                          ..onTap =
                                                              () {
                                                            sub();
                                                          },
                                                        style: new TextStyle(
                                                            decoration:
                                                            TextDecoration
                                                                .underline,
                                                            color: Colors
                                                                .blue,
                                                            fontSize:
                                                            16.0,
                                                            fontWeight:
                                                            FontWeight.w500))
                                                  ],
                                                ))),

                                        Container(
                                          height: 16,
                                        ),
                                        btn_log,
                                        new Container(
                                          height: 24.0,
                                        ),
                                      ])))))
                ])
              ])
            ])));
  }
}

class MyDialogContent extends StatefulWidget {
  MyDialogContent(this.items, {this.onchanged});

  List<String> items;
  var onchanged;

  @override
  _MyDialogContentState createState() => new _MyDialogContentState();
}

class _MyDialogContentState extends State<MyDialogContent> {
  List<CustomRowModel> sampleData = new List<CustomRowModel>();

  @override
  void initState() {
    super.initState();

    for (String item in widget.items) {
      sampleData.add(CustomRowModel(title: item, selected: false));
    }
    /*sampleData.add(CustomRowModel(title: "Marathi", selected: false));
    sampleData.add(CustomRowModel(title: "English", selected: false));
    sampleData.add(CustomRowModel(title: "Hindi", selected: false));
    sampleData.add(CustomRowModel(title: "Kannada", selected: false));
    sampleData.add(CustomRowModel(title: "Telugu", selected: false));
    sampleData.add(CustomRowModel(title: "Gujarathi", selected: false);
        sampleData.add(CustomRowModel(title: "Rajsthani", selected: false);
    sampleData.add(CustomRowModel(title: "Punjabi", selected: false));*/
  }

  @override
  Widget build(BuildContext context) {
    return sampleData.length == 0
        ? Container()
        : Container(
      child: ListView.separated(
        separatorBuilder: (context, index) => Divider(
          color: Colors.grey,
        ),
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: sampleData.length,
        itemBuilder: (BuildContext context, int index) {
          return new InkWell(
            //highlightColor: Colors.red,
            //splashColor: Colors.blueAccent,
            onTap: () {
              setState(() {
                sampleData.forEach((element) => element.selected = false);
                sampleData[index].selected = true;
              });
              widget.onchanged(sampleData[index].title);
            },
            child: new CustomRow(sampleData[index]),
          );
        },
      ),
    );
  }
}

class CustomRowModel {
  bool selected;
  String title;

  CustomRowModel({this.selected, this.title});
}

class CustomRow extends StatelessWidget {
  final CustomRowModel model;

  CustomRow(this.model);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
      const EdgeInsets.only(left: 8.0, right: 8.0, top: 3.0, bottom: 3.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
// I have used my own CustomText class to customise TextWidget.
          Text(
            model.title,
          ),
          this.model.selected
              ? Icon(
            Icons.radio_button_checked,
            color: Fonts.col_app,
          )
              : Icon(Icons.radio_button_unchecked),
        ],
      ),
    );
  }
}
