import 'package:intl/intl.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/region.dart';
import 'package:medz/models/sector.dart';
import 'package:medz/models/ville.dart';

class Membre {
  var objectId;
  String nadh;
  String ice;

  var status;
  String phone;

  ///pointer de type statuts

  List<Sector> sectors = [];
  var ville; //Pointer
  Region region; //Pointer
  String situation;
  String activities;

  var address = "";
  var createdDate = "";
  var description = "";
  var email = "";
  var name = "";
  var logo = "";
  String im;

  Commission federation;
  List<String> tels = [];
  List<String> emails = [];
  List<String> fax = [];
  int active = 1;

  bool liked = false;
  var numberlikes;
  bool wait = false;
  var cnt = "";
  bool begin = true;
  bool check = false;

  Membre({
    this.objectId,
    this.nadh,
    this.ice,
    this.status,
    this.ville,
    this.sectors,
    this.region,
    this.situation,
    this.tels,
    this.emails,
    this.fax,
    this.address,
    this.createdDate,
    this.federation,
    this.phone = "",
    this.activities,
    this.description,
    this.name,
    this.logo,
    this.email,
  });

  Membre.fromMap(Map<String, dynamic> document)
      : objectId = document["objectId"].toString(),
        nadh = document["nadh"].toString(),
        activities = document["activities"].toString() == "null"
            ? ""
            : document["activities"].toString(),
        ice = document["ice"].toString(),
        status = document["status"].toString(),
        sectors = document["sectors"].toString() == "null"
            ? []
            : List<Sector>.from(
                document["sectors"].map((val) => Sector.fromMap(val)).toList()),
        ville = document["ville"],
        region = document["region"].toString() == "null"
            ? null
            : new Region.fromMap(document["region"]),
        situation = document["situation"].toString(),
        tels = document["tels"].toString() == "null"
            ? []
            : List<String>.from(document["tels"]),
        emails = document["emails"].toString() == "null"
            ? []
            : List<String>.from(document["emails"]),
        fax = document["fax"].toString() == "null"
            ? []
            : List<String>.from(document["fax"]),
        address = document["address"].toString(),
        /*contacts = document["contacts"].toString() == "null"
            ? []
            : document["contacts"]
                .map((val) => new Contact.fromMap(val))
                .toList(),*/
        createdDate = document["createdDate"].toString(),
        federation = document["federation"].toString() == "null"
            ? null
            : new Commission.fromDoc(document["federation"]),
        description = document["description"].toString(),
        name = document["username"].toString(),
        im = document["logo"] == null
            ? "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565012657/placeholder_2_seeta8.png"
            : document["logo"],
        logo = document["imageUrl"] == null
            ? "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565012657/placeholder_2_seeta8.png"
            : document["imageUrl"].toString();
}

class Contact {
  var objectId;
  List<String> emails = [];
  var name = "";
  var nom = "";
  var prenom = "";
  String fonction;
  String email;
  Membre membre;
  bool new_membre;

  /// Pointer

  var logo = "";

  String organisme;
  var object_id; //for user non verifié

  Contact(
      {this.objectId,
      this.object_id,
      this.name,
      this.nom,
      this.new_membre,
      this.prenom,
      this.emails,
      this.fonction,
      this.membre,
      this.organisme,
      this.email});

  Contact.fromMap(Map<String, dynamic> document)
      : objectId = document["objectId"].toString(),
        name = document["name"],
        nom = document["nom"],
        fonction = document["fonction"].toString() == "null"
            ? ""
            : document["fonction"]["name"],
        prenom = document["prenom"],
        membre = document["membre"] == null
            ? null
            : Membre.fromMap(document["membre"]),
        emails = document["emails"].toString() == '[""]'
            ? []
            : List<String>.from(document["emails"]);
}
