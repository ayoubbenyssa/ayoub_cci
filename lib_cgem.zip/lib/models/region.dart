class Region {
  String id;
  String name;
  var num;
  bool check = false;

  Region(this.id, this.name, this.num);

  Region.fromMap(Map<String, dynamic> map)
      : id = map["objectId"],
        name = map["region"],
        check = false,
        num = map["num"];
}



class SSRegion {
  String id;
  String name;

  bool check = false;

  SSRegion(this.id, this.name);

  SSRegion.fromMap(Map<String, dynamic> map)
      : id = map["objectId"],
        name = map["name"],
        check = false;
}

