

class MyView{

  String name;
  String image;
  bool wait = false;
  var cnt = "";


  MyView(this.name,this.image);


}