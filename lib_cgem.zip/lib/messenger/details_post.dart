import 'package:flutter/material.dart';


class Details_post extends StatefulWidget {
  @override
  _Details_postState createState() => _Details_postState();
}

class _Details_postState extends State<Details_post> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
