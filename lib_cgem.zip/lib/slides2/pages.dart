import 'package:flutter/material.dart';
import 'package:medz/services/Fonts.dart';

/**
 * xImage.asset("images/logo.png",width: MediaQuery.of(context).size.width*0.15,)
 */
final pages = [
  new PageViewModel(
      Fonts.col_app,
      "images/logo.png",
      /* 100% dédiée à aux membres*/
      'Bienvenue sur MyCGEM !',
          "L'application de la communauté CGEM qui vous permet de vous connecter et de contacter d'autres membres par message, de partager votre actualité, de saisir de nouvelles opportunités d'affaires et de promouvoir vos produits et services !",
      "images/logo.png",
      'images/im1_b.jpeg'),
  new PageViewModel(
      Colors.blueGrey[900],
      'images/netw.png',
      'Networking',
      'Nous facilitons les interactions et les échanges entre opérateurs économiques dans l’objectif d’élargir votre réseau !',
      'images/netw.png',
      'images/netw.png'),
  new PageViewModel(
      // const Color(0xffd6a943),//0xFFd89d9d),
      Colors.teal[900],
      'images/cale.png',
      'Événements',
      "La CGEM organise régulièrement des conférences, rencontres et forums que vous retrouverez dans l'agenda et auxquels vous pourrez participer en complétant le formulaire d'inscription !",
      'images/cale.png',
      'images/cale.png'),
  new PageViewModel(
      // const Color(0xffd6a943),//0xFFd89d9d),
      Colors.indigo[800],
      'images/cost.png',
      "Opportunités d'affaires",
      "Nous facilitons l’interaction et les échanges au sein de la communauté CGEM, dans l’objectif de multiplier vos opportunités d'affaires !",
      'images/cost.png',
      'images/cost.png'),
];

class Page extends StatelessWidget {
  final PageViewModel viewModel;
  final double percentVisible;

  Page({
    this.viewModel,
    this.percentVisible = 1.0,
  });

  @override
  Widget build(BuildContext context) {
    return new Container(
        width: double.infinity,
        //color: viewModel.color,
        child: new Container(
          child:
              new Column(mainAxisAlignment: MainAxisAlignment.start, children: [
            Container(
              height: MediaQuery.of(context).size.height * 0.1,
            ),
            // logo,

            /*   new Center(
                    child:   new Text("....................................",
                            style: new  TextStyle(
                              color: Colors.blue[50],
                              fontSize: 22.0,
                              fontWeight: FontWeight.w800,
                              fontFamily: "RapidinhoFontFamily",
                            ))),*/
            //new Container(height: 8.0,),
            new Transform(
                transform: new Matrix4.translationValues(
                    0.0, 50.0 * (1.0 - percentVisible), 0.0),
                child: new Container(
                    width: 120.0,
                    height: 120.0,
                    padding: new EdgeInsets.all(4.0),
                    child: new Material(
                      color: const Color(0xfff4f5f6),
                      type: MaterialType.circle,
                      shadowColor: Colors.black,
                      elevation: 8.0,
                      child: new Padding(
                        padding: new EdgeInsets.all(12.0),
                        child: new Image.asset(viewModel.heroAssetPath,
                            width: 90.0, height: 90.0),
                      ),
                    ))),
            new Container(height: 12.0),

            new Padding(
              padding: new EdgeInsets.only(
                  top: 12.0, bottom: 4.0, left: 8.0, right: 8.0),
              child: new Text(
                viewModel.title,
                textAlign: TextAlign.center,
                style: new TextStyle(
                  //color: Colors.white,
                  color: Fonts.col_app,
                  fontWeight: FontWeight.bold,
                  fontSize: 20.0,
                ),
              ),
            ),

            Container(
              height: 12.0,
            ),

            new Padding(
                padding:
                    new EdgeInsets.only(bottom: 4.0, left: 24.0, right: 24.0),
                child: new Text(
                  viewModel.body,
                  textAlign: TextAlign.justify,
                  style: new TextStyle(
                      color: Colors.grey[900],
                      fontWeight: FontWeight.w500,
                      height: 1.1,
                      //  color: Colors.white,
                      fontSize: 16.0),
                )),

            new Container(height: 100.0),
          ]),
        ));
  }
}

class PageViewModel {
  final Color color;
  final String heroAssetPath;
  final String title;
  final String body;
  final String iconAssetPath;
  final String background;

  PageViewModel(this.color, this.heroAssetPath, this.title, this.body,
      this.iconAssetPath, this.background);
}
