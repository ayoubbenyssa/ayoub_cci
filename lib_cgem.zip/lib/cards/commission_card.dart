import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:medz/cards/details_partner.dart';
import 'package:medz/cards/like_partner_button.dart';
import 'package:medz/filter/commissions_users.dart';
import 'package:medz/filter/federations_users.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';

class Commission_card_search extends StatefulWidget {
  Commission_card_search(
      this.commission, this.user, this.lat, this.lng, this.chng,
      {this.type});

  Commission commission;
  User user;

  var lat;
  var lng;
  var chng;
  String type;

  @override
  _Commission_card_search_cardState createState() =>
      _Commission_card_search_cardState();
}

class _Commission_card_search_cardState extends State<Commission_card_search> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: () {
          print(widget.type);

          if (widget.type == "commission")
            Navigator.push(context,
                new MaterialPageRoute(builder: (BuildContext context) {
              return new FilterByCommissionsUsers(widget.commission,
                  widget.user, widget.lat, widget.lng, [], null, widget.chng);
            }));
          else
            Navigator.push(context,
                new MaterialPageRoute(builder: (BuildContext context) {
              return new FilterByFederationUsers(widget.commission, widget.user,
                  widget.lat, widget.lng, [], null, widget.chng);
            }));
          /**
           * FilterByCommissionsUsers(this.commission,this.user, this.lat, this.lng, this.list_partner, this.analytics,
              this.chng)
           */
        },
        child: Container(
            padding: new EdgeInsets.all(4.0),
            child: Material(
                elevation: 0.0,
                borderRadius: new BorderRadius.circular(8.0),
                child: Container(
                  padding: EdgeInsets.all(4),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          color: Colors.grey[50],
                          child: ClipRRect(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(8)),
                              child: widget.commission.img.toString() == "null"
                                  ? Container()
                                  : FadingImage.network(
                                      widget.commission.img,
                                      fit: BoxFit.contain,
                                    )),
                          width: 80,
                          height: 80,
                        ),
                        Container(
                          width: 12,
                        ),
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.6,
                                  child: Text(
                                    widget.commission.name,
                                    maxLines: 3,
                                    style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        height: 1.4,
                                        fontSize: 19.5),
                                  )),
                              Container(
                                height: 4,
                              ),
                             /* Container(
                                width: MediaQuery.of(context).size.width * 0.55,
                                child: widget.type == "commission"
                                    ? Text(
                                        widget.commission.description
                                                    .toString() ==
                                                "null"
                                            ? ""
                                            : widget.commission.description,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontFamily: "ralway",
                                          color: Colors.grey,
                                          fontSize: 14.0,
                                        ),
                                      )
                                    : Container(),
                              ),*/
                            ]),
                        Expanded(
                          child: Container(),
                        ),
                        Container(
                          width: 10,
                        ),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 20,
                          color: Colors.grey[400],
                        ),
                        Container(
                          width: 10,
                        ),
                      ]),
                ))));
  }
}
