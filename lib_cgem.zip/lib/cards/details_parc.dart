import 'dart:async';
import 'dart:io';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:medz/cards/details_partner.dart';
import 'package:medz/cards/like_widget.dart';
import 'package:medz/chat/chatscreen.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/youtube_service.dart';
import 'package:medz/widgets/common.dart';
import 'package:medz/widgets/image_widget.dart';
import 'package:medz/widgets/youtube_widget.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:timeago/timeago.dart' as ta;

class DetailsParc extends StatefulWidget {
  DetailsParc(this.offer, this.user, this.tpe, this.listp, this.auth,
      this.analytics, this.onLocaleChange, this.lat, this.lng);

  Offers offer;
  User user;
  var tpe;
  var listp;
  var auth;
  var analytics;
  var onLocaleChange;
  var lat;
  var lng;

  @override
  _ShopCardState createState() => _ShopCardState();
}

class _ShopCardState extends State<DetailsParc> {
  ParseServer parseFunctions = new ParseServer();

  String link_img = "", link_title = "";

  getLink() {
    GetLinkData.getLink(widget.offer.urlVideo).then((vall) {
      setState(() {
        link_img = vall["image"];
        link_title = vall["title"];
      });
    });
  }

  @override
  void initState() {
    parseFunctions.putparse(
        "offers/" + widget.offer.objectId, {"count": widget.offer.count + 1});
   // getLink();

    print("yesjsjs");
    print(widget.offer.dis);


    super.initState();
  }
  func_update_likes(i) {
    setState(() {
      widget.offer.likes_post =
          (int.parse(widget.offer.likes_post) + i).toString();
    });
  }

  void onLoading(context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        child: new Dialog(
          child: new Container(
            padding: new EdgeInsets.all(16.0),
            width: 40.0,
            color: Colors.transparent,
            child: new Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                new RefreshProgressIndicator(),
                new Container(height: 8.0),
                new Text(
                  "En cours ..",
                  style: new TextStyle(
                    color: Fonts.col_app_fonn,
                  ),
                ),
              ],
            ),
          ),
        ));

    // Navigator.pop(context); //pop dialog
    //  _handleSubmitted();
  }

  confirmer(my_id, his_id, user_me, user) async {
    // widget.delete();

    onLoading(context);

    DatabaseReference gMessagesDbRef2 = FirebaseDatabase.instance
        .reference()
        .child("room_medz")
        .child(my_id + "_" + his_id);
    Navigator.of(context, rootNavigator: true).pop('dialog');

    Navigator.push(context,
        new MaterialPageRoute(builder: (BuildContext context) {
      return new ChatScreen(my_id, his_id, widget.listp, false, widget.auth,
          widget.analytics, widget.onLocaleChange,
          user: user_me);
    }));
  }

  //For ùaking a call
  Future _launched;

  Future _launch(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  gotomap() {
    var lat = widget.offer.latLng.toString().split(";")[0];
    var lng = widget.offer.latLng.toString().split(";")[1];
    _launched = _launch('https://www.google.com/maps/@$lat,$lng,16z');
  }

  void playYoutubeVideo() {
    Navigator.push(context,
        new MaterialPageRoute<String>(builder: (BuildContext context) {
      return new WebviewScaffold(
        url: widget.offer.urlVideo,
        appBar: new AppBar(
          title: new Text(""),
        ),
      );
    }));
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.instance = ScreenUtil(width: 750, height: 1334)..init(context);

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: new AppBar(),
      body: new ListView(
        children: <Widget>[
          ImageWidget(widget.offer.pic),
          Container(
            color: Fonts.col_cl,
            child: new Container(
                color: Fonts.col_cl,
                padding: new EdgeInsets.all(16.0),
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    InkWell(
                        onTap: () {
                          Navigator.push(context, new MaterialPageRoute(
                              builder: (BuildContext context) {
                            return new PartnerCardDetails(
                                widget.offer.partner,
                                widget.lat,
                                widget.lng,
                                widget.user,
                                widget.onLocaleChange);
                          }));
                        },
                        child: new ClipOval(
                            child: new Container(
                                color: Fonts.col_app,
                                width: MediaQuery.of(context).size.width * 0.12,
                                height:
                                    MediaQuery.of(context).size.width * 0.12,
                                child: new Center(
                                    child: FadingImage.network(
                                  widget.offer.partner.logo,
                                  width:
                                      MediaQuery.of(context).size.width * 0.12,
                                  height:
                                      MediaQuery.of(context).size.width * 0.12,
                                  fit: BoxFit.cover,
                                ))))),
                    new Container(
                      width: 8.0,
                    ),
                    new Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                            width: MediaQuery.of(context).size.width * 0.63,
                            child: new Text(widget.offer.partner.name,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: new TextStyle(
                                    color: Colors.grey[800],
                                    fontWeight: FontWeight.w600,
                                    fontSize:
                                        ScreenUtil.getInstance().setSp(32)))),
                        new Container(height: 0.0),
                        ScopedModelDescendant<AppModel1>(
                            builder: (context, child, model) =>
                                widget.offer.sponsorise != 1
                                    ? new Text(
                                        ta.format(widget.offer.create,
                                            locale: model.locale == "ar"
                                                ? "ar"
                                                : "fr"),
                                        style: new TextStyle(
                                            color: Fonts.col_grey,
                                            //  fontWeight: FontWeight.bold,
                                            fontSize: ScreenUtil.getInstance()
                                                .setSp(28)),
                                      )
                                    : Row(
                                        children: <Widget>[
                                          Text(
                                            "Sponsorisé",
                                            style: TextStyle(
                                                color: Fonts.col_grey,
                                                fontSize:
                                                    ScreenUtil.getInstance()
                                                        .setSp(28),
                                                fontWeight: FontWeight.w600),
                                          ),
                                          Container(
                                            width: 4,
                                          ),
                                          Image.asset(
                                            "images/spon.png",
                                            color: Fonts.col_grey,
                                            width: 18,
                                            height: 18,
                                          )
                                        ],
                                      )),
                      ],
                    ),
                    new Expanded(child: new Container()),
                    widget.tpe != "1"
                        ? new Container(
                            child: new FavoriteButton(
                            widget.offer,
                            widget.user,
                            true,
                            func_update_likes,
                          ))
                        : new Container(),
                    Container(
                      width: 4,
                    )
                    /*  ButtonWidget(widget.offer, widget.user, ratefunc,
                        widget.lat, widget.lng, widget.onLocaleChange)*/
                  ],
                )),
          ),
          Container(
            height: 8,
          ),
          widget.offer.type == "event"
              ? new Container(
                  padding: new EdgeInsets.only(
                      top: 6.0, bottom: 6.0, left: 16.0, right: 16.0),
                  width: width * 0.64,
                  child: new Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[(widget.offer.dis ==
                         "-.- Km" || widget.offer.dis =="" )?Container():    new GestureDetector(
                          onTap: () {
                            gotomap();
                          },
                          child: new Container(
                              //padding: new EdgeInsets.only(left: 2.0,bottom: 2.0,top: 2.0,right: 2.0),
                              //  width: 150.0,
                              //alignment: Alignment.center,
                              decoration: new BoxDecoration(
                                border: new Border.all(
                                    color: Colors.blue, width: 0.5),
                                color: Colors.transparent,
                                borderRadius: new BorderRadius.circular(4.0),
                              ),
                              child: new Row(
                                children: <Widget>[
                                  new Icon(Icons.directions,
                                      color: Colors.blue[600], size: 12.0),
                                  new Container(
                                    width: 4.0,
                                  ),
                                  new Text(
                                    "Itinéraire",
                                    style: new TextStyle(
                                        color: Colors.blue, fontSize: 11.5),
                                  )
                                ],
                              ))),
                      new Container(
                        width: 4.0,
                      ),
                      new GestureDetector(
                          onTap: () {
                            gotomap();
                          },
                          child: new Text(widget.offer.dis.toString(),
                              style: new TextStyle(
                                  color: Colors.grey[600],
                                  fontWeight: FontWeight.w500,
                                  fontSize: 11.0))),
                      // new Container(width: height*0.05),
                    ],
                  ),
                )
              : Container(),
          new Container(
            padding: new EdgeInsets.only(left: 16.0, right: 16.0),
            child: Text(
              widget.offer.name,
              style: new TextStyle(
                  color: Colors.blueGrey[800], fontWeight: FontWeight.bold),
            ),
          ),
          new Container(height: 8.0),
          link_title == ""
              ? Container()
              : YoutubeWidget(link_title, link_img, widget.offer.urlVideo,
                  playYoutubeVideo),
          /*GestureDetector(
              onTap: () {
                print("dhidhid");
                playYoutubeVideo();

              },
              child: new Container(
                padding: EdgeInsets.only(left: 8.0,right: 8.0),
                  width: width * 0.63,
                  child: new Text(
                      widget.offer.urlVideo == ""
                          ? ""
                          : widget.offer.urlVideo,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: new TextStyle(
                          color: Colors.blue,
                          decoration: TextDecoration.underline))
              )),*/
          new Container(
              padding: new EdgeInsets.only(left: 16.0, right: 16.0),
              child: HtmlWidget(
                widget.offer.description
                    .toString()
                    .replaceAll(RegExp(r'(\\n)+'), ''),
              )),
          InkWell(
            onTap: () {
              if (Platform.isIOS)
                Navigator.push(context, new MaterialPageRoute<String>(
                    builder: (BuildContext context) {
                  return new WebviewScaffold(
                    url: widget.offer.docUrl,
                    appBar: new AppBar(
                      title: new Text(""),
                    ),
                  );
                }));
            },
            child: Row(
              children: <Widget>[
                widget.offer.docUrl.toString() == "null" ||
                        widget.offer.docUrl == ""
                    ? Container()
                    : IconButton(
                        iconSize: 42,
                        icon: CircleAvatar(
                            radius: 28,
                            backgroundColor: Colors.blue[500],
                            child: Padding(
                                padding: EdgeInsets.all(8),
                                child: Image.asset(
                                  "images/pdf.png",
                                  color: Colors.white,
                                  width: 28,
                                  height: 28,
                                ))),
                        onPressed: () {
                          if (Platform.isIOS)
                            Navigator.push(context,
                                new MaterialPageRoute<String>(
                                    builder: (BuildContext context) {
                              return new WebviewScaffold(
                                url: widget.offer.docUrl,
                                appBar: new AppBar(
                                  title: new Text(""),
                                ),
                              );
                            }));
                        },
                      ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
