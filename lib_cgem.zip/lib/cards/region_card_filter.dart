import 'package:flutter/material.dart';
import 'package:medz/filter/region_users.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/region.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';

class Region_card_filter extends StatefulWidget {
  Region_card_filter(
      this.region, this.user, this.lat, this.lng, this.chng, this.reg);

  Region region;
  User user;
  double lat;
  double lng;
  bool reg;
  var chng;

  @override
  _Entreprise_cardState createState() => _Entreprise_cardState();
}

class _Entreprise_cardState extends State<Region_card_filter> {
  List<String> st = [];

  var load = true;

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: () {
          if (widget.reg == true)
            Navigator.push(context,
                new MaterialPageRoute(builder: (BuildContext context) {
              return new FilterByRegionsUsers(widget.region, widget.user,
                  widget.lat, widget.lng, [], null, widget.chng);
            }));
        },
        child: Card(
          child: Container(
            child: ListTile(
              title: Text(
                widget.region.name,
                maxLines: 2,
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              trailing: widget.reg == true
                  ? Icon(
                      Icons.arrow_forward_ios,
                      size: 20,
                      color: Colors.grey[400],
                    )
                  : Container(width: 0,height: 0,),
            ),
          ),
        ));
  }
}
