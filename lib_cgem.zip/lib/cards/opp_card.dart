import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:intl/intl.dart';
import 'package:medz/annonces/details_annonce.dart';
import 'package:medz/cards/details_parc.dart';
import 'package:medz/cards/details_partner.dart';
import 'package:medz/cards/header_card.dart';
import 'package:medz/fils_actualit/card_footer.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/block.dart';
import 'package:medz/widgets/common.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:timeago/timeago.dart' as ta;
import 'package:video_player/video_player.dart';

class OppCard extends StatefulWidget {
  OppCard(this.offer, this.user, this.lat, this.lng, this.context, this.bl,
      this.chng);

  Offers offer;
  User user;
  var listp;
  var auth;
  var analytics;
  var context;
  var lat;
  var lng;
  var bl;
  var chng;

  @override
  _ParcPubCardState createState() => _ParcPubCardState();
}

class _ParcPubCardState extends State<OppCard> {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.instance = ScreenUtil(width: 750, height: 1334)..init(context);

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    //For ùaking a call
    Future _launched;

    Future _launch(String url) async {
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
    }

    gotomap() {
      var lat = widget.offer.latLng.toString().split(";")[0];
      var lng = widget.offer.latLng.toString().split(";")[1];
      _launched = _launch('https://www.google.com/maps/@$lat,$lng,16z');
    }

    block_user() async {
      await Block.insert_block(
          widget.user.auth_id,
          widget.offer.author1.auth_id,
          widget.user.id,
          widget.offer.author1.id);
      await Block.insert_block(widget.offer.author1.auth_id,
          widget.user.auth_id, widget.offer.author1.id, widget.user.id);

      setState(() {
        widget.user.show = false;
      });
    }

    ratefunc() {}

    Widget op = Container(
      padding: new EdgeInsets.only(left:8.0,right: 8,top: 8),
      child: Material(
        elevation: 2,
        borderRadius: BorderRadius.all(Radius.circular(18)),
        child: Container(
          // height: ScreenUtil.getInstance().setHeight(236.0),

          child: ClipRRect(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            child: Column(
              children: <Widget>[
                HeaderCard(widget.offer, widget.user, widget.lat, widget.lng,
                    widget.chng, block_user, ratefunc),
                InkWell(
                    onTap: () {
                      if (widget.bl == false)
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new OppCard(
                              widget.offer,
                              widget.user,
                              widget.lat,
                              widget.lng,
                              context,
                              true,
                              widget.chng);
                        }));
                    },
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          flex: 1,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 0, horizontal: 16),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: <Widget>[
                                Container(
                                  height: 4,
                                ),
                                /**
                                    Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                    widget.offer.type_offre_or_demande
                                    .toString() ==
                                    "null"
                                    ? Container()
                                    : Container(
                                    padding: EdgeInsets.all(6),
                                    decoration: new BoxDecoration(
                                    color: widget.offer.type_offre_or_demande ==
                                    "Offre"
                                    ? Fonts.col_app.withOpacity(0.1)
                                    : Fonts.col_gr.withOpacity(0.1),
                                    border: new Border.all(
                                    color: widget.offer.type_offre_or_demande ==
                                    "Offre"
                                    ? Fonts.col_app
                                    : Fonts.col_gr,
                                    width: 1.5),
                                    borderRadius:
                                    new BorderRadius.circular(
                                    8.0),
                                    ),
                                    child: Text(
                                    widget.offer.type_offre_or_demande
                                    .toString() ==
                                    "null"
                                    ? ""
                                    : widget.offer
                                    .type_offre_or_demande
                                    .toString(),
                                    style: Theme.of(context)
                                    .textTheme
                                    .display2
                                    .copyWith(
                                    fontSize: 16,
                                    color: Fonts.col_app_fonn,
                                    fontWeight:
                                    FontWeight.w700,
                                    height: 1.2),
                                    ))
                                    ],
                                    ),
                                 */
                                Text(
                                  widget.offer.name,
                                  maxLines: 2,
                                  style: Theme.of(context)
                                      .textTheme
                                      .display2
                                      .copyWith(
                                          fontSize: 14,
                                          color: Fonts.col_app_fonn,
                                          fontWeight: FontWeight.w700,
                                          height: 1.2),
                                ),
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  children: <Widget>[
                                    Text(
                                      LinkomTexts.of(context).typ() + ": ",
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 16,
                                              color: Colors.grey[800],
                                              fontWeight: FontWeight.w700,
                                              height: 1.2),
                                    ),
                                    Container(
                                      width: 8,
                                    ),
                                    Text(
                                      widget.offer.type_op == "RC"
                                          ? "Recherche de collaboration"
                                          : widget.offer.type_op,
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 16,
                                              color: Colors.blue,
                                              fontWeight: FontWeight.w700,
                                              height: 1.2),
                                    ),
                                  ],
                                ),
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  children: <Widget>[
                                    Text(
                                      LinkomTexts.of(context).valid() + ":  ",
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 14,
                                              color: Colors.black,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2),
                                    ),
                                    Text(
                                      new DateFormat('dd-MM-yyyy')
                                          .format(widget.offer.create),
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 14,
                                              color: const Color(0xffff374e),
                                              fontWeight: FontWeight.w600,
                                              height: 1.2),
                                    ),
                                  ],
                                ),
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: Colors.blue[50],
                                        borderRadius:
                                            BorderRadius.circular(6.0),
                                      ),
                                      child: Row(
                                        children: <Widget>[
                                          Text(
                                            LinkomTexts.of(context).budget() +
                                                ":  ",
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .display2
                                                .copyWith(
                                                    fontSize: 14,
                                                    color: Colors.black,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2),
                                          ),
                                          Text(
                                            widget.offer.budget.toString() ==
                                                    "null"
                                                ? "0 Dhs"
                                                : widget.offer.budget + " Dhs",
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .display2
                                                .copyWith(
                                                    fontSize: 14,
                                                    color: Colors.amber[700],
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Container(),
                                    ),
                                  ],
                                ),
                                Container(
                                  height: 8,
                                ),
                                /* HtmlWidget(
                                  widget.bl == true
                                      ? widget.offer.description == ""
                                          ? "----Aucune description ----"
                                          : widget.offer.description
                                      : widget.offer.description == ""
                                          ? "----Aucune description ----"
                                          : widget.offer.description.length <
                                                  270
                                              ? widget.offer.description
                                              : widget.offer.description
                                                      .substring(0, 270) +
                                                  "..",
                                ),*/
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    widget.bl == false
                                        ? InkWell(
                                            child: Text(
                                              LinkomTexts.of(context)
                                                      .details() +
                                                  " ..",
                                              style: TextStyle(
                                                  color: Fonts.col_app,
                                                  fontWeight: FontWeight.w800,
                                                  decoration:
                                                      TextDecoration.underline,
                                                  fontSize: 16),
                                            ),
                                          )
                                        : Container(),
                                  ],
                                ),
                                /*
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Colors.grey),
                             */

                                /*
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Colors.grey),
                             */
                                Container(
                                  height: 12.0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    )),
                CardFooter(widget.offer, widget.user, null, context,
                    widget.listp, null, widget.lat, widget.lng, widget.chng)
              ],
            ),
          ),
        ),
      ),
    );

    return widget.bl == true
        ? Scaffold(
            appBar: AppBar(
              backgroundColor: Fonts.col_app_shadow,
              elevation: 1,
              title: Text(
                widget.offer.name,
                style: TextStyle(color: Fonts.col_app_fonn, fontSize: 14),
              ),
            ),
            body: op,
          )
        : op;
  }
}
