import 'dart:async';
import 'package:flutter/material.dart';
import 'package:medz/co_voiturage/add_covoiturage.dart';
import 'package:medz/co_voiturage/profile/user_profile.dart';
import 'package:medz/co_voiturage/search/search_form.dart';
import 'package:medz/models/user.dart';
import 'package:medz/parc_events_stream/parc_events_stream.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/teeeeest.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Covoiturage extends StatefulWidget {
  Covoiturage(this.user, this.auth, this.sign, this.lat, this.lng,
      this.list_partner, this.analytics, this.post_id, this.chng);

  User user;
  var auth;
  var sign;
  var lat;
  var lng;
  var analytics;
  var observer;
  List list_partner;
  var chng;
  String post_id;

  @override
  _CovoiturageState createState() => _CovoiturageState();
}

class _CovoiturageState extends State<Covoiturage>
    with TickerProviderStateMixin {
  AnimationController animationController;
  bool _menuShown = false;
  int _counter = 0;
  var add;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  bool loading = false;
  int count1 = 0;
  int count2 = 0;

  setSount1(c) {
    setState(() {
      count1 = c;
    });
  }

  setSount2(c) {
    setState(() {
      count2 = c;
    });
  }

  Reload() {
    setState(() {
      loading = true;
    });
    // getRequestLIst();
    new Timer(const Duration(seconds: 1), () {
      try {
        setState(() => loading = false);
      } catch (e) {
        e.toString();
      }
    });
  }

  // A modifier

  goto_add() {
    Navigator.push(context,
        new MaterialPageRoute(builder: (BuildContext context) {
      return new AddCov(widget.user, widget.auth, widget.sign,
          widget.list_partner, Reload, add, widget.post_id);
    }));
  }

  gotoposts() {
    Navigator.push(context,
        new MaterialPageRoute(builder: (BuildContext context) {
      return new UserProfile(
        widget.user,
        widget.user,
        widget.auth,
        widget.sign,
        widget.lat,
        widget.lng,
        true,
        widget.list_partner,
        widget.analytics,
        false,
        widget.chng,
      );
    }));
  }

  display_slides() async {
    //Restez informés sur  tout ce qui se passe au sein de votre communauté à travers l’actualité et les événements.
    SharedPreferences prefs = await SharedPreferences.getInstance();

    if (prefs.getString("cov") != "cov") {
      new Timer(new Duration(seconds: 1), () {
        setState(() {
          _menuShown = true;
        });

        prefs.setString("cov", "cov");
      });
    }
  }

  @override
  void initState() {
    animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    // TODO: implement initState
    super.initState();
    display_slides();
  }

  onp() {
    setState(() {
      _menuShown = false;
    });
  }

  @override
  Widget build(BuildContext context) {

    Animation opacityAnimation =
        Tween(begin: 0.0, end: 1.0).animate(animationController);
    if (_menuShown)
      animationController.forward();
    else
      animationController.reverse();

    row(name, icon, tap, wid, he, selec) => new ListTile(
        onTap: () {
          if (name == "Depuis l'évènement") {
            add = true;
          } else if (name == "Vers l'évènement") {
            add = false;
          }
          tap();
        },
        title: Row(children: [
          Image.asset(
            icon,
            width: wid,
            height: he,
            color: Colors.blue[600],
          ),
          Container(
            width: 16.0,
          ),
          new Text(
            name,
            style: TextStyle(fontSize: 14.5),
          )
        ]));

    cov() {
      //Navigator.pop(context);

      showDialog(
          context: context,
          barrierDismissible: true,
          child: new Dialog(
              child: new Container(
                  height: 252.0,
                  // width: MediaQuery.of(context).size.width,
                  child: new Container(
                      // padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                      child: new Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                        Container(
                          height: 16,
                        ),
                        Center(
                            child: Text("Publier un covoiturage:",
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700))),
                        Container(
                          height: 16,
                        ),
                        row("Depuis l'évènement", "images/from.png", goto_add,
                            26.0, 26.0, ""),
                        Container(
                          height: 1,
                          width: 250,
                          color: Colors.grey[300],
                        ),
                        row("Vers l'évènement", "images/from.png", goto_add,
                            26.0, 26.0, ""),
                        Container(
                          height: 1,
                          width: 250,
                          color: Colors.grey[300],
                        ),
                      ])))));
    }


    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Fonts.col_app_shadow,
        iconTheme: IconThemeData(color: Fonts.col_app_fonn),
        title: new Text(
          count1 == 0
              ? "Co-voiturage"
              : "Co-voiturage" + ' (' + count1.toString() + ')',
          style: TextStyle(color: Fonts.col_app_fonn),
        ),
      ),
      body: Stack(children: <Widget>[
        loading
            ? Widgets.load()
            : new StreamParcPub(
                new Container(),
                widget.lat,
                widget.lng,
                widget.user,
                "0",
                widget.list_partner,
                widget.analytics,
                setSount1,
                widget.chng,
                favorite: false,
                revue: false,
                video: false,
                boutique: false,
                idp: widget.post_id,
                //idpost: widget.post_id,
                category: "cov",
              ),
        _menuShown == false
            ? Container()
            : Positioned(
                child: FadeTransition(
                  opacity: opacityAnimation,
                  child: ShapedWidget(
                      "Proposer des places dans votre véhicule. Une autre façon de rencontrer des personnes."
                      " Idéal pour partager les frais d’essence et rendre le trajet plus agréable.",
                      onp,
                      180.0),
                ),
                right: 12.0,
                top: 86.0,
              ),
      ]),

    );
  }
}
