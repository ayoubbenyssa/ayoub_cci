import 'dart:async';

import 'package:flutter/services.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:latlong/latlong.dart';
import 'package:medz/chat/chatscreen.dart';
import 'package:medz/co_voiturage/add_covoiturage.dart';
import 'package:medz/co_voiturage/alert_rate.dart';
import 'package:medz/co_voiturage/comments/comments.dart';
import 'package:medz/co_voiturage/covoiturages.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/block.dart';
import 'package:medz/user/details_user.dart';
import 'package:timeago/timeago.dart' as ta;
import 'package:url_launcher/url_launcher.dart';

class Cov_Card extends StatefulWidget {
  Cov_Card(this.cov, this.user, this.analytics, this.observer,
      this.list_partner, this.show, this.idpost, this.chng,
      {this.auth, this.sign, this.lat, this.lng});

  Offers cov;
  User user;
  var auth;
  var sign;
  var lat;
  var lng;
  var analytics;
  var observer;
  List list_partner;
  bool show = false;
  var idpost;
  var chng;

  @override
  _Cov_CardState createState() => _Cov_CardState();
}

class _Cov_CardState extends State<Cov_Card> {
  String _platformVersion = 'Unknown';

  // Platform messages are asynchronous, so we initialize in an async method.

  Distance distance = new Distance();

  @override
  void initState() {
    widget.cov.delete = false;
    if (widget.cov.latLng.isEmpty) {
      widget.cov.dis = "-.- Km";
    } else {
      if (widget.cov.latLng.split(";")[0].toString() == "null") {
        widget.cov.dis = "-.- Km";
      } else {
        widget.cov.dis = distance
                .as(
                    LengthUnit.Kilometer,
                    new LatLng(double.parse(widget.cov.latLng.split(";")[0]),
                        double.parse(widget.cov.latLng.split(";")[1])),
                    new LatLng(widget.lat, widget.lng))
                .toString() +
            " Km(s)";
      }
    }
  }

  Offers cov;

  func() {
    setState(() {
      widget.cov = cov;
    });
  }

  void onLoading(context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        child: new Dialog(
          child: new Container(
            padding: new EdgeInsets.all(16.0),
            width: 40.0,
            color: Colors.transparent,
            child: new Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                new RefreshProgressIndicator(),
                new Container(height: 8.0),
                new Text(
                  "En cours ..",
                  style: new TextStyle(
                    color: Fonts.col_app_fonn,
                  ),
                ),
              ],
            ),
          ),
        ));

    // Navigator.pop(context); //pop dialog
    //  _handleSubmitted();
  }

  //For ùaking a call
  Future _launched;

  Future _launch(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }



  confirmer(my_id, his_id, user_me, user) async {
    // widget.delete();

    onLoading(context);
    Navigator.of(context, rootNavigator: true).pop('dialog');

    Navigator.push(context,
        new MaterialPageRoute(builder: (BuildContext context) {
      return new ChatScreen(my_id, his_id, widget.list_partner, false,
          widget.auth, widget.analytics, widget.chng,
          user: user_me);
    }));
  }

  ParseServer parse_s = new ParseServer();

  delete_post() async {
    await parse_s.deleteparse("offers/" + widget.cov.objectId);
    setState(() {
      widget.cov.delete = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    _buildRatingBar() {
      return new Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          new GestureDetector(
            child: new Icon(
              Icons.star,
              size: 14.0,
              color: widget.cov.rating >= 1 ? Colors.orange : Colors.grey,
            ),
            onTap: () => null,
          ),
          new GestureDetector(
            child: new Icon(
              Icons.star,
              size: 14.0,
              color: widget.cov.rating >= 2 ? Colors.orange : Colors.grey,
            ),
            onTap: () => null,
          ),
          new GestureDetector(
            child: new Icon(
              Icons.star,
              size: 14.0,
              color: widget.cov.rating >= 3 ? Colors.orange : Colors.grey,
            ),
            onTap: () => null,
          ),
          new GestureDetector(
            child: new Icon(
              Icons.star,
              size: 14.0,
              color: widget.cov.rating >= 4 ? Colors.orange : Colors.grey,
            ),
            onTap: () => null,
          ),
          new GestureDetector(
            child: new Icon(
              Icons.star,
              size: 14.0,
              color: widget.cov.rating >= 5 ? Colors.orange : Colors.grey,
            ),
            onTap: () => null,
          )
        ],
      );
    }

    Widget spons = SizedBox(
        height: 20.0,
        width: 100.0,
        child: new Center(
            child: ColorizeAnimatedTextKit(
          text: [
            "Sponsorisé",
          ],
          textStyle: TextStyle(
            fontSize: 12.0,
          ),
          colors: [
            Colors.pink,
            Colors.blue,
            Colors.yellow[400],
            Colors.blue[700],
          ],
        )));

    Widget rw(text, text2, im) => new Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            new Container(width: 4.0),
            new Image.asset(
              im,
              width: 14.0,
              height: 14.0,
            ),
            new Container(width: 8.0),
            new Text(
              text2,
              style: new TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.w600,
                  fontSize: 10.0),
            ),
            new Container(width: 4.0),
            new Text(
              text,
              style: new TextStyle(
                  color: Colors.blueGrey[700],
                  fontWeight: FontWeight.w500,
                  fontSize: 11.0),
            ),
            new Container(
              width: 2.0,
            ),
          ],
        );

    fu() {
      setState(() {
        widget.cov.numbercommenttext =
            (int.parse(widget.cov.numbercommenttext) + 1).toString();
      });
    }

    block_user() async {
      await Block.insert_block(widget.user.auth_id, widget.cov.author1.auth_id,
          widget.user.id, widget.cov.author1.id);
      await Block.insert_block(widget.cov.author1.auth_id, widget.user.auth_id,
          widget.cov.author1.id, widget.user.id);

      setState(() {
        widget.user.show = false;
      });
    }

    var st = TextStyle(
        color: Colors.white, fontWeight: FontWeight.w600, fontSize: 12.5);

    Widget card = widget.cov.delete
        ? new Container()
        : new Container(
            // margin: new EdgeInsets.all(16.0),
            height: 280.0,
            child: new Card(
                elevation: 2.0,
                child: new Container(
                    padding: new EdgeInsets.all(8.0),
                    child: new Column(children: <Widget>[
                      new Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          new Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              new InkWell(
                                  onTap: () async {
                                    //UserProfile

                                    /* Navigator.push(context,
                                        new MaterialPageRoute(
                                            builder: (BuildContext context) {
                                      return new UserProfile(
                                          widget.cov.author,
                                          widget.user,
                                          widget.auth,
                                          widget.sign,
                                          widget.lat,
                                          widget.lng,
                                          true,
                                          widget.analytics,
                                          widget.list_partner);
                                    }));*/
                                  },
                                  child: new InkWell(
                                      onTap: () {
                                        Navigator.of(context)
                                            .push(new PageRouteBuilder(
                                          pageBuilder: (_, __, ___) =>
                                              new Details_user(
                                                  widget.cov.author1,
                                                  widget.user,
                                                  true,
                                                  widget.list_partner,
                                                  widget.analytics,
                                                  widget.chng),
                                        ));
                                      },
                                      child: new ClipOval(
                                          //: Colors.grey[400],
                                          child: /*new Image.asset("images/logo.png"*/
                                              new Container(
                                                  color: Colors.grey[300],
                                                  child: new Image.network(
                                                      widget.cov.author.image,
                                                      width: 40.0,
                                                      height: 40.0,
                                                      fit: BoxFit.cover))))),

                              new Container(
                                height: 4.0,
                              ),
                              new Text(
                                widget.cov.author.firstname +
                                    " " +
                                    widget.cov.author.fullname.toUpperCase(),
                                style: new TextStyle(
                                    color: Fonts.col_app,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 11.0),
                              ),
                              //new Container(height: 2.0),
                              new Container(
                                height: 8.0,
                              ),

                              new Row(children: <Widget>[
                                _buildRatingBar(),
                                widget.cov.count_r == 0
                                    ? new Container()
                                    : new Text(
                                        " (" +
                                            widget.cov.count_r.toString() +
                                            ") ",
                                        style: new TextStyle(
                                            color: Colors.grey[800],
                                            fontSize: 11.0),
                                      )
                              ]),
                              new Container(height: 8.0),

                              new Row(
                                children: <Widget>[
                                  new Container(
                                    width: 2.0,
                                  ),
                                  new GestureDetector(
                                      onTap: () {
                                        /*  var lat = widget.cov.latLng
                                        .toString()
                                        .split(";")[0];
                                    var lng = widget.cov.latLng
                                        .toString()
                                        .split(";")[1];
                                    _launched = _launch(
                                        'https://www.google.com/maps/@$lat,$lng,16z');*/
                                      },
                                      child: new Icon(
                                        Icons.location_on,
                                        size: 12.0,
                                        color: Fonts.col_app_fon,
                                      )),
                                  new Container(width: 2.0),
                                  new GestureDetector(
                                      onTap: () {
                                        /*  var lat = widget.cov.latLng
                                        .toString()
                                        .split(";")[0];
                                    var lng = widget.cov.latLng
                                        .toString()
                                        .split(";")[1];
                                    _launched = _launch(
                                        'https://www.google.com/maps/@$lat,$lng,16z');*/
                                      },
                                      child: new Text(
                                        widget.cov.dis.toString == "null"
                                            ? "-.- Km"
                                            : widget.cov.dis.toString(),
                                        style: new TextStyle(
                                            color: Fonts.col_app_fon,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 12.0),
                                      )),
                                ],
                              ),
                              new Container(height: 8.0),

                              widget.cov.nboost == 0
                                  ? spons
                                  : new Row(
                                      children: <Widget>[
                                        new Container(
                                          width: 2.0,
                                        ),
                                        new Icon(
                                          Icons.timer,
                                          size: 12.0,
                                          color: Colors.blue[800],
                                        ),
                                        new Container(width: 2.0),
                                        new Text(
                                          ta.format(DateTime.parse(
                                              widget.cov.createdAt)),
                                          style: new TextStyle(
                                              color: Colors.blue[800],
                                              fontSize: 11.0),
                                        ),
                                      ],
                                    ),
                            ],
                          ),
                          new Container(
                            width: 8.0,
                          ),
                          // new Expanded(child: new Container()),
                          new Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              rw(widget.cov.from_place.toString(), "De: ",
                                  "images/loc.png"),
                              new Container(height: 12.0),
                              rw(widget.cov.to_place.toString(), "A: ",
                                  "images/loc.png"),
                              widget.cov.date_cov.toString().toString() ==
                                      "null"
                                  ? Container()
                                  : new Container(height: 12.0),
                              widget.cov.date_cov.toString().toString() ==
                                      "null"
                                  ? Container()
                                  : rw(widget.cov.date_cov.toString(),
                                      "Date de départ: ", "images/cal.png"),
                              widget.cov.hour_d.toString().toString() == "null"
                                  ? Container()
                                  : new Container(height: 12.0),
                              widget.cov.hour_d.toString().toString() == "null"
                                  ? Container()
                                  : rw(widget.cov.hour_d.toString(),
                                      "Heure de départ: ", "images/clock.png"),
                              new Container(height: 12.0),
                              rw(
                                  widget.cov.nb_places.toString() != "" &&
                                          widget.cov.nb_places.toString() !=
                                              "null"
                                      ? widget.cov.nb_places.toString()
                                      : "Non mentionné",
                                  "Nombre de places",
                                  "images/seat.png"),
                              new Container(height: 12.0),
                              rw(
                                  widget.cov.station.isNotEmpty &&
                                          widget.cov.station.toString() !=
                                              "null"
                                      ? widget.cov.station
                                          .toString()
                                          .replaceAll("]", "")
                                          .replaceFirst("[", "")
                                      : "Non mentionné",
                                  "Stations",
                                  "images/pin.png")
                            ],
                          )
                        ],
                      ),
                      !widget.show
                          ? Container()
                          : Container(
                              height: 6.0,
                            ),
                      !widget.show
                          ? Container()
                          : Container(
                              width: MediaQuery.of(context).size.width,
                              child: Row(
                                children: <Widget>[
                                  Expanded(child: Container()),
                                  RaisedButton(
                                    color: Colors.deepPurple[800],
                                    padding: EdgeInsets.all(0),
                                    shape: new RoundedRectangleBorder(
                                        borderRadius:
                                            new BorderRadius.circular(18.0)),
                                    onPressed: () {
                                      /* Navigator.push(context,
                                    new MaterialPageRoute(builder: (BuildContext context) {
                                      return new Covoiturage(
                                          widget.user,
                                          widget.auth,
                                          null,
                                          widget.lat,
                                          widget.lng,
                                          widget.list_partner,
                                          widget.analytics);
                                    }));*/
                                    },
                                    child: Text("Covoiturages", style: st),
                                  )
                                ],
                              )),
                      new Expanded(child: new Container()),
                      new Container(
                        height: 1.0,
                        width: 1000.0,
                        color: Colors.blueGrey[100],
                      ),
                      widget.cov.author.id != widget.user.id
                          ? new Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                new FlatButton(
                                    padding: new EdgeInsets.all(0.0),
                                    onPressed: () {
                                      confirmer(
                                          widget.user.auth_id,
                                          widget.cov.author.auth_id,
                                          widget.user,
                                          widget.cov.author);
                                    },
                                    child: new Row(
                                      children: <Widget>[
                                        new Image.asset(
                                          "images/contact.png",
                                          width: 16.0,
                                          height: 16.0,
                                          color: Colors.blueGrey[900],
                                        ),
                                        new Container(
                                          width: 4.0,
                                        ),
                                        new Text(LinkomTexts.of(context).contact(),
                                            style: Fonts.footer)
                                      ],
                                    )),
                                new Container(
                                  width: 8.0,
                                ),
                                new FlatButton(
                                    padding: new EdgeInsets.all(0.0),
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          new MaterialPageRoute<Null>(
                                              builder: (BuildContext context) =>
                                                  new Comments(
                                                      widget.cov,
                                                      "",
                                                      true,
                                                      widget.user,
                                                      func,widget.chng)));
                                    },
                                    child: new Row(
                                      children: <Widget>[
                                        new Image.asset(
                                          "images/com.png",
                                          width: 18.0,
                                          height: 18.0,
                                          color: Colors.blueGrey[900],
                                        ),
                                        new Container(
                                          width: 6.0,
                                        ),
                                        new Text(
                                          "Commenter",
                                          style: Fonts.footer,
                                        )
                                      ],
                                    )),
                                new Container(
                                  width: 4.0,
                                ),
                                widget.cov.author.id != widget.user.id
                                    ? new FlatButton(
                                        padding: new EdgeInsets.all(0.0),
                                        onPressed: () async {
                                          List off = await AlertRate.dialog(
                                              context,
                                              widget.cov.author.fullname,
                                              widget.cov.author.image,
                                              widget.cov.author.id,
                                              widget.cov.author,
                                              widget.cov.rating,
                                              widget.cov.objectId,
                                              widget.cov.count_r,
                                              context,
                                              my_id: widget.user.id,
                                              id_other: widget.cov.author.id);
                                          setState(() {
                                            widget.cov.rating = off[0];
                                            widget.cov.count_r = off[1];
                                          });
                                        },
                                        child: new Row(
                                          children: <Widget>[
                                            new Image.asset(
                                              "images/medal.png",
                                              width: 16.0,
                                              height: 16.0,
                                            ),
                                            new Container(
                                              width: 4.0,
                                            ),
                                            new Text("Evaluer",
                                                style: Fonts.footer)
                                          ],
                                        ))
                                    : new Container(),

                                /*  new Expanded(
                        child: new Container(),
                      ),
                      new RaisedButton(
                        color: Colors.grey[50],
                        splashColor: Fonts.col_app,
                        elevation: 4.0,
                        highlightColor: Fonts.col_app_fon,
                        onPressed: () {
                          // Routes.goto(context, "profile", id: widget.user.id);
                        },
                        child: new Text(
                          "CONTACTER",style: new TextStyle(color: const Color(0xffff374e),fontWeight: FontWeight.bold,),
                        ),
                      ),
                      new Container(
                        width: 12.0,
                      ),
                      new RaisedButton(
                        elevation: 8.0,

                        color: Fonts.col_app,
                        splashColor: Fonts.col_app_fon,
                        // highlightColor: Fonts.color_app,
                        onPressed: () {},
                        child: new Text(
                          "EVALUER",style: new TextStyle(color: Colors.white),
                        ),
                      )*/
                              ],
                            )
                          : new Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                  new InkWell(
                                      onTap: () {
                                        Navigator.push(
                                            context,
                                            new MaterialPageRoute<Null>(
                                                builder:
                                                    (BuildContext context) =>
                                                        new Comments(
                                                            widget.cov,
                                                            "",
                                                            true,
                                                            widget.user,
                                                            fu,widget.chng)));
                                      },
                                      child: Container(
                                          padding: EdgeInsets.only(
                                              right: 10.0,
                                              top: 12.0,
                                              bottom: 12.0),
                                          child: new Row(
                                            children: <Widget>[
                                              new Image.asset(
                                                "images/com.png",
                                                width: 12.0,
                                                height: 12.0,
                                                color: Colors.blueGrey[900],
                                              ),
                                              new Container(
                                                width: 6.0,
                                              ),
                                              new Text(
                                                "Commenter",
                                                style: Fonts.footer,
                                              )
                                            ],
                                          ))),
                                  new InkWell(
                                      onTap: () {
                                        //A modifier
                                        Navigator.push(context,
                                            new MaterialPageRoute(builder:
                                                (BuildContext context) {
                                          return new AddCov(
                                            widget.user,
                                            widget.auth,
                                            widget.sign,
                                            widget.list_partner,
                                            func,
                                            true,
                                            widget.idpost,
                                            cov: widget.cov,
                                          );
                                        }));
                                      },
                                      child: Container(
                                          padding: EdgeInsets.only(
                                              right: 8.0,
                                              top: 12.0,
                                              bottom: 12.0),
                                          child: new Row(children: <Widget>[
                                            new Image.asset("images/edit.png",
                                                width: 12.0,
                                                height: 12.0,
                                                color: Colors.blueGrey[700]),
                                            new Container(
                                              width: 4.0,
                                            ),
                                            new Text(
                                              "Modifier",
                                              style: Fonts.footer,
                                            )
                                          ]))),
                                  new InkWell(
                                      onTap: () {
                                        delete_post();
                                      },
                                      child: Container(
                                          padding: EdgeInsets.only(
                                              right: 8.0,
                                              top: 12.0,
                                              bottom: 12.0),
                                          child: new Row(
                                            children: <Widget>[
                                              new Image.asset(
                                                  "images/delete.png",
                                                  width: 12.0,
                                                  height: 12.0,
                                                  color: Colors.blueGrey[700]),
                                              new Container(
                                                width: 4.0,
                                              ),
                                              new Text(
                                                "Supprimer",
                                                style: Fonts.footer,
                                              )
                                            ],
                                          ))),
                                ]),
                      new Container()
                    ]))));
    return card;
  }
}
