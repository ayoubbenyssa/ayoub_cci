import 'dart:async';

import 'package:flutter/material.dart';
import 'package:medz/co_voiturage/comments/streamcomments.dart';
import 'package:medz/fils_actualit/wall_card.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/models/video.dart';
import 'package:medz/services/Fonts.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/services/commentsfunctions.dart';

class Comments extends StatefulWidget {
  Comments(this.post, this.error,this.retur, this.user,this.func,this.chng,{Key key}) : super(key: key);
  var error;

  User user;
  var post;
  bool retur;
  var func;
  var chng;

  @override
  _CommentsState createState() => new _CommentsState();
}

class _CommentsState extends State<Comments> {
  ScrollController scrollController = new ScrollController();

  //Notificationfunctions notification = new Notificationfunctions();
  CommentFunctions commentFunctions = new CommentFunctions();
  final TextEditingController _textController = new TextEditingController();
  /* Stylesapp stylesapp = new Stylesapp();*/

  bool addcomments = false;
  String _issubscribed = "subscribe";
  String txtsubscribe = "";
  List newcomments = new List();
  bool isloading = true;
  String avatar = "";
  String username = "";
  String imageURL = "";
  String imagenew = "";
  bool show = false;
  bool cansend = false;
  bool isBlock = false;
  var idcurrent = "";
  var isimage = 0;



  insertcomment() async {
    try {
      setState(() => cansend = false);
    } catch (e) {}
    await commentFunctions.insertComment(_textController.text,
        widget.post.objectId, imageURL, widget.post.author, avatar, widget.user.id,context);
    setState(() => addcomments = true);
    _textController.clear();

    widget.func(1);


    new Timer(new Duration(seconds: 1), () {
      scrollController.animateTo(1000.0,
          curve: Curves.easeOut, duration: const Duration(milliseconds: 1));
    });

    try {
      setState(() {
        isimage = 0;
        imageURL = "";
      });
    } catch (e) {}
  }

  /*verifyblocked() async {
    if (widget.error == "nointernet" ||
        widget.error == "error" ||
        widget.error == "empty") {
      return false;
    }
    var val = await blockFunctions.verifyBlock(widget.post.author);
    try {
      setState(() => isBlock = val);
    } catch (e) {}
  }*/

  @override
  initState() {
    super.initState();
    //verifyblocked();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.error == "nointernet") {
      Widget appbar = /*new AppBar(
          backgroundColor: Colors.grey[900],
          title: new Text("nointernet"))*/
      new AppBar(
          iconTheme:  new IconThemeData(color: Colors.grey[200]
          ),
          backgroundColor: Colors.white,
          elevation: 1.0,
          title: new Text("Commentaires",style: TextStyle(color: Colors.black),));

      return new Scaffold(
          appBar: appbar, body: new Center(child: new Text("nointernet")));
    } else if (widget.error == "error") {
      Widget appbar = new AppBar(
          backgroundColor:Fonts.col_app,title: new Text("error"));

      return new Scaffold(
          appBar: appbar, body: new Center(child: new Text("error")));
    }  else {

      Widget appbar =  new AppBar(
          iconTheme:  new IconThemeData(
              color: Colors.white
          ),
          backgroundColor:  Fonts.col_app_green,
          elevation: 1.0,
          title: new Text("Commentaires"));



      Widget textinputcomment = new Flexible(
          child: new Container(
              child: new TextField(
                  controller: _textController,
                  autocorrect: true,
                  onChanged: (text) {
                    if (text != "" && text != null) {
                      try {
                        setState(() => cansend = true);
                      } catch (e) {}
                    }
                  },
                  maxLines: ((_textController.text.length / 25).round() < 6)
                      ? ((_textController.text.length / 25).round() + 1)
                      : 6,
                  keyboardType: TextInputType.multiline,
                  //  style: stylesapp.styleaddnewcomment(),
                  decoration: new InputDecoration.collapsed(
                    hintText: "Ajouter un commentaire",
                    //hintStyle: stylesapp.styleaddnewcomment()

                  ))));

      Widget sendcomment = new IconButton(
          padding: new EdgeInsets.all(4.0),
          icon: new Icon(Icons.send,
              size: 30.0,
              color: cansend ? Colors.grey[900] : Colors.grey),
          onPressed: cansend ? () => insertcomment() : null);

      Widget bottomsend = isBlock
          ? new Container()
          : new Container(
          decoration: new BoxDecoration(
              color: Colors.grey[200],
              border: new Border(top: new BorderSide(color: Colors.grey))),
          padding: const EdgeInsets.only(left: 10,bottom: 22,right: 10,top: 4),
          child: Center(
              child: new Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Container(
                      width: 12,
                    ),
                    new Container(
                        decoration: new BoxDecoration(
                            color: const Color(0xffe8f2f4),
                            border: new Border(
                                top: new BorderSide(color: Colors.grey[400])))),
                    textinputcomment,
                    sendcomment
                  ])));



      Widget content = new Column(children: [

        new Flexible(
            child: new StreamComments(
                widget.user,
                scrollController: scrollController,
                addcomments: addcomments,
                idpost: widget.post.objectId,
                post: widget.post,
                widgetheader:   widget.post.type=="sondage"?Container(): Wall_card(
                    widget.post,
                    widget.user,
                    [],
                    0.0,
                    0.0,
                    null,
                    widget.chng),
                func:widget.func
            )),
        bottomsend
      ]);


      return  new Scaffold(appBar: appbar, body: new Container(child: content));
    }
  }
}
