import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
//import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/services/Fonts.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:scoped_model/scoped_model.dart';

import 'package:timeago/timeago.dart' as ta;
import 'package:medz/models/comment.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/app_services.dart';
import 'package:medz/services/commentsfunctions.dart';

class CommentsWidget extends StatefulWidget {
  CommentsWidget(this.comment, this.user, this.post, this.user_me, this.func,
      {Key key})
      : super(key: key);
  Comment comment;
  User user;
  Offers post;
  User user_me;
  var func;

  @override
  _CommentsWidgetState createState() => new _CommentsWidgetState();
}

class _CommentsWidgetState extends State<CommentsWidget> {
  CommentFunctions commentFunctions = new CommentFunctions();

  HasArabicCharacters(String text) {
    var regex = new RegExp(
        "[\u0600-\u06ff]|[\u0750-\u077f]|[\ufb50-\ufc3f]|[\ufe70-\ufefc]");

    return regex.hasMatch(text);
  }

  Future<Null> _launch(String url) async {
    /*  if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }*/
  }

  TapGestureRecognizer gourl(item) {
    var tap = new TapGestureRecognizer()
      ..onTap = () {
        _launch(item);
      };
    return tap;
  }

  ParseServer parse_s = new ParseServer();

  delete() async {
    await parse_s.deleteparse("comments1/" + widget.comment.id);

    setState(() {
      widget.comment.delete = true;
      widget.func(-1);
    });
  }

  Widget build(BuildContext context) {
    List<TextSpan> texts = new List<TextSpan>();
    var text = widget.comment.text.split(" ");

    Widget photouser = new ClipOval(
        child: new Image.network(widget.user.image.toString(),
            fit: BoxFit.cover, width: 32.0, height: 32.0));
    Widget avatar = new GestureDetector(
        onTap: () => null,
        //routesFunctions.gotoparams2("profile", context, widget.user,widget.user.objectId),
        child: new Container(
            margin: const EdgeInsets.only(right: 8.0), child: photouser));

    Widget icns = IconButton(
      icon: Icon(
        Icons.remove_circle,
        color: Colors.red[900],
      ),
      onPressed: () {
        Alert(
            context: context,
            title: "Voulez-vous supprimer ce commentaire ?",
            content: Column(
              children: <Widget>[],
            ),
            buttons: [
              DialogButton(
                color: Fonts.col_app_green,
                onPressed: () {
                  delete();
                  Navigator.pop(context);
                },
                child: Text(
                  "Ok",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              )
            ]).show();
      },
    );

    TextSpan returnurl(text) {
      return new TextSpan(
        style: new TextStyle(color: Colors.black87),
        recognizer: gourl(text),
        text: text + " ",
        // style: styleapp.styleurlhash()
      );
    }

    /* TextSpan returnhashtag(text) {
      return new TextSpan(
          recognizer: gohashtag(text.substring(1, text.length)),
          text: text + " ",
          style: styleapp.styleurlhash());
    }*/

    Widget username = new Text(
        toBeginningOfSentenceCase(  widget.user.firstname.toString()) + " " + widget.user.fullname.toString().toUpperCase(),
      style: new TextStyle(
          fontSize: 15.0,
          color: Colors.grey[800],
          fontWeight: FontWeight.w900), /* style: styleapp.styleusername1()*/
    );

    Widget timecomment = ScopedModelDescendant<AppModel1>(
        builder: (context, child, model) => new Text(
            ta.format(widget.comment.createdat,
                locale: model.locale == "ar" ? "ar" : "fr"),
            style: new TextStyle(
                fontSize: 10.0,
                color: Colors.grey[600],
                fontWeight: FontWeight.w700)
          /*style: styleapp.styletime()*/));

    return widget.comment.delete == true
        ? Container()
        : new Container(
        padding: new EdgeInsets.all(2.0),
        margin: new EdgeInsets.all(2.0),
        child: new Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              new Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    avatar,
                    new Container(
                        padding: new EdgeInsets.all(1.0),
                        child: new Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              new Container(
                                height: 2.0,
                              ),
                              username,
                              new Container(
                                height: 2.0,
                              ),
                              timecomment
                            ])),
                    Expanded(
                      child: Container(),
                    ),
                    widget.post.author.toString() != "null" &&
                        widget.user_me.id == widget.post.author.id
                        ? icns
                        : Container()
                  ]),
              new Container(
                  width: MediaQuery.of(context).size.width * 0.93,
                  padding: new EdgeInsets.only(
                      top: 4.0, bottom: 4.0, left: 32.0),
                  child: new Linkify(
                      maxLines: 60,
                      style: TextStyle(
                        fontSize: 15.5,
                      /*  fontFamily: HasArabicCharacters(widget.comment.text)
                            ? 'open'
                            : 'ab',*/
                      ),
                     /* textDirection:
                      HasArabicCharacters(widget.comment.text)
                          ? TextDirection.rtl
                          : TextDirection.ltr,*/
                      onOpen: (link) =>
                          AppServices.go_webview(link.url, context),

                      //jiji
                      text: widget.comment.text)),
              new Container(
                height: 2.0,
              ),
              new Divider(
                height: 1.0,
                color: Colors.grey,
              ),
            ]));
  }
}
