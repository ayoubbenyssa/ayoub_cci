import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:latlong/latlong.dart';
import 'package:medz/co_voiturage/profile/covoiturage_user.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/user.dart';
import 'package:photo_view/photo_view.dart';
import 'package:medz/widgets/arc_clip.dart';
import 'package:medz/widgets/common.dart';
import 'package:timeago/timeago.dart' as ta;
import 'package:intl/intl.dart';

enum AppBarBehavior { normal, pinned, floating, snapping }

class UserProfile extends StatefulWidget {
  UserProfile(this.user, this.user_me, this.auth, this.sign, this.lat, this.lng,
      this.cov, this.list_partner, this.analytics, this.bl, this.chng);

  User user;
  var user_me;
  var auth;
  var sign;
  var lat;
  var lng;
  List list_partner;
  var analytics;
  var cov = true;
  bool bl;
  var chng;

  @override
  _Details_userState createState() => _Details_userState();
}

class _Details_userState extends State<UserProfile>
    with TickerProviderStateMixin {
  AnimationController _containerController;
  bool uploading = false;

  double _appBarHeight = 224.0;
  AppBarBehavior _appBarBehavior = AppBarBehavior.pinned;
  Animation<double> width;
  Animation<double> heigth;
  Distance distance = new Distance();
  ParseServer parse_s = new ParseServer();
  final _phonecontroller = new TextEditingController();
  FocusNode _focusphone = new FocusNode();
  bool val1 = true;
  String type = "";
  bool val2 = false;

  getOnlineUser() async {
    DocumentSnapshot a = await Firestore.instance
        .collection('users')
        .document(widget.user.auth_id)
        .get();

    if (a.data["offline"].toString() == "offline") {
      setState(() {
        widget.user.online = false;
        widget.user.offline = "offline";
      });
    } else if (a.data["online"].toString() == "null") {
      setState(() {
        widget.user.online = false;
      });
    } else
      setState(() {
        widget.user.online = a.data["online"];
        widget.user.last_active = a.data["last_active"];
        print(ta.format(
            new DateTime.fromMillisecondsSinceEpoch(widget.user.last_active)));
      });
  }

  void initState() {
    getOnlineUser();

    _containerController = new AnimationController(
        duration: new Duration(milliseconds: 2000), vsync: this);
    super.initState();
    width = new Tween<double>(
      begin: 160.0,
      end: 160.0,
    ).animate(
      new CurvedAnimation(
        parent: _containerController,
        curve: Curves.ease,
      ),
    );
    heigth = new Tween<double>(
      begin: 160.0,
      end: 160.0,
    ).animate(
      new CurvedAnimation(
        parent: _containerController,
        curve: Curves.ease,
      ),
    );
    heigth.addListener(() {
      setState(() {
        if (heigth.isCompleted) {}
      });
    });
    _containerController.forward();
  }

  @override
  void dispose() {
    _containerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    /*Widget gsm = Widgets.textfield0(
      "GSM",
      _focusphone,
      user.phone,
      _phonecontroller,
      TextInputType.phone,
    );*/

    var divider = new Container(
      color: Colors.grey[300],
      width: 10000.0,
      height: 1.0,
    );

    Widget page = widget.bl
        ? new CovoiturageUser(
            widget.user_me,
            widget.user.id,
            widget.auth,
            widget.sign,
            widget.lat,
            widget.lng,
            widget.cov,
            widget.list_partner,
            widget.analytics,
            true,
            widget.chng,
          )
        : new Container(
            width: width.value,
            height: heigth.value,
            color: Colors.grey[50],
            child: new Container(
              color: Colors.transparent,
              child: new Container(
                //alignment: Alignment.center,
                width: width.value,
                height: heigth.value,
                decoration: new BoxDecoration(
                  color: Colors.white,
                  // borderRadius: new BorderRadius.circular(10.0),
                ),
                child: new Stack(
                  alignment: AlignmentDirectional.bottomCenter,
                  children: <Widget>[
                    new CustomScrollView(
                      shrinkWrap: false,
                      slivers: <Widget>[
                        new SliverAppBar(
                          leading: new IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: new Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                              size: 30.0,
                            ),
                          ),
                          backgroundColor: Colors.transparent,
                          automaticallyImplyLeading: false,
                          elevation: 0.0,
                          forceElevated: true,
                          expandedHeight: _appBarHeight,
                          pinned: _appBarBehavior == AppBarBehavior.pinned,
                          floating:
                              _appBarBehavior == AppBarBehavior.floating ||
                                  _appBarBehavior == AppBarBehavior.snapping,
                          snap: _appBarBehavior == AppBarBehavior.snapping,
                          flexibleSpace: new FlexibleSpaceBar(
                            title: new Text(""),
                            background: ClipPath(
                                clipper: new ArcClipper2(),
                                child: new Stack(
                                  fit: StackFit.expand,
                                  children: <Widget>[
                                    new Container(
                                      width: width.value,
                                      height: _appBarHeight,
                                      decoration: new BoxDecoration(
                                        image: new DecorationImage(
                                          image: new NetworkImage(
                                              widget.user.image),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      child: new Container(
                                          decoration: new BoxDecoration(
                                            color: Colors.grey[800],
                                            image: new DecorationImage(
                                              fit: BoxFit.cover,
                                              colorFilter: new ColorFilter.mode(
                                                  Colors.black.withOpacity(0.3),
                                                  BlendMode.dstATop),
                                              image: new NetworkImage(
                                                widget.user.image,
                                              ),
                                            ),
                                          ),
                                          child: new Column(children: <Widget>[
                                            new Row(
                                              children: <Widget>[
                                                new Expanded(
                                                    child: new Container()),
                                              ],
                                            ),
                                            new Container(
                                              height: 48.0,
                                            ),
                                            new ClipOval(
                                                child: new Container(
                                              width: 100.0,
                                              height: 100.0,
                                              child: new FadingImage.network(
                                                widget.user.image,
                                                fit: BoxFit.cover,
                                              ),
                                            )),
                                            new Container(
                                              height: 8.0,
                                            ),
                                            new Center(
                                                child: new Text(
                                              widget.user.age.toString() != ""
                                                  ? toBeginningOfSentenceCase(
                                                              widget.user
                                                                  .firstname
                                                                  .toString())
                                                          .toString() +
                                                      " " +
                                                      widget.user.fullname
                                                          .toString()
                                                          .toUpperCase() +
                                                      ", " +
                                                      widget.user.age
                                                          .toString() +
                                                      " ans"
                                                  : toBeginningOfSentenceCase(
                                                          widget.user.firstname
                                                              .toString()) +
                                                      " " +
                                                      widget.user.firstname
                                                          .toString()
                                                          .toUpperCase(),
                                              style: new TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 17.0,
                                                  fontWeight: FontWeight.w600),
                                            )),
                                            new Container(
                                              height: 6.0,
                                            ),
                                            new Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  new Container(width: 28.0),
                                                  new Expanded(
                                                      child: new Center(
                                                          child: new Text(
                                                              widget.user.titre
                                                                      .toString() +
                                                                  " à " +
                                                                  widget.user
                                                                      .organisme,
                                                              style: new TextStyle(
                                                                  color: Colors
                                                                          .grey[
                                                                      400],
                                                                  fontSize:
                                                                      16.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center))),
                                                ]),
                                            new Container(
                                              height: 6.0,
                                            ),
                                            new Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  new Center(
                                                      child: new Text(
                                                    widget.user.community
                                                        .toString(),
                                                    style: new TextStyle(
                                                        color: Colors.grey[200],
                                                        fontSize: 17.0,
                                                        fontWeight:
                                                            FontWeight.w400),
                                                  )),
                                                  new Container(
                                                    height: 4.0,
                                                  ),
                                                ]),
                                          ])),
                                    ),
                                  ],
                                )),
                          ),
                        ),

                        new CovoiturageUser(
                          widget.user_me,
                          widget.user.id,
                          widget.auth,
                          widget.sign,
                          widget.lat,
                          widget.lng,
                          widget.cov,
                          widget.list_partner,
                          widget.analytics,
                          false,
                          widget.chng,
                        ),

                        // new  CovoiturageUser(widget.user_me,widget.user.id,widget.auth,widget.sign,widget.lat,widget.lng)
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
    return new Theme(
      data: new ThemeData(
        brightness: Brightness.light,
        primaryColor: Colors.grey[50],
        platform: Theme.of(context).platform,
      ),
      child: page,
    );
  }

/*
*/
}

class FullScreenWrapper extends StatelessWidget {
  final ImageProvider imageProvider;
  final Widget loadingChild;
  final Color backgroundColor;
  final dynamic minScale;
  final dynamic maxScale;

  FullScreenWrapper(
      {this.imageProvider,
      this.loadingChild,
      this.backgroundColor,
      this.minScale,
      this.maxScale});

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          iconTheme: IconThemeData(color: Colors.black),
          backgroundColor: Colors.black,
          actions: <Widget>[
            new IconButton(
                icon: new Icon(
                  Icons.close,
                  color: Colors.grey[50],
                  size: 26.0,
                ),
                onPressed: () {
                  Navigator.pop(context);
                })
          ],
        ),
        backgroundColor: Colors.black87,
        body: new Container(
            constraints: BoxConstraints.expand(
              height: MediaQuery.of(context).size.height,
            ),
            child: new PhotoView(
              imageProvider: imageProvider,
              loadingChild: loadingChild,
              // backgroundColor: backgroundColor,
              minScale: minScale,
              maxScale: maxScale,
            )));
  }
}
