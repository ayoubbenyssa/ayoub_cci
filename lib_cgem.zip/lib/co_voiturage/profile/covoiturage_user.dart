import 'package:flutter/material.dart';
import 'package:medz/models/user.dart';
import 'package:medz/parc_events_stream/parc_events_stream.dart';

class CovoiturageUser extends StatefulWidget {
  CovoiturageUser(
      this.user_me,
      this.id_user_cov,
      this.auth,
      this.sign,
      this.lat,
      this.lng,
      this.type,
      this.list_partner,
      this.analytics,
      this.bl,
      this.chng);

  User user_me;
  var auth;
  var sign;
  var lat;
  var lng;
  String id_user_cov;
  bool type;
  List list_partner;
  var analytics;
  var chng;
  bool bl;

  @override
  _CovoiturageState createState() => _CovoiturageState();
}

class _CovoiturageState extends State<CovoiturageUser> {
  String profile = "";

  @override
  void initState() {
    super.initState();
    if (widget.bl == true) {
      profile = "";
    } else {
      profile = "profile";
    }
  }

  int count1 = 0;
  int count2 = 0;

  setSount1(c) {
    setState(() {
      count1 = c;
    });
  }

  setSount2(c) {
    setState(() {
      count2 = c;
    });
  }

  @override
  Widget build(BuildContext context) {
    return widget.type
        ? StreamParcPub(
            new Container(),
            widget.lat,
            widget.lng,
            widget.user_me,
            "0",
            widget.list_partner,
            widget.analytics,
            setSount1,
            widget.chng,
            category: "cov",
            profile: profile,
            user_id_cov: widget.id_user_cov,
            favorite: false,
            boutique: false,
          )
        : StreamParcPub(
            new Container(),
            widget.lat,
            widget.lng,
            widget.user_me,
            "0",
            widget.list_partner,
            widget.analytics,
            setSount1,
            widget.chng,
            type: "an",
            profile: profile,
            user_id_cov: widget.id_user_cov,
            favorite: false,
            boutique: false,
          );
  }
}

/**
 *
 *  new SliverList(
    delegate: new SliverChildListDelegate(<Widget>[
    new Container(height: 438.0),

    new Container(
    height: 14.0),


    ]),
    ),
 */
