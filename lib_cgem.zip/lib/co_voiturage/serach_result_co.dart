/*import 'package:flutter/material.dart';
import 'package:flutter_fab_dialer/flutter_fab_dialer.dart';
import 'package:medz/co_voiturage/add_covoiturage.dart';
import 'package:medz/co_voiturage/search/search_form.dart';
import 'package:medz/models/user.dart';
import 'package:medz/parc_events_stream/parc_events_stream.dart';
import 'package:medz/services/Fonts.dart';


class CovoiturageSearchREs extends StatefulWidget {
  CovoiturageSearchREs(this.user, this.auth, this.sign, this.lat, this.lng,
      this.dep, this.dest, this.da, this.analytics,this.list_partner);

  User user;
  var auth;
  var sign;
  var lat;
  var lng;
  var dep;
  var dest;
  var da;
  List list_partner;
  var analytics;


  @override
  _CovoiturageState createState() => _CovoiturageState();
}

class _CovoiturageState extends State<CovoiturageSearchREs> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  int count1 = 0;

  setSount1(c) {
    setState(() {
      count1 = c;
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(title: new Text(count1 == 0?"Co-voiturage":"Co-voiturage"+ " ("+count1.toString()+")"),),
      body: new StreamParcPub(
          new Container(), widget.lat, widget.lng, widget.user, "0",
        widget.list_partner,
          widget.analytics,
          setSount1,
          category: "cov",
          dep: widget.dep,
          dest: widget.dest,
          boutique: false,
          favorite: false,
          da: widget.da),


    );
  }
}
*/