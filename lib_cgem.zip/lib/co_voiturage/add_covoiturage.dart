import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:medz/co_voiturage/stations.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/community.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/location_services.dart';
import 'package:medz/services/validators.dart';
import 'package:medz/widgets/fixdropdown.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:location/location.dart';

const String apiKey = 'AIzaSyDCB1z3cOQuIaf9LxLI6adVYjsSJC5TpDU';

class AddCov extends StatefulWidget {
  AddCov(this.user, this.auth, this.sign, this.list_partner, this.func, this.bl,this.idpost,
      {this.cov});

  User user;
  var auth;
  var sign;
  var idpost;


  Offers cov;
  List list_partner;
  var func;
  bool bl = false;

  @override
  _AddCovState createState() => _AddCovState();
}

class _AddCovState extends State<AddCov> {
  List<Community> _list = [];

  String ta = "";
  var lo = false;
  var error = "";
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  bool _autovalidate = false;
  final depctrl = new TextEditingController();
  FocusNode depfocus = new FocusNode();
  String selectedValue1 = "";
  String selectedValue2 = "";

  final destctrl = new TextEditingController();
  FocusNode destfocus = new FocusNode();

  final nbctrl = new TextEditingController();
  FocusNode nbfocus = new FocusNode();

  FocusNode pricefocus = new FocusNode();

  String da = "";
  ParseServer parse_s = new ParseServer();
  List<String> sttions = new List<String>();

  var lat, lng;

  getCommunities() async {
    if (widget.bl) {
      depctrl.text = widget.user.community;
      selectedValue1 = widget.user.community;
    } else {
      selectedValue2 = widget.user.community;
      destctrl.text = widget.user.community;
    }

    var ref = FirebaseDatabase.instance.reference();
    ref
        .child('communities')
        .orderByChild('raja')
        .equalTo(true)
        .onValue
        .listen((evt) {
      if (evt.snapshot.value == null) {
        print('No Wiork to Show');
        return;
      }
      DataSnapshot data = evt.snapshot;
      var keys = data.value.keys;
      var todo = data.value;
      for (var key in keys) {
        //print(todo[key]);

        setState(() {
          _list.add(new Community.fromMap(todo[key], key));
        });
      }
    });
  }



  get_cov() {
    if (widget.cov.toString() != "null") {
      setState(() {
        depctrl.text = widget.cov.from_place;
        destctrl.text = widget.cov.to_place;
        nbctrl.text = widget.cov.nb_places;
        // sttions = widget.cov.station;

        for (String i in widget.cov.station) {
          sttions.add(i);
        }

        da = widget.cov.date_cov;
        ta = widget.cov.hour_d;
      });
    }
  }

  var currentLocation = <String, double>{};
  var location = new Location();


  getloc() async {
    currentLocation = await Location_service.getLocation();
    lat = currentLocation["latitude"];
    lng = currentLocation["longitude"];
  }



  bool enabl1 = true;
  bool enabl2 = true;

  @override
  void initState() {
    super.initState();
   // getCommunities();

    /*if (widget.bl == true) {
      depctrl.text = widget.user.community;
      setState(() {
        enabl1 = false;
      });
    } else {
      destctrl.text = widget.user.community;
      setState(() {
        enabl2 = false;
      });
    }*/

    get_cov();
    getloc();
  }

  @override
  Widget build(BuildContext context) {
    //final bloc = LocationProvider.of(context);

    Validators val = new Validators(context: context);
    var style = new TextStyle(
        color: const Color(0xffeff2f7),
        fontSize: 14.0,
        fontWeight: FontWeight.w600);

    Widget dep = Widgets.textfield_dec(
        "Départ", depfocus, "", depctrl, TextInputType.text, val.titrre,
        en: enabl1);

    Widget dest = Widgets.textfield_dec(
        "Destination", destfocus, "", destctrl, TextInputType.text, val.titrre,
        en: enabl2);

    Widget nb = Widgets.textfield0_dec(
        "Nombre de places", nbfocus, "", nbctrl, TextInputType.number);

    DateTime a;

    showd() async {
      a = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime.now().subtract(new Duration(days: 30)),
        lastDate: new DateTime.now().add(new Duration(days: 30)),
      );

      setState(() {
        da = a.toString().split(" ")[0];
        error = "";
      });
    }

    showt() async {
      TimeOfDay a = await showTimePicker(
        initialTime: new TimeOfDay.now(),
        context: context,
      );

      setState(() {
        ta = a.format(context);
        error = "";
      });
    }

    Widget stations = new InkWell(
      child: new Column(
        children: <Widget>[
          new Row(
            children: <Widget>[
              new Container(
                width: 8.0,
              ),
              new Text(
                "Stations:",
                style: new TextStyle(color: Colors.grey[600]),
              ),
              new Container(
                width: 12.0,
              ),
              new Text(sttions.isEmpty ? "" : sttions.toString()),
              new Expanded(child: new Container()),
              new Icon(Icons.arrow_drop_down)
            ],
          ),
          new Container(height: 12.0),
          new Container(
            height: 1.2,
            width: 1000.0,
            color: Colors.grey,
          )
        ],
      ),
      onTap: () async {
        List<String> a = await Navigator.push(context,
            new MaterialPageRoute(builder: (BuildContext context) {
          return new Stations();
        }));

        setState(() {
          sttions = a;
        });
      },
    );

    void onLoading(context) {
      showDialog(
          context: context,
          barrierDismissible: false,
          child: new Dialog(
            child: new Container(
              padding: new EdgeInsets.all(16.0),
              width: 40.0,
              color: Colors.transparent,
              child: new Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  new RefreshProgressIndicator(),
                  new Container(height: 8.0),
                  new Text(
                    "En cours ..",
                    style: new TextStyle(
                      color: Fonts.col_app_fonn,
                    ),
                  ),
                ],
              ),
            ),
          ));

      // Navigator.pop(context); //pop dialog
      //  _handleSubmitted();
    }

    confirm() async {
      final FormState form = _formKey.currentState;
      if (!form.validate()) {
        _autovalidate = true; // Start validating on every change.
      } else if (da == "") {
        setState(() {
          error = "Choisir la date de départ";
        });
      } else {
        onLoading(context);

        var idp = widget.idpost;

        var js = {
          "latLng": lat.toString() + ';' + lng.toString(),
          "depart": depctrl.text,
          "destination": destctrl.text,
          "time_dep": da,
          "hour_d": ta,
          "time_depart": a.toString(),
          "nb_place": nbctrl.text,
          "type": "cov",
          "raja": true,
          "station": sttions,
          "idp":"$idp",
          "author": {
            "__type": "Pointer",
            "className": "users",
            "objectId": widget.user.id
          }
        };

        if (widget.cov.toString() == "null") {
          await parse_s.postparse('offers', js);
          Navigator.of(context, rootNavigator: true).pop('dialog');
          widget.func();
          Navigator.pop(context);
        } else {
          await parse_s.putparse('offers/' + widget.cov.objectId, js);
          Navigator.of(context, rootNavigator: true).pop('dialog');
          Navigator.pop(context);
        }
      }
    }

    Widget time_d = new InkWell(
      child: new Column(
        children: <Widget>[
          new Row(
            children: <Widget>[
              new Container(
                width: 8.0,
              ),
              new Text(
                "Heure de départ:",
                style: new TextStyle(color: Colors.grey[600]),
              ),
              new Container(
                width: 12.0,
              ),
              new Text(ta == "" ? "" : ta),
              new Expanded(child: new Container()),
              new Icon(Icons.arrow_drop_down)
            ],
          ),
          new Container(height: 12.0),
          new Container(
            height: 1.2,
            width: 1000.0,
            color: Colors.grey,
          )
        ],
      ),
      onTap: () {
        showt();
      },
    );

    Widget date_d = new InkWell(
      child: new Column(
        children: <Widget>[
          new Row(
            children: <Widget>[
              new Container(
                width: 8.0,
              ),
              new Text(
                "Date de départ:",
                style: new TextStyle(color: Colors.grey[600]),
              ),
              new Container(
                width: 12.0,
              ),
              new Text(da == "" ? "" : da),
              new Expanded(child: new Container()),
              new Icon(Icons.arrow_drop_down)
            ],
          ),
          new Container(height: 12.0),
          new Container(
            height: 1.2,
            width: 1000.0,
            color: Colors.grey,
          )
        ],
      ),
      onTap: () {
        showd();
      },
    );

    Widget drop_down() => _list.isEmpty
        ? Container()
        : new Container(
            color: Colors.white,
            width: 700.0,
            height: 60.0,
            child: Container(
                margin: const EdgeInsets.all(8.0),
                // padding: const EdgeInsets.only(left: 16.0, right: 8.0),
                decoration: new BoxDecoration(
                  // color: Fonts.col_app,
                  border: new Border.all(color: Colors.grey[100], width: 1.0),
                  borderRadius: new BorderRadius.circular(2.0),
                ),
                child: new FixDropDown(
                    iconSize: 32.0,
                    isDense: false,
                    items: _list.map((Community value) {
                      return new FixDropdownMenuItem(
                        value: value,
                        child: new Text(
                          value.name.toString(),
                          maxLines: 2,
                          softWrap: true,
                        ),
                      );
                    }).toList(),
                    hint: new Text(
                      "Départ:" + selectedValue1 != ""
                          ? selectedValue1
                          : "Choisir une communité:",
                      maxLines: 1,
                      softWrap: true,
                      style: new TextStyle(color: Colors.black),
                    ),
                    onChanged: (Community value) {
                      setState(() {
                        selectedValue1 = value.name;
                        depctrl.text = value.name;
                        //Reload();
                      });
                    })));

    Widget drop_down1() => _list.isEmpty
        ? Container()
        : new Container(
            color: Colors.white,
            width: 700.0,
            height: 60.0,
            child: Container(
                margin: const EdgeInsets.all(8.0),
                // padding: const EdgeInsets.only(left: 16.0, right: 8.0),
                decoration: new BoxDecoration(
                  // color: Fonts.col_app,
                  border: new Border.all(color: Colors.grey[100], width: 1.0),
                  borderRadius: new BorderRadius.circular(2.0),
                ),
                child: new FixDropDown(
                    iconSize: 32.0,
                    isDense: false,
                    items: _list.map((Community value) {
                      return new FixDropdownMenuItem(
                        value: value,
                        child: new Text(
                          value.name.toString(),
                          maxLines: 2,
                          softWrap: true,
                        ),
                      );
                    }).toList(),
                    hint: new Text(
                      "Destination:   " + selectedValue2 != ""
                          ? selectedValue2
                          : "Choisir une communité:",
                      maxLines: 1,
                      softWrap: true,
                      style: new TextStyle(color: Colors.black),
                    ),
                    onChanged: (Community value) {
                      setState(() {
                        selectedValue2 = value.name;
                        destctrl.text = value.name;

                        //Reload();
                      });
                    })));

    Widget btn_log = new Container(
        height: 40.0,
        padding: new EdgeInsets.only(left: 6.0, right: 6.0),
        child: new Material(
            elevation: 2.0,
            shadowColor: Fonts.col_app_fon,
            borderRadius: new BorderRadius.circular(4.0),
            color: Fonts.col_app,
            child: new MaterialButton(
                // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  confirm();
                },
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Container(
                      width: 8.0,
                    ),
                    //  new Container(height: 36.0,color: Colors.white,width: 1.5,),
                    new Container(width: 8.0),
                    new Text(
                        widget.cov.toString() == "null"
                            ? "CREER   "
                            : "CONFIRMER",
                        style: style)
                  ],
                ))));

    return Scaffold(
      key: _scaffoldKey,
      appBar: new AppBar(),
      body: new Form(
          key: _formKey,
          autovalidate: _autovalidate,
          //onWillPop: _warnUserAboutInvalidData,
          child: new Column(children: <Widget>[
            new Expanded(
              child: new ListView(
                padding: new EdgeInsets.all(6.0),
                children: <Widget>[
                  new Container(height: 16.0),
                  // drop_down(),
                  //Center(child: Text("Ou"),),
                  dep,
                  // _searchField(context, bloc),
                  //   new Container(height: 20.0),
                  dest,
                  //drop_down1(),
                  !widget.bl
                      ? Container(
                          height: 12,
                        )
                      : new Container(height: 32.0),
                  stations,
                  new Container(height: 32.0),
                  date_d,
                  new Container(height: 20.0),
                  time_d,
                  new Container(height: 20.0),
                  nb,
                  new Container(height: 20.0),

                  //   desc,

                  new Center(
                    child: new Text(
                      error,
                      style: new TextStyle(
                          color: Colors.red[900], fontWeight: FontWeight.bold),
                    ),
                  ),
                  new Container(height: 16.0),
                  btn_log
                ],
              ),
            )
          ])),
    );
  }
}
