import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/services/Fonts.dart';

class Rating extends StatefulWidget {
  Rating(this.myid, this.idother, this.rate, this.id, this.context,this.count);

  String myid;
  String idother;
  var rate;
  var id;
  var context;
  var count;

  @override
  _RatingState createState() => new _RatingState();
}

class _RatingState extends State<Rating> {
  int _rating = 0;

// var response =
//        await parse_s.getparse('rate?where={"id_receive":"$his","id_cov":"$id_c"}');

  bool exist = false;
  String id_rate;
  bool show = false;

  /*


 exist check if the user already submit his rating
  */

  check_if_exit() async {
    var my_id = widget.myid;
    var his = widget.idother;
    var id_c = widget.id;

    var response = await parse_s.getparse(
        'rate?where={"id_receive":"$his","id_cov":"$id_c","id_send":"$my_id"}&count=1&limit=1');

    setState(() {
      show = true;
    });

    if (response["count"] > 0)
      setState(() {
        exist = true;
        _rating = response["results"][0]["rate"];
        id_rate = response["results"][0]["objectId"];
      });
    else
      setState(() {
        exist = false;
      });

    print(response);
  }

  @override
  void initState() {
    // TODO: implement initState
    check_if_exit();

    super.initState();
  }

  void rate(int rating) async {
    setState(() {
      _rating = rating;
      // fav.setrating(_rating, widget.doctors_id, prefs.getString("id"));
    });
  }

  ParseServer parse_s = new ParseServer();

  _buildRatingBar() {
    return new Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        new GestureDetector(
          child: new Icon(
            Icons.star,
            size: 32.0,
            color: _rating >= 1 ? Colors.orange : Colors.grey,
          ),
          onTap: () => rate(1),
        ),
        new GestureDetector(
          child: new Icon(
            Icons.star,
            size: 32.0,
            color: _rating >= 2 ? Colors.orange : Colors.grey,
          ),
          onTap: () => rate(2),
        ),
        new GestureDetector(
          child: new Icon(
            Icons.star,
            size: 32.0,
            color: _rating >= 3 ? Colors.orange : Colors.grey,
          ),
          onTap: () => rate(3),
        ),
        new GestureDetector(
          child: new Icon(
            Icons.star,
            size: 32.0,
            color: _rating >= 4 ? Colors.orange : Colors.grey,
          ),
          onTap: () => rate(4),
        ),
        new GestureDetector(
          child: new Icon(
            Icons.star,
            size: 32.0,
            color: _rating >= 5 ? Colors.orange : Colors.grey,
          ),
          onTap: () => rate(5),
        )
      ],
    );
  }

  List<int> list = new List<int>();
  bool load = false;
  var count = 0;
  var sum = 0;

  /*
  
  
  function rate 
   */
  setStar(value) async {
    setState(() {
      load = true;
    });

    var his = widget.idother;
    var id_c = widget.id;

    var response = await parse_s
        .getparse('rate?where={"id_receive":"$his","id_cov":"$id_c"}');

    print("_________________________________0");

    print(response["results"]);

    var a = response["results"];

    for (var i in response["results"]) {
      if (i["id_send"] != widget.myid) {
        list.add(i["rate"]);
      }
    }

    // list.add(value);
    if (exist == true) {

      list.add(value);

      await parse_s.putparse('rate/' + id_rate, {
        "rate": value,
        "id_cov": widget.id,
        "id_send": widget.myid,
        "id_receive": widget.idother,
        "author": {
          "__type": "Pointer",
          "className": "users",
          "objectId": widget.myid
        }
      });



    } else {
      list.add(value);

      //count++;

      await parse_s.postparse('rate', {
        "rate": value,
        "id_cov": widget.id,
        "id_send": widget.myid,
        "id_receive": widget.idother,
        "author": {
          "__type": "Pointer",
          "className": "users",
          "objectId": widget.myid
        }
      });
    }


    for (var i = 0; i < list.length; i++) {

      count++;
      print(list[i]);

      sum += list[i] ;
    }

    print(
        "--------------------------------------------------------------------------------------");
    print(count);

    var truncated = sum ~/ count;
    var js = {"rating": truncated, "count_r": count};

    await parse_s.putparse("offers/" + widget.id, js);

    setState(() {
      load = false;
    });

    print(truncated);
    Navigator.pop(widget.context, [truncated, count]);

    /* var js = {
      "bio":widget.user.bio
    };

 parse_s.putparse("offers/" + widget.user.id, js);
    Navigator.pop(context, widget.user);


    Firestore.instance.document("users/" + user_id).updateData({
      'rating.$me_id': value
      //firestore plugin doesnt support deleting, so it must be nulled / falsed
    });

  }

  setFinal(val,user_id){
    Firestore.instance.document("users/" + user_id).updateData({
      'rate': val
      //firestore plugin doesnt support deleting, so it must be nulled / falsed
    });*/
  }

  @override
  Widget build(BuildContext context) {


    return new WillPopScope(
        onWillPop: () {
          Navigator.pop(context, [widget.rate ,widget.count]);
        },
        child: new Column(
          children: <Widget>[
            _buildRatingBar(),

            new Container(height: 16.0),

            load
                ? new Center(child: new RefreshProgressIndicator())
                : new Container(),
            // dialog bottom
             new Padding(
                padding: new EdgeInsets.symmetric(vertical: 4.0),
                child: new RaisedButton(
                  onPressed: () => show ? setStar(_rating) : null,
                  color: Fonts.col_app,
                  child: new Text("Confirmer".toUpperCase(),
                      style: new TextStyle(
                          color: Colors.white,
                          fontSize: 18.0,
                          fontWeight: FontWeight.w500)),

              ),

              /*LoDocDesign.btn(LoDocText.of(context).confirm(), 200.0,  goto(context, chng)*/
            ),
            new Container(
              height: 16.0,
            )
          ],
        ));
  }
}
