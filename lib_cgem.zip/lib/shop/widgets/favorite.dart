import 'package:flutter/material.dart';
import 'package:medz/parc_events_stream/parc_events_stream.dart';

class FavoriteShps extends StatefulWidget {
  FavoriteShps(
      this.user, this.lat, this.lng, this.list_partner, this.analytics, this.chng);

  var user;
  var lat;
  var lng;
  List list_partner;
  var analytics;

  var chng;

  @override
  _FavoriteShpsState createState() => _FavoriteShpsState();
}

class _FavoriteShpsState extends State<FavoriteShps> {
  int count1 = 0;

  setSount1(c) {
    setState(() {
      count1 = c;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: new AppBar(
            title: new Text(count1 == 0
                ? "Favoris"
                : "Favoris" + " (" + count1.toString()+")")),
        /* appBar: CustomAppBar((s) {
          setState(() {
            searchTerm = s;
          });
        }, scaffoldKey),*/
        body: new StreamParcPub(
          Container(),
          widget.lat,
          widget.lng,
          widget.user,
          "0",
          widget.list_partner,
          widget.analytics,
          setSount1,
          widget.chng,
          category: "boutique",
          favorite: true,
          boutique: false,
        ));
  }
}
