
import 'package:medz/shop/models/Product.dart';

class WishList {
  WishList();
  List<Product> products = [];
}
