import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/shop.dart';

class EmailverifyServices {
  static ParseServer parse_s = new ParseServer();

  static get_contact_by_email(String email) async {
    String url = "";

    url =
        'contacts?where= {"\$or":[{"emails":{"\$eq":"$email"}},{"membre":{"\$inQuery":{"where":{"emails":"$email"},"className":"membres"}}}]}&include=membre&include=fonction';

    var getcity = await parse_s.getparse(url);
    if (getcity == "No Internet") return "No Internet";
    if (getcity == "error") return "error";
    List res = getcity["results"];
    return res;
  }
}
