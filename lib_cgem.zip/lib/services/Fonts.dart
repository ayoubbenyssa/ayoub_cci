import 'package:flutter/material.dart';


class Fonts {
  static const Color col_ap =     const Color(0xff5f50cc);//0b72a4);
  static const Color col_app_light =     const Color(0xffeef6f8);//0b72a4);

  static const Color col_app =     const Color(0xff37b1d5);//0b72a4);
  static const Color col_app_fon =const Color(0xff443a8c);
  static const Color col_app_shadow = const Color(0xfff5fafb);
  static const Color col_app_fonn = const Color(0xff443a8c);
  static const Color col_ap_fonn = const Color(0xff17104e);

  static const Color col_app_green = const Color(0xff50bbd9);//Color(0xff00b281);
  static const Color col_green = const Color(0xfffdfdff);
  static const Color col_grey = const Color(0xffb0b6c5);
  static const Color col_gr = const Color(0xffe97656);
/// 1491c0
  static TextStyle st(size) => TextStyle(
      color: Colors.black,
      fontSize: size,
      fontWeight: FontWeight.w600);
  static const Color col_cl = const Color(0xffebebeb);
  static var footer = new TextStyle(
      color: col_app, fontWeight: FontWeight.w600, fontSize: 9.5);

  static List<Color> kitGradients = [
    // new Color.fromRGBO(103, 218, 255, 1.0),
    // new Color.fromRGBO(3, 169, 244, 1.0),
    // new Color.fromRGBO(0, 122, 193, 1.0),
    col_app,
    Colors.blue[200],
  ];


}
