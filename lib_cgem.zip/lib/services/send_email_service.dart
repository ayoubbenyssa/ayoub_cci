import 'package:http/http.dart' as clientHttp;


class EmailService {


  static sendCustomMail(String emails, subject, message)  async{
   var res =  await clientHttp.post(
        "https://us-central1-sante-ae15e.cloudfunctions.net/sendCustomMailToUserMyCGEM",
        body: {"subject": subject, "message": message, "email": emails});


   print(res.body);

   return res.body;

  }
}
