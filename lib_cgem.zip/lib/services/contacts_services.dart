import 'dart:convert';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/membre.dart';
import 'package:medz/models/objectif.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/pro.dart';
import 'package:medz/models/region.dart';
import 'package:medz/models/resp.dart';
import 'package:medz/models/shop.dart';
import 'package:medz/models/ville.dart';

class Contacts_services {
  static ParseServer parse_s = new ParseServer();

  static get_list_contacts_by_id_membre(String id_membre) async {
    //,"sponsored":1
    String url = 'contacts?where={"id_membre":"$id_membre"}&order=-createdAt';
    var getres = await parse_s.getparse(url);
    if (getres == "No") return "No";
    if (getres == "error") return "error";
    List res = getres["results"];

    return res
        .map((var contactRaw) => new Contact.fromMap(contactRaw))
        .toList();

  }

}