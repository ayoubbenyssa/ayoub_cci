

import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/category_shop.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/sector.dart';

class SectorsServices {

static   ParseServer parseFunctions = new ParseServer();


   static get_list_sectors() async {
    String url = 'sectors?order=name';
    var sect = await parseFunctions.getparse(url);
    if (sect == "No Internet") return "No Internet";
    if (sect == "error") return "error";
    List res =  sect["results"];
    return res.map((var contactRaw) => new Sector.fromMap(contactRaw))
        .toList();
  }


static get_list_sectors1() async {
  String url = 'sectors_convention?order=name';
  var sect = await parseFunctions.getparse(url);
  if (sect == "No Internet") return "No Internet";
  if (sect == "error") return "error";
  List res =  sect["results"];
  return res.map((var contactRaw) => new Sector.fromMap(contactRaw))
      .toList();
}


static get_list_com() async {
  String url = 'commissions?order=name';
  var sect = await parseFunctions.getparse(url);
  if (sect == "No") return "No";
  if (sect == "error") return "error";
  List res =  sect["results"];
  return res.map((var contactRaw) => new Commission.fromDoc(contactRaw))
      .toList();
}




static get_list_fed() async {
  String url = 'federations?order=name';
  var sect = await parseFunctions.getparse(url);
  if (sect == "No") return "No";
  if (sect == "error") return "error";
  List res =  sect["results"];
  return res.map((var contactRaw) => new Commission.fromDoc(contactRaw))
      .toList();
}





static get_list_category() async {

  String url = 'categories_shop';
  var sect = await parseFunctions.getparse(url);
  if (sect == "No Internet") return "No Internet";
  if (sect == "error") return "error";
  List res =  sect["results"];
  return res.map((var contactRaw) => new CategoryShop.fromMap(contactRaw))
      .toList();
}


}