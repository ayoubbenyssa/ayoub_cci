import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:medz/annonces/details_annonce.dart';
import 'package:medz/cards/details_parc.dart';
import 'package:medz/cards/like_widget.dart';
import 'package:medz/cards/likes.dart';
import 'package:medz/cards/participatebutton.dart';
import 'package:medz/cards/prom_details.dart';
import 'package:medz/co_voiturage/alert_rate.dart';
import 'package:medz/co_voiturage/comments/comments.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/commentsfunctions.dart';
import 'package:medz/services/like_wall_function.dart';
import 'package:medz/shop/pages/product_page.dart';

class CardFooter extends StatefulWidget {
  CardFooter(this.an, this.user, this.deletepost, this.context, this.list,
      this.analytics, this.lat, this.lng, this.onLocaleChange,
      {this.ratefunc});

  var an;
  var deletepost;
  var context;
  User user;
  var list;
  var analytics;
  double lat;
  double lng;
  var onLocaleChange;
  var ratefunc;

  @override
  _CardFooterState createState() => new _CardFooterState();
}

class _CardFooterState extends State<CardFooter> {
  String _value1 = 'addfav';
  CommentFunctions commentFunctions = new CommentFunctions();

  //likes
  LikeFunctions likeFunctions = new LikeFunctions();

  var likestext = "Likes";

  var load = true;

  bool wait = false;

  /* toggletar() async {
    /* _heartAnimationController.forward().whenComplete(() {
      _heartAnimationController.reverse();
    });*/
    setState(() {
      wait = true;
    });
    var res =
        await likeFunctions.like(widget.an.objectId, context, widget.user.id);
    if (res == "nointernet") {
    } else if (res == "error") {
    } else {
      try {
        setState(() {
          widget.an.isLiked = res["isLiked"];
          widget.an.likesCount = res["numberLikes"];
          wait= false;
        });
      } catch (e) {}
    }
  }*/
  func_update_comment(num) {
    setState(() {
      widget.an.numbercommenttext =
          (int.parse(widget.an.numbercommenttext) + num).toString();
    });
  }

  func_update_likes(i) {
    setState(() {
      widget.an.likes_post = (int.parse(widget.an.likes_post) + i).toString();
    });
  }

  rate() async {
    List off = await AlertRate.dialog2(
        context,
        widget.an.name,
        widget.an.pic[0],
        widget.an.rating,
        widget.an.objectId,
        widget.an.count_r,
        context,
        my_id: widget.user.id,
        id_other: widget.an.objectId);
    setState(() {
      widget.an.rating = off[0];
      widget.an.count_r = off[1];
    });

    widget.ratefunc(widget.an);
  }

  @override
  initState() {
    super.initState();
    /* isliked();
    getnumbers();
    getNumbeComments();*/
  }

  func() {
    setState(() {
      widget.an.numbercommenttext =
          (int.parse(widget.an.numbercommenttext) + 1).toString();
    });
  }

  getnumbers() async {
    var count = await likeFunctions.likes(widget.an.objectId);
    try {
      setState(() {
        print("-----------------------------------");
        print(count);
        widget.an.likesCount = count;
        likestext = "  j'aime";
        if (widget.an.likesCount.toString() == "1") likestext = "  j'aime";
      });
    } catch (e) {}
  }

  getNumbeComments() {
    commentFunctions.numberComments(widget.an.objectId).then((count) {
      try {
        setState(() {
          widget.an.numbercommenttext = count.toString() /*+" Comments"*/;
        });
      } catch (e) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget numbercomments = widget.an.numbercommenttext.toString() == "0"
        ? Container()
        : new Text(
            widget.an.numbercommenttext.toString() +
                ( widget.an.numbercommenttext.toString() ==
                    "1"
                ? " Commentaire"
                : " Commentaires"),
            style: new TextStyle(
                fontWeight: FontWeight.w600,
                color: Fonts.col_ap_fonn,
                fontSize: 14.5),
          );

    Widget textlike = widget.an.likes_post.toString() != "null" &&
            widget.an.likes_post.toString() != "0"
        ? new Text(
            widget.an.likes_post.toString() == "null"
                ? "0"
                : widget.an.likes_post.toString() + " J'aime",
            style: new TextStyle(
                color: Colors.blue[300],
                fontSize: 15.5,
                fontWeight: FontWeight.w600))
        : Container();

    Widget decodertoggletar = new Container(
        child: widget.an.isLiked
            ? new Image.asset("images/hand.png", width: 18.0, height: 18.0)
            : new Image.asset("images/handn.png", width: 18.0, height: 18.0));

    Widget iconlike = decodertoggletar;

    goto() {}

    return new Container(
        padding: EdgeInsets.only(left: 12, right: 12),
        child: Column(children: [
          Container(
            height: 4,
          ),
          widget.an.type == "event"
              ? ParticipateButton(widget.an, widget.user, null, context)
              : Container(),
          Container(
            height: 4,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              InkWell(
                child: textlike,
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute<Null>(
                          builder: (BuildContext context) => new LikeList(
                              widget.lat,
                              widget.lng,
                              widget.user,
                              widget.onLocaleChange,
                              widget.an.objectId)));

                  //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                },
              ),
              Expanded(
                child: Container(),
              ),
              new InkWell(
                child: numbercomments,
                onTap: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute<Null>(
                          builder: (BuildContext context) => new Comments(
                              widget.an,
                              "",
                              true,
                              widget.user,
                              func_update_comment,
                              widget.onLocaleChange)));

                  //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                },
              ),
              Container(
                width: 12,
              ),
            ],
          ),
          new Container(
              color: /*const Color(0xffedd9ac)*/ Colors.white,
              child: new Container(
                  height: MediaQuery.of(context).size.height * 0.06,
                  margin: new EdgeInsets.only(
                      left: 4.0, right: 4.0, bottom: 6.0, top: 0.0),
                  child: Center(
                      child: new Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          //crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                        FavoriteButton(
                          widget.an,
                          widget.user,
                          false,
                          func_update_likes,
                        ),
                        /* new InkWell(
                      onTap: () => toggletar(),
                    */
                        new Container(
                          width: 8.0,
                        ),
                        //  textlike,

                        new InkWell(
                          child: Row(children: [
                            new Image.asset("images/cht.png",
                                color: Fonts.col_ap_fonn,
                                width: 18.0,
                                height: 18.0),
                            Text("  Commenter",
                                style: new TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: Fonts.col_ap_fonn,
                                    fontSize: 14.5)),
                          ]),
                          onTap: () async {
                            Navigator.push(
                                context,
                                new MaterialPageRoute<Null>(
                                    builder: (BuildContext context) =>
                                        new Comments(
                                            widget.an,
                                            "",
                                            true,
                                            widget.user,
                                            func_update_comment,
                                            widget.onLocaleChange)));

                            //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                          },
                        ),

                        /*new InkWell(
                          child: Row(
                            children: [
                              new Image.asset("images/share1.png",
                                  color: Fonts.col_app_fonn,
                                  width: 18.0,
                                  height: 18.0),
                              Text("  Partager",
                                  style: new TextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: Fonts.col_app_fonn,
                                      fontSize: 14.5)),
                            ],
                          ),
                          onTap: () async {
                            Navigator.push(
                                context,
                                new MaterialPageRoute<Null>(
                                    builder: (BuildContext context) =>
                                        new Comments(widget.an, "", true,
                                            widget.user, func)));

                            //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                          },
                        ),*/

                        new Container(
                          width: 8.0,
                        ),
                        /* widget.an.type == "event"
                      ? CircleAvatar(
                          backgroundColor: Colors.white,
                          child: InkWell(
                              onTap: () {
                                rate();
                              },
                              child: new Image.asset(
                                "images/medal.png",
                                color: Colors.black,
                                width: 18.0,
                                height: 18.0,
                              )))
                      : Container(),*/

                        /**
                                widget.an.type == "event"
                                ? widget.an.docUrl == null || widget.an.docUrl == ""
                                ? Container()
                                : CircleAvatar(
                                backgroundColor: Colors.white,
                                // backgroundColor: Colors.amber[400],
                                child: InkWell(
                                onTap: () {
                                /* Navigator.push(context,
                                new MaterialPageRoute<String>(
                                builder:
                                (BuildContext context) {
                                return new Scaffold(
                                appBar: AppBar(
                                title: new Text(
                                widget.an.name,
                                ),
                                ),
                                body: SimplePdfViewerWidget(
                                completeCallback:
                                (bool result) {
                                print(
                                "completeCallback,result:${result}");
                                },
                                initialUrl: widget.an.docUrl,
                                ),
                                );
                                }));*/
                                },
                                child: new Image.asset(
                                "images/pdf.png",
                                color: Colors.black,
                                width: 18.0,
                                height: 18.0,
                                )))
                                : Container(),
                             */

                        /*

                    Navigator.push(context, new MaterialPageRoute<String>(
                  builder: (BuildContext context) {
                return new  Scaffold(
                  appBar: AppBar(
                    title: const Text('Plugin example app'),
                  ),
                  body: SimplePdfViewerWidget(
                    completeCallback: (bool result){
                      print("completeCallback,result:${result}");
                    },
                    initialUrl: "https://www.orimi.com/pdf-test.pdf",
                  ),
                );
              }));
                   */

                        /* widget.an.author.toString() == "null"
                      ? Container()
                      : widget.user.auth_id == widget.an.author.auth_id
                          ? Container()
                          : new InkWell(
                              child: new Image.asset("images/cht.png",
                                  color: Colors.green[600],
                                  width: 26.0,
                                  height: 26.0),
                              onTap: () async {
                                Navigator.push(context, new MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return new ChatScreen(
                                      widget.user.auth_id,
                                      widget.an.author.auth_id,
                                      goto,
                                      false,
                                      null,
                                      widget.analytics,
                                      widget.onLocaleChange,
                                      user: widget.user);
                                }));

                                //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                              },
                            ),*/
                        Container(
                          width: 8,
                        ),
                        widget.an.author.toString() == "null"
                            ? Container()
                            : widget.an.author.id == widget.user.id
                                ? new InkWell(
                                    child: new Image.asset(
                                        "images/icons/delete.png",
                                        color: Colors.red[700],
                                        width: 22.0,
                                        height: 22.0),
                                    onTap: () async {
                                      await showDialog<String>(
                                            context: context,
                                            child: new AlertDialog(
                                              title: const Text(''),
                                              content: const Text(
                                                  'Voulez vous supprimer ce post ?'),
                                              actions: <Widget>[
                                                new FlatButton(
                                                    child: const Text('Ok'),
                                                    onPressed: () {
                                                      widget.deletepost();

                                                      Navigator.of(context,
                                                              rootNavigator:
                                                                  true)
                                                          .pop('dialog');
                                                    }),
                                                new FlatButton(
                                                  child: const Text('Cancel'),
                                                  onPressed: () {
                                                    Navigator.of(context,
                                                            rootNavigator: true)
                                                        .pop('dialog');
                                                  },
                                                ),
                                              ],
                                            ),
                                          ) ??
                                          false;

                                      //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                                    },
                                  )
                                : Container(),
                        new Expanded(
                            child: new Container(
                          width: 2.0,
                        )),

                        widget.an.type != "sondage" &&
                                widget.an.type != "opportunite" &&
                                widget.an.type != "video" &&
                                widget.an.type != "prod_service"
                            ? new RaisedButton(
                                color: Colors.grey[100],
                                elevation: 0,
                                padding: EdgeInsets.all(0),
                                shape: new RoundedRectangleBorder(
                                    borderRadius: new BorderRadius.all(
                                  Radius.circular(6.0),
                                )),
                                // padding: EdgeInsets.all(0),
                                onPressed: () {
                                  if (widget.an.type == "Annonces" ||
                                      widget.an.type == "Objets perdus" ||
                                      widget.an.type == "Général" ||
                                      widget.an.type == "Général") {
                                    Navigator.push(context,
                                        new MaterialPageRoute(
                                            builder: (BuildContext context) {
                                      return new DetailsAnnonce(
                                          widget.an,
                                          widget.user,
                                          widget.list,
                                          null,
                                          widget.analytics,
                                          widget.onLocaleChange);
                                    }));
                                  } else if (widget.an.type == "news" ||
                                      widget.an.type == "event") {
                                    Navigator.push(context,
                                        new MaterialPageRoute(
                                            builder: (BuildContext context) {
                                      return new DetailsParc(
                                          widget.an,
                                          widget.user,
                                          widget.an.type,
                                          widget.list,
                                          null,
                                          widget.analytics,
                                          widget.onLocaleChange,
                                          widget.lat,
                                          widget.lng);
                                    }));
                                  } else if (widget.an.type == "promotion") {
                                    Navigator.push(context,
                                        new MaterialPageRoute(
                                            builder: (BuildContext context) {
                                      return new Promo_details(
                                          widget.an,
                                          widget.user,
                                          widget.lat,
                                          widget.lng,
                                          widget.onLocaleChange);
                                    }));
                                  } else if (widget.an.type == "boutique") {
                                    Navigator.push(
                                        context,
                                        new MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                ProductPage(
                                                    widget.an,
                                                    widget.user,
                                                    widget.lat,
                                                    widget.lng,
                                                    widget.onLocaleChange)));
                                  }
                                },
                                child: Container(
                                    padding: EdgeInsets.only(left: 2, right: 2),
                                    child: Text(
                                      LinkomTexts.of(context).details(),
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14.5,
                                        color: Fonts.col_app_green,
                                      ),
                                    )))
                            : Container(),
                        Container(
                          width: 0,
                        )
                        /*  widget.an.type != "sondage" && widget.an.type != "opportunite"
                      ? new RaisedButton(
                          color: Colors.grey[100],
                          elevation: 1,
                          shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.all(
                            Radius.circular(6.0),
                          )),
                          // padding: EdgeInsets.all(0),
                          onPressed: () {
                            if (widget.an.type == "Annonces" ||
                                widget.an.type == "Objets perdus" ||
                                widget.an.type == "Général" ||
                                widget.an.type == "Général") {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new DetailsAnnonce(
                                    widget.an,
                                    widget.user,
                                    widget.list,
                                    null,
                                    widget.analytics,
                                    widget.onLocaleChange);
                              }));
                            } else if (widget.an.type == "news" ||
                                widget.an.type == "event") {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new DetailsParc(
                                    widget.an,
                                    widget.user,
                                    widget.an.type,
                                    widget.list,
                                    null,
                                    widget.analytics,
                                    widget.onLocaleChange,
                                    widget.lat,
                                    widget.lng);
                              }));
                            } else if (widget.an.type == "promotion") {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new Promo_details(
                                    widget.an,
                                    widget.user,
                                    widget.lat,
                                    widget.lng,
                                    widget.onLocaleChange);
                              }));
                            } else if (widget.an.type == "boutique") {
                              Navigator.push(
                                  context,
                                  new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          ProductPage(
                                              widget.an,
                                              widget.user,
                                              widget.lat,
                                              widget.lng,
                                              widget.onLocaleChange)));
                            } else {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new DetailsParc(
                                    widget.an,
                                    widget.user,
                                    widget.an.type,
                                    widget.list,
                                    null,
                                    widget.analytics,
                                    widget.onLocaleChange,
                                    widget.lat,
                                    widget.lng);
                              }));
                            }
                          },
                          child: Container(
                              child: Text(
                            LinkomTexts.of(context).details(),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: ScreenUtil.getInstance().setSp(30),
                              color: Fonts.col_app_green,
                            ),
                          )))
                      : Container(),*/
                        ,
                      ])))),
        ])); //2E9E51
  }
}
