import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as prefix0;
import 'package:latlong/latlong.dart';
import 'package:medz/cards/opp_card.dart';
import 'package:medz/cards/pub_parc_card.dart';
import 'package:medz/cards/sonagecard.dart';
import 'package:medz/co_voiturage/cov_card.dart';
import 'package:medz/communities/communities.dart';
import 'package:medz/communities/federations.dart';
import 'package:medz/fils_actualit/wall_card.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/checked.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/posts_services.dart';
import 'package:medz/widgets/fixdropdown.dart';
import 'package:medz/widgets/groups_commission.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class StreamPots extends StatefulWidget {
  StreamPots(this.user, this.lat, this.lng, this.list_partners, this.analytics,
      this._isVisible1, this._hide_bar_mur, this.chng);

  User user;
  var lat;
  var lng;
  var list_partners;
  var analytics;
  var _isVisible1;
  var _hide_bar_mur;
  var chng;

  @override
  _StreamPotsState createState() => _StreamPotsState();
}

class _StreamPotsState extends State<StreamPots> {
  List<Offers> list = new List<Offers>();
  List<Offers> list_offers = new List<Offers>();
  var noPost = "";
  String selectedValue = "Actualités";

  List<Offers> cov_list = new List<Offers>();
  List<Offers> all_list = new List<Offers>();
  List<Offers> pub_list = new List<Offers>();
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      new GlobalKey<RefreshIndicatorState>();
  SliverPersistentHeaderDelegate delegate;
  List listWidget = new List();
  bool isLoading = true;
  int skip = 0;
  var count = 0;
  var count2 = 0;
  ParseServer parseFunctions = new ParseServer();
  String verify;
  List<Offers> son_list = new List<Offers>();
  String select_result = "";

  var j = 0;
  List<Offers> shop_list = new List<Offers>();
  List<Offers> event_list1 = new List<Offers>();
  List<Offers> promo_list = new List<Offers>();
  List<Offers> promo_list1 = new List<Offers>();

  List<Offers> news_list = new List<Offers>();

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();

    selectedValue_c = LinkomTexts.of(context).ccom();
    selectedValue_f = LinkomTexts.of(context).cfed();
    selected_type = "news";
    selectedValue = LinkomTexts.of(context).actu();
    _list = [
      /* {
        "name": LinkomTexts.of(context).tous(),
        "type": "tous",
        "isSelected": true
      },*/
      {
        "name": LinkomTexts.of(context).actu(),
        "type": "news",
        "isSelected": true
      },
      {"name": "Ma région", "type": "maregion", "isSelected": false},
      {
        "name": LinkomTexts.of(context).oppo(),
        "type": "opportunite",
        "isSelected": false
      },
      {"name": "mes Fédérations", "type": "federations", "isSelected": false},
      {"name": "Mes commissions", "type": "commissions", "isSelected": false},
      {
        "name": LinkomTexts.of(context).agenda(),
        "type": "event",
        "isSelected": false
      },
     /* {
        "name": LinkomTexts.of(context).tarifs(),
        "type": "cgem",
        "isSelected": false
      },
      /*{
        "name": LinkomTexts.of(context).ava(),
        "type": "linkommunity",
        "isSelected": false
      },*/
      {
        "name": LinkomTexts.of(context).prodss(),
        "type": "prod_service",
        "isSelected": false
      },*/
    ];

    print("hdhdhd");
    print(widget.user.commissions.length);
    print(widget.user.entreprise.name);
    print(widget.user.entreprise.region);

    if (widget.user.commissions.length == 0)
      _list.remove(_list
          .where((element) => element["type"] == "commissions")
          .elementAt(0));
    if (widget.user.entreprise.region.toString() == "null")
      _list.remove(
          _list.where((element) => element["type"] == "maregion").elementAt(0));
    if (widget.user.entreprise.federation.toString() == "null")
      _list.remove(_list
          .where((element) => element["type"] == "federations")
          .elementAt(0));
  }

  Future<List<Offers>> getLIst() async {
    all_list = [];
    list = [];
    news_list = [];
    event_list1 = [];
    promo_list = [];
    promo_list1 = [];

    shop_list = [];
    pub_list = [];
    j = 0;

    if (selectedValue != LinkomTexts.of(context).tous()) {

      var a = await PostsServices.get_pub_type(
        skip * 4,
        selected_type,
        widget.user,
        verify,
        selected: selectedValue,
      );
      setState(() {
        list = List<Offers>.from(a["results"]);
      });
    } else {
      var a = await PostsServices.get_recent_friend_pub(
          widget.user.id, skip * 2, verify);
      pub_list = List<Offers>.from(a["results"]);

      var s = await PostsServices.get_sondage(widget.user, skip, verify);
      son_list = List<Offers>.from(s["results"]);

      var b = await PostsServices.get_events(widget.user, skip * 4, verify);

      all_list = b["results"];

      var eve = await PostsServices.get_event_(widget.user, skip);
      event_list1 = eve["results"];

      all_list.forEach((offers) {
        if (offers.type == "news") {
          news_list.add(offers);
        }
        /*else if (offers.type == "event") {
          event_list1.add(offers);
        } */
        else if (offers.type == "opportunite") {
          promo_list.add(offers);
        } else if (offers.type == "promotion") {
          promo_list1.add(offers);
        } else if (offers.type == "prod_service") {
          shop_list.add(offers);
        }
      });

      /* var c  = await PostsServices.get_news(widget.user, skip);
    news_list = c["results"];

    var d  = await PostsServices.get_promo(widget.user, skip);
    promo_list = d["results"];*/

      /* var f  = await PostsServices.get_shop(widget.user, skip);
    shop_list = f["results"];*/

      count = a["count"] + b["count"];

      if (this.mounted)
        setState(() {
          isLoading = false;
        });

      for (int i = 1; i < 30; i = i + 2) {
        //  j = i;

        if (event_list1.length > j) {
          list.add(event_list1[j]);
        }

        if (pub_list.length > i) {
          list.add(pub_list[i]);
        }

        if (pub_list.length >= i) {
          list.add(pub_list[i - 1]);
        }

        if (news_list.length > j) {
          list.add(news_list[j]);
        }

        if (promo_list.length > j) {
          list.add(promo_list[j]);
        }

        if (son_list.length > j) {
          list.add(son_list[j]);
        }

        if (promo_list1.length > j) {
          list.add(promo_list1[j]);
        }

        if (shop_list.length > j) {
          list.add(shop_list[j]);
        }

        j++;
      }

      setState(() {
        list_offers = list;
      });
    }
    return list;
  }

  errorrequest(text) {
    var errorWithYourRequest = "Error";
    if (text == "nointernet")
      errorWithYourRequest = "Vérifier votre connexion internet!";
    Scaffold.of(context).showSnackBar(new SnackBar(
      duration: new Duration(seconds: 5),
      content: new Text(errorWithYourRequest,
          style: new TextStyle(color: Colors.red[900])),
      action: new SnackBarAction(
          label: "try again",
          onPressed: () {
            streampost(skip);
          }),
    ));
  }

  Distance distance = new Distance();
  String selected_type = "";

  eventcard(Offers postdata) {
    if (postdata.latLng.isNotEmpty && postdata.latLng.toString() != "null") {
      print("ghdugdu");
      print(postdata.latLng);

      if (postdata.latLng.split(";")[0].toString() == "null" ||
          postdata.latLng.split(";")[0] == "") {
        postdata.dis = "-.- Km";
      } else
        postdata.dis = distance
                .as(
                    LengthUnit.Kilometer,
                    new LatLng(double.parse(postdata.latLng.split(";")[0]),
                        double.parse(postdata.latLng.split(";")[1])),
                    new LatLng(widget.lat, widget.lng))
                .toString() +
            " Km(s)";
    } else {
      postdata.dis = "-.- Km";
    }
    return Container(
        child: new ParcPubCard(postdata, widget.user, true, [], null,
            widget.analytics, context, widget.lat, widget.lng, widget.chng));
  }

  showwidgets(List<Offers> result) {
    //if (skip == 0) count = result.length ;

    for (Offers item in result) {
      count2++;

      /* if (item.latLng.toString() != "null") {
         item.dis = distance
             .as(
             LengthUnit.Kilometer,
             new LatLng(double.parse(item.latLng.split(";")[0]),
                 double.parse(item.latLng.split(";")[1])),
             new LatLng(widget.lat, widget.lng))
             .toString() +
             " Km(s)";
      } else {

         item.dis = "-.- Km";


       }*/

      listWidget.add(item.type == "sondage"
          ? SondageCard(widget.user, item, list, widget.chng)
          : item.type == "event"
              ? eventcard(item)
              : item.type == "opportunite"
                  ? new OppCard(item, widget.user, widget.lng, widget.lat,
                      context, false, widget.chng)
                  : Wall_card(item, widget.user, widget.list_partners,
                      widget.lat, widget.lng, widget.analytics, widget.chng));
    }

    setState(() => skip += 5);

    /*list.map((Offers item) {
       count2++;

       return item.type == "cov"
           ? Cov_Card(
         item,
         widget.user,
         null,
         null,
         widget.list_partners,
         lat: widget.lat,
         lng: widget.lng,
       )
           : Wall_card(item, widget.user, widget.list_partners);
     }).toList();*/
  }

  streampost(skipp) async {
    if (skipp == 0) listWidget = new List();
    List<Offers> result = await getLIst();

    if (!this.mounted) return;

    try {
      setState(() => isLoading = false);
    } catch (e) {
      e.toString();
    }
    if (result == "nointernet" || result == "error")
      errorrequest(result);
    else if (result == "empty" || result == "nomoreresults")
      noPosts(result);
    else
      showwidgets(result);
  }

  getdata() async {
    widget._hide_bar_mur.addListener(() {
      if (widget._hide_bar_mur.position.atEdge) {
//  if (count2 < count)
        streampost(count2);
      }
    });
    await getUser(widget.user.id);
    streampost(skip);
  }

  getUser(id) async {
    var a = await parseFunctions
        .getparse('users?where={"objectId":"$id"}&include=respons');
    if (!this.mounted) return;
    print(a);

    setState(() {
      verify = a["results"][0]["verify"].toString();
      print(verify);
    });
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 300)).then((value) async {
      getdata();
    });
  }

  noPosts(type) {
    try {
      if (type == "nomoreresults")
        setState(() => noPost = "Il n y a aucun autre résultat");
      else
        setState(() => noPost = "Aucun post trouvé");
    } catch (e) {
      e.toString();
    }
  }

  getrefresh() {
    skip = 0;

    streampost(0);
    Completer<Null> completer = new Completer<Null>();
    new Timer(new Duration(seconds: 3), () {
      completer.complete();
    });
    return completer.future;
  }

  Reload() {
    setState(() {
      isLoading = true;
    });

    skip = 0;
    streampost(0);
  }

  List _list = [];

  filter_no() {
    setState(() {
      selectedValue = LinkomTexts.of(context).tous();
      select_result = "";

      selectedValue_c = LinkomTexts.of(context).ccom();
      selectedValue_f = "";
    });
    Reload();
  }

  Widget drop_down() => new Container(
      color: Fonts.col_app_shadow,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height * 0.09,
      child: Row(
        children: <Widget>[
          Container(
              width: MediaQuery.of(context).size.width * 0.7,
              margin: const EdgeInsets.all(8.0),
              padding: const EdgeInsets.only(left: 16.0, right: 0.0),
              decoration: new BoxDecoration(
                color: Fonts.col_app_shadow,
                border: new Border.all(color: Fonts.col_app_shadow, width: 0.8),
                borderRadius: new BorderRadius.circular(2.0),
              ),
              child: new FixDropDown(
                  iconSize: 32.0,
                  isDense: false,
                  items: _list.map((dynamic value) {
                    return new FixDropdownMenuItem(
                      value: value,
                      child: new Text(
                        value["name"].toString(),
                        maxLines: 2,
                        softWrap: true,
                        style: TextStyle(color: Fonts.col_app_fonn),
                      ),
                    );
                  }).toList(),
                  hint: new Text(
                    selectedValue,
                    maxLines: 1,
                    softWrap: true,
                    style: new TextStyle(color: Fonts.col_app_fonn),
                  ),
                  onChanged: (dynamic value) {
                    /* if (value["type"] == 'tous') {
                      setState(() {
                        selectedValue = LinkomTexts.of(context).tous();
                      });
                      Reload();
                    } else {*/
                    setState(() {
                      selectedValue = value["name"];
                      selected_type = value["type"];
                      //com = value;
                      Reload();
                    });
                    //  }
                  })),
          Expanded(
            child: Container(),
          ),
          InkWell(
            onTap: () {
              filter_no();
            },
            child: Container(
                padding: EdgeInsets.only(left: 16),
                child: FloatingActionButton(
                    heroTag: '12222',
                    mini: true,
                    elevation: 12,
                    backgroundColor: Fonts.col_app,
                    child: Container(
                        padding: EdgeInsets.all(4),
                        child: Image.asset(
                          "images/fil.png",
                          color: Colors.white,
                          //color: Fonts.col_app,
                        )))),
          ),
          Container(
            width: 16,
          )
        ],
      ));

  String selectedValue_c = "";
  String selectedValue_f = "";

  bool commission_bool = false;

  Widget drop_down_commission() => new Container(
      color: Fonts.col_app_shadow,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height * 0.09,
      child: Row(
        children: <Widget>[
          Container(
              width: MediaQuery.of(context).size.width * 0.76,
              margin: const EdgeInsets.all(8.0),
              padding: const EdgeInsets.only(left: 16.0, right: 0.0),
              decoration: new BoxDecoration(
                color: Fonts.col_app_shadow,
                border: new Border.all(color: Fonts.col_app_shadow, width: 0.8),
                borderRadius: new BorderRadius.circular(2.0),
              ),
              child: new FixDropDown(
                  iconSize: 32.0,
                  isDense: false,
                  items: widget.user.commissions.map((dynamic value) {
                    return new FixDropdownMenuItem(
                      value: value,
                      child: new Text(
                        value.name.toString(),
                        maxLines: 2,
                        softWrap: true,
                        style: TextStyle(color: Fonts.col_app_fonn),
                      ),
                    );
                  }).toList(),
                  hint: new Text(
                    selectedValue_c,
                    maxLines: 1,
                    softWrap: true,
                    style: new TextStyle(color: Fonts.col_app_fonn),
                  ),
                  onChanged: (dynamic value) {
                    setState(() {
                      selectedValue = value.objectId;
                      selectedValue_c = value.name;
                      print("11");
                      print(selectedValue_c);
                      selected_type = "commission";
                      //com = value;
                      Reload();
                    });
                    /* if (value["type"] == 'tous') {
                        setState(() {
                          selectedValue_c = "Choisir une commission";
                        });
                        Reload();
                      } else {
                        setState(() {
                          selectedValue = value["name"];
                          selected_type = value["type"];
                          //com = value;
                          Reload();
                        });
                      }*/
                  })),
          Expanded(
            child: Container(),
          ),
          InkWell(
            onTap: () {
              setState(() {
                select_result = "";
                selectedValue = LinkomTexts.of(context).tous();
              });
              Reload();
            },
            child: Container(
                padding: EdgeInsets.only(left: 16),
                child: FloatingActionButton(
                    heroTag: '12222',
                    mini: true,
                    elevation: 12,
                    backgroundColor: Fonts.col_app,
                    child: Container(
                        padding: EdgeInsets.all(4),
                        child: Image.asset(
                          "images/fil.png",
                          color: Colors.white,
                          //color: Fonts.col_app,
                        )))),
          ),
          Container(
            width: 16,
          )
        ],
      ));

  Widget drop_down_fed() => new Container(
      color: Fonts.col_app_shadow,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height * 0.09,
      child: Row(
        children: <Widget>[
          Container(
              width: MediaQuery.of(context).size.width * 0.76,
              margin: const EdgeInsets.all(8.0),
              padding: const EdgeInsets.only(left: 16.0, right: 0.0),
              decoration: new BoxDecoration(
                color: Fonts.col_app_shadow,
                border: new Border.all(color: Fonts.col_app_shadow, width: 0.8),
                borderRadius: new BorderRadius.circular(2.0),
              ),
              child: new FixDropDown(
                  iconSize: 32.0,
                  isDense: false,
                  items: widget.user.fed.map((dynamic value) {
                    return new FixDropdownMenuItem(
                      value: value,
                      child: new Text(
                        value.name.toString(),
                        maxLines: 2,
                        softWrap: true,
                        style: TextStyle(color: Fonts.col_app_fonn),
                      ),
                    );
                  }).toList(),
                  hint: new Text(
                    selectedValue_f != LinkomTexts.of(context).cfed()
                        ? selectedValue_f
                        : LinkomTexts.of(context).cfed(),
                    maxLines: 1,
                    softWrap: true,
                    style: new TextStyle(color: Fonts.col_app_fonn),
                  ),
                  onChanged: (dynamic value) {
                    setState(() {
                      selectedValue = value.objectId;
                      selected_type = "federation";
                      print(value.name);
                      selectedValue_f = value.name;
                      //com = value;
                      Reload();
                    });
                    /* if (value["type"] == 'tous') {
                        setState(() {
                          selectedValue_c = "Choisir une commission";
                        });
                        Reload();
                      } else {
                        setState(() {
                          selectedValue = value["name"];
                          selected_type = value["type"];
                          //com = value;
                          Reload();
                        });
                      }*/
                  })),
          Expanded(
            child: Container(),
          ),
          InkWell(
            onTap: () {
              setState(() {
                select_result = "";
                selectedValue = LinkomTexts.of(context).tous();
              });
              Reload();
            },
            child: Container(
                padding: EdgeInsets.only(left: 16),
                child: FloatingActionButton(
                    heroTag: '12222',
                    mini: true,
                    elevation: 12,
                    backgroundColor: Fonts.col_app,
                    child: Container(
                        padding: EdgeInsets.all(4),
                        child: Image.asset(
                          "images/fil.png",
                          color: Colors.white,
                          //color: Fonts.col_app,
                        )))),
          ),
          Container(
            width: 16,
          )
        ],
      ));

  @override
  Widget build(BuildContext context) {
    Widget buildBody(BuildContext context) {
      Widget loading = new SliverToBoxAdapter(
          child: new Center(
              child: Padding(
                  padding: EdgeInsets.only(top: 32), child: Widgets.load())));
      Widget bottom = new SliverToBoxAdapter(
          child: new Center(
              child: new Container(
                  padding: const EdgeInsets.only(
                      top: 85.0, left: 16.0, right: 16.0, bottom: 16.0),
                  child: new Text(noPost))));
      Widget silverheader = new SliverToBoxAdapter(
          child: Stack(
        children: <Widget>[
          Positioned(
            child: Container(),
          )
        ],
      ));

      Widget listposts = new SliverList(
          delegate:
              new SliverChildListDelegate(new List<Widget>.from(listWidget)));

      Widget scrollview =
          new CustomScrollView(controller: widget._hide_bar_mur, slivers: [
        silverheader,
        // widget.silver == null ? new SliverToBoxAdapter() : widget.silver,
        isLoading ? loading : listposts,
        bottom,
      ]);

      return new RefreshIndicator(
          onRefresh: () => getrefresh(),
          child: scrollview,
          key: _refreshIndicatorKey);
    }

    onPressed(var value) {
      print(selectedValue);
      print("w3");

      setState(() {
        var last_element = _list
            .where((element) => element["name"] == selectedValue)
            .elementAt(0);
        last_element["isSelected"] = false;
        value["isSelected"] = true;
      });

      /* if (value["type"] == 'tous') {
        setState(() {
          selectedValue = LinkomTexts.of(context).tous();
        });
        Reload();
      } else {*/
      setState(() {
        selectedValue = value["name"];
        selected_type = value["type"];
        //com = value;
        Reload();
      });
      // }
    }

    horizontal_list() {
      return Container(
        height: MediaQuery.of(context).size.height*0.08,
        color: Colors.white,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: (_list
              .map((e) => Column(
                    children: [
                      FlatButton(
                        child: Text(
                          e["name"].toUpperCase(),
                          style: TextStyle( fontSize: 15),
                        ),
                        onPressed: () => onPressed(e),
                        textColor:
                            e["isSelected"] ? Fonts.col_app : Fonts.col_ap_fonn,
                      ),
                      Container(
                        height: 0,
                      ),
                      Container(
                        width: 60,
                        height: e["isSelected"] ? 5 : 0,
                        color:
                            e["isSelected"] ? Fonts.col_gr : Fonts.col_ap_fonn,
                      )
                    ],
                  ))
              .toList()),
        ),
      );
    }

    return Container(

      child: Column(
        children: <Widget>[
          /**
              widget._isVisible1 == false
              ? Container()
              : select_result == ""
              ? Container(
              color: Color(0xfff8f7fe),
              padding: EdgeInsets.all(10),
              //  height: MediaQuery.of(context).size.height * 0.095,
              child: Container(
              decoration: new BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.all(
              const Radius.circular(12.0)),
              ),
              child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
              Center(
              child: Padding(
              padding: EdgeInsets.only(
              left: 16, bottom: 8, top: 8),
              child: Text(
              LinkomTexts.of(context).filtrer(),
              style: TextStyle(
              decoration:
              TextDecoration.underline,
              color: Fonts.col_app,
              fontSize: 14.0),
              ))),
              Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: Checkedd.check_list(context)
              .map((Checkedd aa) => Row(
              children: <Widget>[
              RaisedButton(
              elevation: 0,
              color: Color(0xfff8f7fe),
              shape:
              new RoundedRectangleBorder(
              borderRadius:
              new BorderRadius
              .circular(
              8.0)),
              padding: EdgeInsets.all(2),
              child: Text(
              aa.name,
              style: TextStyle(
              color: aa.name ==
              LinkomTexts.of(
              context)
              .commission() &&
              widget
              .user
              .commissions
              .isEmpty
              ? Colors.grey
              : aa.name ==
              LinkomTexts.of(
              context)
              .fed() &&
              widget
              .user
              .fed
              .isEmpty
              ? Colors.grey
              : Fonts.col_ap,
              fontSize: 13),
              ),
              onPressed: () {
              if (aa.name ==
              LinkomTexts.of(
              context)
              .fed() &&
              widget.user.fed.isEmpty)
              return null;
              else if (aa.name ==
              LinkomTexts.of(
              context)
              .commission() &&
              widget.user.commissions
              .isEmpty)
              return null;
              else
              setState(() {
              //  aa.isselected = aa.name;
              select_result = aa.name;
              print(select_result);
              });
              },
              materialTapTargetSize:
              MaterialTapTargetSize
              .shrinkWrap,
              ),
              aa.name ==
              LinkomTexts.of(
              context)
              .commission() &&
              widget.user.commissions
              .isEmpty
              ? Container(
              width: 6,
              )
              : Container(),
              aa.name ==
              LinkomTexts.of(
              context)
              .commission() &&
              widget.user.commissions
              .isEmpty
              ? InkWell(
              child: Image.asset(
              "images/informations.png",
              width: 18,
              color: Colors.blue[700],
              ),
              onTap: () {
              Alert(
              context: context,
              title: "",
              content: Column(
              children: <
              Widget>[
              Container(
              width: MediaQuery.of(
              context)
              .size
              .width *
              0.8,
              child: RichText(
              text: new TextSpan(
              text: "",
              children: <
              TextSpan>[
              new TextSpan(
              text: "Vous n'êtes membre d'aucune commission"
              .toString(),
              style: new TextStyle(
              color: Fonts
              .col_app_fonn,
              fontSize:
              18,
              height:
              1.5),
              ),
              new TextSpan(
              text:
              ". Cliquez ici ",
              recognizer:
              new TapGestureRecognizer()
              ..onTap = () {
              Navigator.push(context, new MaterialPageRoute(builder: (BuildContext context) => new CommunitiesCGEM(null, null, [], false, false, widget.lat, widget.lng, widget.chng, user: widget.user)));
              },
              style: new TextStyle(
              color: Colors.blue[
              400],
              fontSize:
              18.0,
              fontWeight:
              FontWeight.w900,
              height: 1.5),
              ),
              new TextSpan(
              text:
              " pour rejoindre une ou plusieurs commission",
              style: new TextStyle(
              color: Fonts.col_app_fonn,
              fontSize: 18,
              height: 1.5))
              ],
              )) /*Text(
              "Vous n'êtes membre d'aucune commission. Cliquez pour rejoindre une ou plusieurs commission",
              style: TextStyle(
              color: Fonts
              .col_app_fonn),
              )*/
              ,
              ),
              ],
              ),
              buttons: [
              DialogButton(
              onPressed: () {
              Navigator.pop(
              context);
              },
              child: Text(
              "OK",
              style: TextStyle(
              color: Colors
              .white,
              fontSize:
              20),
              ),
              )
              ]).show();
              },
              )
              : Container(),
              aa.name ==
              LinkomTexts.of(
              context)
              .fed() &&
              widget.user.fed.isEmpty
              ? Container(
              width: 6,
              )
              : Container(),
              aa.name ==
              LinkomTexts.of(
              context)
              .fed() &&
              widget.user.fed.isEmpty
              ? InkWell(
              child: Image.asset(
              "images/informations.png",
              width: 18,
              color: Colors.blue[700],
              ),
              onTap: () {
              Alert(
              context: context,
              title: "",
              content: Column(
              children: <
              Widget>[
              Container(
              width: MediaQuery.of(context)
              .size
              .width *
              0.8,
              child: RichText(
              text: new TextSpan(
              text: "",
              children: <
              TextSpan>[
              new TextSpan(
              text:
              "Vous n'êtes membre d'aucune fédération".toString(),
              style: new TextStyle(
              color: Fonts.col_app_fonn,
              fontSize: 18,
              height: 1.5),
              ),
              new TextSpan(
              text:
              ". Cliquez ici ",
              recognizer: new TapGestureRecognizer()
              ..onTap = () {
              Navigator.push(
              context,
              new MaterialPageRoute(
              builder: (BuildContext context) => new FedCGEM(
              null,
              null,
              [],
              false,
              false,
              widget.lat,
              widget.lng,
              widget.chng,
              user: widget.user,
              )));
              },
              style: new TextStyle(
              color: Colors.blue[400],
              fontSize: 18.0,
              fontWeight: FontWeight.w900,
              height: 1.5),
              ),
              new TextSpan(
              text:
              " pour rejoindre une ou plusieurs fédérations",
              style: new TextStyle(
              color: Fonts.col_app_fonn,
              fontSize: 18,
              height: 1.5))
              ],
              ))),
              ],
              ),
              buttons: [
              DialogButton(
              onPressed: () {
              Navigator.pop(
              context);
              },
              child: Text(
              "OK",
              style: TextStyle(
              color: Colors
              .white,
              fontSize:
              20),
              ),
              )
              ]).show();
              },
              )
              : Container(),
              Container(
              width: 4,
              )
              ],
              ))
              .toList(),
              ),
              Container(height: 8,)
              ])))
              : Container(),
           */

          ///  drop_down(),
          ///

          horizontal_list(),
          /* widget._isVisible1
              ? select_result == LinkomTexts.of(context).publi()
                  ? drop_down()
                  : Container()
              : Container(),
          widget._isVisible1
              ? select_result == LinkomTexts.of(context).commission()
                  ? drop_down_commission()
                  : Container()
              : Container(),
          widget._isVisible1
              ? select_result == LinkomTexts.of(context).fed()
                  ? drop_down_fed()
                  : Container()
              : Container(),*/
          Expanded(
              child: widget.user.verify.toString() != "1" &&
                      (selected_type == "opportunite" ||
                          selected_type == "event")
                  ? Container(
                      child: Container(
                          padding:
                              EdgeInsets.only(top: 60, left: 12, right: 12),
                          child: Text(
                            selected_type == "opportunite"
                                ? "Vous devez être membre de la Cgem pour accéder à cette rubrique "
                                : "Vous devez être membre de la Cgem pour voir les événements",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 20,
                                height: 1.4,
                                color: Fonts.col_ap_fonn),
                          )),
                    )
                  : (widget.user.entreprise.situation != "Ajour" &&
                  (selected_type == "opportunite" ||
                          selected_type == "event"))
                      ? Container(
                          child: Container(
                              padding:
                                  EdgeInsets.only(top: 60, left: 12, right: 12),
                              child: Text(
                                "Vous devez régulariser votre situation pour accéder à cette rubrique.",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 20,
                                    height: 1.4,
                                    color: Fonts.col_ap_fonn),
                              )),
                        )
                      : new Builder(builder: buildBody))
        ],
      ),
      color: Fonts.col_grey.withOpacity(0.16),

    );
  }
}
