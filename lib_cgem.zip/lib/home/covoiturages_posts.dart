import 'package:flutter/material.dart';
import 'package:medz/co_voiturage/profile/covoiturage_user.dart';
import 'package:medz/models/user.dart';

class CovUser extends StatefulWidget {
  CovUser(this.user, this.user_me, this.auth, this.sign, this.lat, this.lng,
      this.cov, this.list_partner, this.analytics, this.chng);

  User user;
  var user_me;
  var auth;
  var sign;
  var lat;
  var lng;
  List list_partner;
  var analytics;
  var chng;
  var cov = true;

  @override
  _CovUserState createState() => _CovUserState();
}

class _CovUserState extends State<CovUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: new CovoiturageUser(
        widget.user_me,
        widget.user.id,
        widget.auth,
        widget.sign,
        widget.lat,
        widget.lng,
        widget.cov,
        widget.list_partner,
        widget.analytics,
        false,
        widget.chng,
      ),
    );
  }
}
