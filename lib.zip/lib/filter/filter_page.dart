import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:medz/filter/federation.dart';
import 'package:medz/filter/filter_by_last_cnx.dart';
import 'package:medz/filter/filter_by_new.dart';
import 'package:medz/filter/filter_by_old.dart';
import 'package:medz/filter/filterbylocalion.dart';
import 'package:medz/filter/objectifs.dart';
import 'package:medz/home/entreprise_view.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/search_widget.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

import 'filter_by_commission.dart';

class FilterPage extends StatefulWidget {
  FilterPage(this.user, this.chng, this.lat, this.lng);

  User user;
  var chng;
  var lat;
  var lng;

  @override
  _FilterPageState createState() => _FilterPageState();
}

class _FilterPageState extends State<FilterPage> {

  String text = "";
  
  tap(String text) {
    var res;
    switch (text) {
      case "Le plus proche":
        res = UsersStream(
            widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;

      case "Nouveaux utilisateurs":
        res = FilterByNew(
            widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;
      case "Anciens utilisateurs":
        res = FilterByOld(
            widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;

      case "Dernière connexion":
        res = FilterByLastCnx(
            widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;
      case "Entreprise":
        res = EntrepriseStream(
            widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;

      case "Commission":
        res = CommissionsStream(
            widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;
      case "Fédération":
        res = FederationsStream(
            widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;
      case "Objectif":
        res = Objectifs_widget(widget.user, widget.lat, widget.lng, [], null, widget.chng);
        break;

    }
    Navigator.push(
      context,
      new PageRouteBuilder(
        pageBuilder:
            (BuildContext context, Animation<double> _, Animation<double> __) {
          return res;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.instance = ScreenUtil(width: 375, height: 812)..init(context);





    Alert(
        context: context,
        title: "RECHERCHE",
        content: Column(
          children: <Widget>[
            Container(height: 12),
            TextFormField(
              style: new TextStyle(
                color: Fonts.col_app_fon,
              ),

              controller: text,
              //focusNode: focus,
              decoration: InputDecoration(
                labelStyle: TextStyle(
                  color: Fonts.col_app_fon,
                ),

                //  contentPadding: EdgeInsets.all(8),
                //   border: InputBorder.none, hintText: "Chercher .."),
                counterStyle:
                TextStyle(color: const Color(0xffeff6fb)),
                contentPadding: EdgeInsets.all(6.0),
                hintText: LinkomTexts.of(context).search() + '  ..',
                /* enabledBorder: OutlineInputBorder(
                      // width: 0.0 produces a thin "hairline" border
                      borderSide:
                          BorderSide(color: Colors.grey[50], width: 0.0),
                      borderRadius: BorderRadius.circular(60.0),
                    ),*/
                hintStyle: TextStyle(
                  color: Fonts.col_app_fon,
                ),
              ),
              onFieldSubmitted: (String text) {
                if (text.length > 0) {
                  Navigator.push(context, new MaterialPageRoute(
                      builder: (BuildContext context) {
                        return new UserListsResults(
                          text,
                          widget.user,
                          widget.list,
                          widget.analytics,
                          widget.lat,
                          widget.lng,
                          widget.bl,
                          null,
                          widget.chng,
                        );
                      }));
                }
              },
            ),
            Container(
              height: 16,
            ),
            Choices(val1, val2, func),
            Container(
              height: 16,
            ),
          ],
        ),
        buttons: [
          DialogButton(
            onPressed: () {
              print("jdjdjjdjdjjdjdjdj");
              Navigator.pop(context);
              var tex = text.text;
              setState(() {
                text.text = "";
              });

              print(type);
              if (type == "Utilisateur") {

              } else {
//

              }

              /* setState(() {
                      text.text = "";
                    });*/
            },
            child: Text(
                "Filtrer",
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
          )
        ]).show();




    Widget divid = Container(
      margin: EdgeInsets.only(top: 12, bottom: 12),
      width: MediaQuery.of(context).size.width,
      height: 1,
      color: Fonts.col_grey.withOpacity(0.4),
    );

    TextStyle st = TextStyle(
        color: Colors.black,
        fontFamily: "ralway",
        fontSize: ScreenUtil.getInstance().setSp(16),
        fontWeight: FontWeight.w500);

    Widget roww(String text) => InkWell(
        onTap: () {
          tap(text);
        },
        child: Row(
          children: [
            Text(text, style: st),
            Expanded(
              child: Container(),
            ),
            Image.asset(
              "images/arrr.png",
              color: Fonts.col_grey.withOpacity(0.77),
              width: ScreenUtil.getInstance().setWidth(16),
              height: ScreenUtil.getInstance().setWidth(16),
            ),
            Container(
              width: 16,
            )
          ],
        ));

    return Container(
      padding: EdgeInsets.only(left: 16, top: 12),
      child: ListView(
        children: [
          SearchWidget(widget.user, [], widget.lat != null ? widget.lat : 0.0,
              widget.lng != null ? widget.lng : 0.0, null, null, widget.chng),
          Container(
            height: 10,
          ),
          Text(
            "TRIER PAR:",
            style: TextStyle(
                fontFamily: "ab",
                fontSize: ScreenUtil.getInstance().setSp(18),
                color: Fonts.col_app,
                fontWeight: FontWeight.w800),
          ),

          divid,
          roww("Le plus proche"),
          divid,
          roww("Nouveaux utilisateurs"),
          divid,
          roww(
            "Anciens utilisateurs",
          ),
          divid,
          roww("Dernière connexion"),
          divid,
          Text(
            "FILTRER PAR:",
            style: TextStyle(
                fontSize: ScreenUtil.getInstance().setSp(18),
                color: Fonts.col_app,
                fontFamily: "ab",
                fontWeight: FontWeight.w800),
          ),
          divid,
          roww("Relations"),
          divid,
          roww("Entreprise"),
          divid,
          roww("Commission"),
          divid,
          roww("Fédération"),
          divid,
          roww("Objectif"),
          divid,
         // roww("Compétence"),
          //divid,
          roww("Genre"),
          divid,
        ],
      ),
    );
  }
}
