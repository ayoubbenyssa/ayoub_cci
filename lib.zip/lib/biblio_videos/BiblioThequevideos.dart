import 'package:flutter/material.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/user.dart';
import 'package:medz/parc_events_stream/parc_events_stream.dart';
import 'package:medz/services/Fonts.dart';



class BiblioVideos extends StatefulWidget {
  BiblioVideos(this.user, this.lat, this.lng,
  this.list_partner, this.analytics, this.chng);
  User user;
  var lat,lng;
  List list_partner;
  var analytics;
  var chng;





  @override
  _BiblioVideosState createState() => _BiblioVideosState();
}

class _BiblioVideosState extends State<BiblioVideos> {


  int count1 = 0;

  setSount1(c) {
    setState(() {
      count1 = c;
    });
  }




  @override
  Widget build(BuildContext context) {


    return Scaffold(
   backgroundColor: Colors.grey[50],
      appBar: AppBar(  backgroundColor: Fonts.col_app_shadow,
        elevation: 0.0,
        iconTheme: IconThemeData(color: Fonts.col_app_fonn),
        title: Text(
          count1 == 0
              ? LinkomTexts.of(context).vids()
              : LinkomTexts.of(context).vids() + ' (' + count1.toString()+')',
          style: TextStyle(color: Fonts.col_app_fonn,fontSize: 14.0,fontWeight: FontWeight.w400),
        ),
      ),
      body:    new StreamParcPub(
        new Container(),
        widget.lat,
        widget.lng,
        widget.user,
        "1",
        widget.list_partner,
        widget.analytics,
        setSount1,
        widget.chng,

        video:true,
        revue: false,
        favorite: false,
        boutique: false,
      ),
    );
  }
}
