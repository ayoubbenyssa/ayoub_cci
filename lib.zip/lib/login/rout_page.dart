import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:connectivity/connectivity.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/services/location_services.dart';
import 'package:medz/services/partners_list.dart';
import 'package:medz/slides2/homeslides.dart';
import 'package:medz/widgets/no_gps.dart';
import 'package:medz/widgets/no_wifi.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/chat/chatscreen.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/func/users_info.dart';
import 'package:medz/login/login.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/auth.dart';
import 'package:medz/notifications/invite_view_user.dart';
import 'package:medz/widgets/bottom_menu.dart';
import 'package:http/http.dart' as clientHttp;
import 'package:parse_server_sdk/parse_server_sdk.dart';
import 'package:http/http.dart' as http;

const String keyApplicationName = 'cgembusiness';
const String keyParseApplicationId = 'cgembusiness';
const String keyParseMasterKey = 'cgembusiness12345678888888-0ed5f89f718b';
const String keyParseServerUrl = 'http://51.38.33.9:1351/parse';
const String liveParseServerUrl = 'http://51.38.33.9:1351';

class RootPage extends StatefulWidget {
  RootPage(this.onLocaleChange, {this.sign, this.analytics, this.observer});

  var sign;
  var analytics;
  var observer;
  var onLocaleChange;

  @override
  State<StatefulWidget> createState() => _RootPageState();
}

enum AuthStatus {
  notSignedIn,
  signedIn,
}

class _RootPageState extends State<RootPage> {
  AuthStatus authStatus = AuthStatus.notSignedIn;
  BaseAuth auth = Auth();
  String _searchText = "";

  int actif = 0;
  String com_id = "";
  String com_name = "";
  Usernfo user_info = new Usernfo();
  User user_me = new User();
  ParseServer parse_s = new ParseServer();
  final FirebaseMessaging _firebaseMessaging = new FirebaseMessaging();

  //List list_partner;
  bool wait = true;
  int state = 0;
  List list_partners;
  final Connectivity _connectivity = new Connectivity();

  bool connect = true;
  bool reload = false;
  bool load = true;

  getUserInfo(id, show) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var response = await parse_s.getparse(
        'users?where={"id1":"$id"}&include=commissions&include=fed&include=respons');
    if (!this.mounted) return;

    if (response == "No")
      setState(() {
        connect = false;
      });
    else
      setState(() {
        connect = true;
        user_me = new User.fromMap(response["results"][0]);

        print("----------<3----------------");
        print(response["results"][0]["commissions"]);
        if (show == true) {
          prefs.setString("user", json.encode(response["results"][0]));
        }
      });
  }

  not() {}

  //    permissions();

  receivenotification(message) async {
    String my_id = await auth.currentUser();
    await getUserInfo(my_id, false);

    if (message["keyy"] == "msg") {
      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new ChatScreen(
            message["my_key"].split("_")[1],
            message["my_key"].split("_")[0],
            list_partners,
            false,
            auth,
            widget.analytics,
            widget.onLocaleChange,
            user: user_me);
      }));
    } else if (message["keyy"] == "connect") {
      //posts[index].auth_id, posts[index].notif_id,id,widget.user_me,
      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new Invite_view(
            message["sent_id"],
            message["id_notification"],
            my_id,
            user_me,
            true,
            not,
            auth,
            widget.sign,
            list_partners,
            null,
            null,
            widget.analytics,
            widget.onLocaleChange);
      }));
    } else if (message["keyy"] == "accept") {
      Navigator.push(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new Invite_view(
            message["sent_id"],
            message["id_notification"],
            my_id,
            user_me,
            false,
            not,
            auth,
            widget.sign,
            list_partners,
            null,
            null,
            widget.analytics,
            widget.onLocaleChange);
      }));
    } else if (message["keyy"] == "group") {
      Navigator.pushReplacement(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new BottomNavigation(auth, _signedIn, user_me, list_partners,
            true, widget.analytics, widget.onLocaleChange,
            animate1: true);
      }));
    }
    //});
  }

  Future<String> _fcmSetupAndGetToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return await _firebaseMessaging.getToken().then((token) {
      prefs.setString("token", token);
    });
  }

  get_info(id) async {
    //String my_id = await widget.auth.currentUser();
    // await  getUserInfo(my_id);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    // await getUserInfo(id, true);

    setState(() {
      connect = true;
      list_partners = [];
    });

    setState(() {
      wait = false;
    });

    if (prefs.getString("Slides").toString() == "null") {
      setState(() {
        state = -1;
      });
    }

    /* else if (prefs.getString("ent").toString() == "true") {

      setState(() {
        wait = false;
        state = 5;
      });
    }*/
    else if (prefs.getString('user').toString() != "null") {
      //await  verify_gps();

      setState(() {
        wait = true;
      });
      if (id != null) {
        await getUserInfo(id, true);
      }
      // user_me = new User.fromMap(json.decode(prefs.getString("user")));

      if (user_me.active == 0) {
        setState(() {
          wait = false;
          state = 3;
        });
      } else {
        setState(() {
          wait = false;
          state = 1;
        });
      }
    } else {
      setState(() {
        state = 3;
      });
    }
  }

  bool gps_exist = true;

  verify_gps() async {
    //await permissions();

    bool gps_op = await Location_service.verify_location();
    if (gps_op)
      setState(() {
        gps_exist = true;
      });
    else {
      setState(() {
        gps_exist = false;
      });
      /* Navigator.push(
          context,
          new MaterialPageRoute(
            builder: (BuildContext context) => new NoGps(verify_gps, null),
          ));*/
    }
  }

  getp() async {
    List<Partner> prtns = new List<Partner>();
    prtns = await PartnersList.get_list_entreprise1(0);

    for (Partner i in prtns) {
      // Offers off = new Offers.fromMap(i);
      var js = {"username": i.name, "description": i.description};
      String basicAuth = 'Basic ' +
          base64Encode(utf8.encode("cgembusiness" + ':' + "cgembusiness"));

      var a = await clientHttp.post(
          "https://search.cgembusiness.tk/docs/doc/" + i.objectId,
          headers: {
            HttpHeaders.authorizationHeader: basicAuth,
            "Content-type": "application/json"
          },
          body: json.encode(js));

      print(a.body);
    }
  }

  getpi() async {
    var response = await parse_s.getparse('offers?limit=100000');

    print("jdopjdojdo");
    print(response);

    for (var i in response["results"]) {
      // Offers off = new Offers.fromMap(i);
      var js = {
        "summary": i["summary"],
        "name": i["name"],
        "description": i["description"],
        "type": i["type"]
      };

      /* var a = await clientHttp.post(
          "https://search.cgembusiness.tk/cgembusiness/post/" + i["objectId"].toString(),
          headers: {"Content-type": "application/json"},
          body: json.encode(js));*/
      String basicAuth = 'Basic ' +
          base64Encode(utf8.encode("cgembusiness" + ':' + "cgembusiness"));

      print(i["objectId"].toString());
      var a = await clientHttp.put(
          "https://search.cgembusiness.tk/posts/post/" +
              i["objectId"].toString(),
          headers: {
            "Content-type": "application/json",
            HttpHeaders.authorizationHeader: basicAuth,
          },
          body: json.encode(js));

      print(a.body);
      /* var a = await  clientHttp.post(
          "http://51.38.33.9:9200/users_apebi/user/" +
              user.id.toString(),
          headers: {"Content-type": "application/json"},
          body: json.encode(jsonsearch));*/

      //  print(a.body);

    }
  }

  /*
  getUsers() async {
    var response = await parse_s.getparse('users?limit=200000');

    // print(response["results"]);

    for (var i in response["results"]) {
      User user = new User.fromMap(i);
      var js = {
        "active_loc": 0,
        "raja": true,
        "linkedin_link": user.linkedin_link,
        "firstname": user.firstname,
        "fullname": user.fullname,
        "photoUrl": user.image,
        "id": user.auth_id,
        "organisme": user.organisme,
        "titre": user.titre,
        "phone": user.phone,
        "email": user.email,
        "sexe": user.sexe,
        "communityName": user.community,
        "communityKey": user.communitykey,
        "active": user.active,
        /*  "location": {
            "__type": "GeoPoint",
            "latitude": double.parse(user.lat),
            "longitude": double.parse(user.lng),
          },
          "lat": double.parse(user.lat),
          "lng": double.parse(user.lng),*/
        "age": user.age,
        "anne_exp": user.anne_exp,
        "bio": user.bio,
        "competences": user.cmpetences,
        "objectif": user.objectif
      };

      String basicAuth = 'Basic ' +
          base64Encode(utf8.encode("cgembusiness" + ':' + "cgembusiness"));

      var a = await clientHttp.post(
          "https://search.cgembusiness.tk/users/user/" +
              user.id.toString(),
          headers: {
            "Content-type": "application/json",
            HttpHeaders.authorizationHeader: basicAuth,
          },
          body: json.encode(js));

      print("---------------------------------");
      print(a.body);
      print("---------------------------------");


    }
  }
*/


  getrs() async {
    var response = await parse_s.getparse('users?limit=200000');

    // print(response["results"]);

    for (var i in response["results"]) {
      User user = new User.fromMap(i);

      int dtte = DateTime.parse(user.updatedAt).millisecondsSinceEpoch;

      print(dtte);
     var a = await parse_s.putparse("users/"+user.id, {
        "last_active": dtte
      });

     print(a);


    }

  }
  delete() async {
    var response = await parse_s.getparse('partnerss?limit=300');

    print("jdopjdojdo");
    print(response);

    for (var i in response["results"]) {
      var name = i["username"];
      var res = await parse_s.getparse('partners?where={"username":"$name"}');

      print("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°");

      print(res);

      /* if(res["results"].length>0){

        print(res["results"][0]["imageUrl"]);
      }*/

      //var a = await parse_s.deleteparse("entreprise/" + i["objectId"]);
      // print(a);

    }
  }

  getzzzp() async {
    var response =
        await parse_s.getparse('users?where={"active":1}&limit=1000');

    print("jdopjdojdo");
    print(response);

    for (var i in response["results"]) {
      User user = new User.fromMap(i);

      var js = {
        "objectId": user.id,
        "firstname": user.firstname,
        "fullname": user.fullname,
        "email": user.email,
        "phone": user.phone,
        "organisme": user.organisme,
        "titre": user.titre,
        "cmpetences": user.cmpetences,
        "community": user.community
      };

      var a = await clientHttp.post(
          "http://51.38.33.9:9200/users/user/" + user.id.toString(),
          headers: {"Content-type": "application/json"},
          body: json.encode(js));

      print(a.body);
    }
  }

  init() async {
    // initConnectivity();
    //getUsers();

    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
        //receivenotification(message);
      },
      onLaunch: (Map<String, dynamic> message) async {
        print("onLaunch: $message");
        receivenotification(message);
      },
      onResume: (Map<String, dynamic> message) async {
        print("onResume: $message");
        receivenotification(message);
      },
    );
    _firebaseMessaging.requestNotificationPermissions(
        const IosNotificationSettings(sound: true, badge: true, alert: true));
    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });

    _fcmSetupAndGetToken();

    auth.currentUser().then((userId) {
      print("isjsijsijsisjsiodsjiodjihdio");

      get_info(userId);

      if (userId == null) {
        setState(() {
          authStatus = AuthStatus.notSignedIn;
        });
      } else {
        setState(() {
          authStatus = AuthStatus.signedIn;
        });

        // conditions();
      }
    });
  }

  reload_page() {
    setState(() {
      load = false;
    });

    print(
        "-------------------------------------------------------------------------------------------");
    new Timer(new Duration(seconds: 2), () {
      setState(() {
        load = true;
      });
    });
  }

  int weekNumber(DateTime date) {
    int dayOfYear = int.parse(DateFormat("D").format(date));
    return ((dayOfYear - date.weekday + 10) / 7).floor();
  }

  get_connect() async {
    //print(DateTime.now().hour);

    var response =
        await parse_s.getparse('connect?where={"accepted":true}&limit=2000');

    for (var i in response["results"]) {
      DateTime dte = DateTime.parse(i["createdAt"]);

      print(dte.weekday);

      await parse_s.putparse("connect/" + i["objectId"], {
        "year": dte.year,
        "dte_a": dte.hour.toString() +
            "-" +
            weekNumber(dte).toString() +
            "-" +
            dte.day.toString() +
            "-" +
            dte.month.toString() +
            "-" +
            dte.year.toString()
      });
    }

    /*
       map["month"] = new DateTime.now().month;
    map["year"] = new DateTime.now().year;
     */
  }

  /*


  getuseresjopsojdiod() async {
    var response =
        await parse_s.getparse('partners?where={"active":1}&limit=1000');
    for (var i in response["results"]) {
      Partner user = new Partner.fromMap(i);
      var jsonsearch = {
        "objectId": user.objectId,
        "name": user.name,
        "email": user.email,
        "phone": user.phone,
        "description": user.description,
        "sector": user.sector
      };

      var res = await clientHttp.post(
          "http://51.38.33.9:9200/entreprises/ent/" + user.objectId.toString(),
          headers: {"Content-type": "application/json"},
          body: json.encode(jsonsearch));

      print(
          "______°°°°°°°°°°°°°°°°°°°°°**********************************************************************");
      print(user.objectId.toString());

      print(res.body);
    }
  }*/

  getvideos() async {
    var a = await parse_s.getparse("revue?limit=1000");

    // var b = a["results"];

    for (var b in a["results"]) {
      if (b["image"].contains("https://www.cgem.ma")) {
        print(b["image"]);

        var c = b["image"].toString().replaceAll("https://www.cgem.ma", "");
        var d = b["url"].replaceAll("https://www.cgem.ma", "");

        parse_s
            .putparse("revue/" + b["objectId"], {"image": "$c", "url": "$d"});
      } else {}
    }
  }

/*  Future<void> _signInAnonymously() async {
    try {
      var a = await http.post("https://us-central1-cgembusiness-5e7e3.cloudfunctions.net/createUserLinkedin",body: {
        "uid": "123456789",
        "email":"jihad.atlagh.1@gmail.com"
      });
      print("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°");
      print(a.body);
//"auth/email-already-exists"
    } catch (e) {
      print("error");
      print(e); // TODO: show dialog with error
    }
  }*/

  getpp() async {
    var response = await parse_s.getparse(
        'users?include=entreprise&include=respons&where={"objectId":"PA2ZTB2Cy9"}');

    print("77777");
    print(response["results"].length);

    for (var i in response["results"]) {
      parse_s.putparse("users/" + i["objectId"], {
        "entreprise": {
          "__type": "Pointer",
          "className": "partners",
          "objectId": 'vDViER2Mbq'
        },
      });
    }
  }

  initState() {
    super.initState();
    //getrs();
    FirebaseDatabase.instance
        .reference()
        .child("connextions")
        .push()
        .set({'timestamp': ServerValue.timestamp});


    //getp();

    Parse().initialize(keyParseApplicationId, keyParseServerUrl,
        masterKey: keyParseMasterKey,
        liveQueryUrl: keyParseServerUrl,
        autoSendSessionId: false,
        debug: true);
    // getzzzp();

    // getzzzp();

    // getp();

    //  getpp();

    //getpp();
    // getvideos();
    // getvideos();
    // getp();

    /*  print("___________________________________________________****************_______________________________________________________");
    print(jsonn["Comité"]);

    for (var i in jsonn["personnel"])
      {
        parse_s.postparse("membre_raja", {
          "titre": i["titre"],
          "name": i["Personnel Raja 2018/19"],
          "type": "Personnel",
          "email": i["email"]
        });

      }*/
    // getuseresjopsojdiod();
    //SearchApis.searchposts("jihad");
    //get_connect();

    init();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void _signedIn() {
    authStatus = AuthStatus.signedIn;
  }

  void _signedOut() {
    authStatus = AuthStatus.notSignedIn;
  }

  got(chng) {
    switch (state) {
      case -1:
        return new Homeslides(
            widget.onLocaleChange);
      case 1:
        return new BottomNavigation(auth, _signedIn, user_me, list_partners,
            true, widget.analytics, widget.onLocaleChange);
        break;

      case 3:
        return new Login(
            auth, _signedIn, list_partners, widget.analytics, chng);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return !connect
        ? NoWifi(init, true)
        : wait
            ? Scaffold(backgroundColor: Colors.grey[100], body: Widgets.load())
            : got(widget.onLocaleChange);
  }
}
