import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_image/flutter_native_image.dart';
import 'package:image_picker/image_picker.dart';
import 'package:medz/communities/list_regions.dart';
import 'package:medz/communities/ville_list.dart';
import 'package:medz/entreprise/list_entreprise.dart';
import 'package:medz/inactive/inactive_widget.dart';
import 'package:medz/models/sector.dart';
import 'package:medz/services/sector_services.dart';
import 'package:medz/user/edit_my_profile.dart';
import 'package:medz/widgets/fixdropdown.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/login/login_w.dart';
import 'package:medz/login/types_company.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/validators.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:flutter/services.dart';

class EntrepriseForm extends StatefulWidget {
  EntrepriseForm(this.id, this.type, this.chng);

  String id;
  String type;
  var chng;


  bool show_myprofile = true;

  @override
  _EntrepriseFormState createState() => _EntrepriseFormState();
}

class _EntrepriseFormState extends State<EntrepriseForm> {
  final _titrecontroller = new TextEditingController();
  final _adrcontroller = new TextEditingController();
  final _vicontroller = new TextEditingController();
  final _pacontroller = new TextEditingController();

  FocusNode _focusville = new FocusNode();

  FocusNode _focuspa = new FocusNode();

  final _chcontroller = new TextEditingController();
  final _capontroller = new TextEditingController();
  FocusNode _focusadr = new FocusNode();
  FocusNode _focuscap = new FocusNode();
  FocusNode _focusch = new FocusNode();

  final _namecontroller = new TextEditingController();
  final _desccontroller = new TextEditingController();
  final _contactcontroller = new TextEditingController();
  bool uploading = false;
  List<Sector> _list = [];

  var im =
      "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565012657/placeholder_2_seeta8.png";
  var lo = false;
  var error = "";
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  bool _autovalidate = false;
  List<String> items = new List<String>();
  String selectedValue1 = "";

  final _raisonc = new TextEditingController();
  FocusNode _focustitre = new FocusNode();
  FocusNode _focusnb = new FocusNode();

  FocusNode _focusdesc = new FocusNode();
  final _nbcontroller = new TextEditingController();

  final _organismecontroller = new TextEditingController();
  List<String> type_profile = [];
  List<String> type = [];
  FocusNode _focusraison = new FocusNode();
  FocusNode _focusname = new FocusNode();
  FocusNode _focuscontact = new FocusNode();

  FocusNode _focusorganise = new FocusNode();
  String _authHint = '';
  ParseServer parse_s = new ParseServer();
  String id_organisme;
  String _platformVersion;
  var my_id = "";
  List tt = [];
  String ville_id = "";

  getSectors() async {
    List<Sector> sect = await SectorsServices.get_list_sectors();
    setState(() {
      _list = sect;
    });
  }

  getId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    my_id = prefs.getString("id");
  }

  bool yes_or = false;

  @override
  void initState() {
    getId();

    getSectors();
  }

  sub() {
    setState(() {
      yes_or = true;
    });
  }

  gotoprofile() {
    Navigator.pushReplacement(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              //new HomePage(widget.auth,widget.sign)
              new InactiveWidget(widget.chng),
        ));
  }

  update_user_entreprise(id, entreprise) async {
    String t = _titrecontroller.text;
    String ra = _raisonc.text;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString("ent", "true");

    var js_org = {
      "entreprise": {
        "__type": "Pointer",
        "className": "partners",
        "objectId": '$id'
      },
      "ent": false,
      "titre": "$t",
      "raison": "$ra",
      "organisme": "$entreprise"
    };

    await parse_s.putparse('users/' + my_id, js_org);
  }

  create_entreprise(owner, name, contact, entreprise) async {
    if (verify == false) {
      var res = await parse_s.postparse('partners/', {
        "username": "$name",
        "email": "$contact",
        "type": "$owner",
        "active": 0,
        "ville_id": "$ville_id",
        "region_id": tt[0],
        "author_id": widget.id,
        "description": _desccontroller.text,
        "imageUrl": im.toString(),
        "address": _adrcontroller.text,
        "ville": _vicontroller.text,
        "pays": _pacontroller.text,
        "ice": _organismecontroller.text,
        "nb_emp": _nbcontroller.text,
        "chiffre": _chcontroller.text,
        "password": "123456",
        "month": new DateTime.now().month.toString(),
        "year": new DateTime.now().year.toString()
      });
      id_organisme = res["objectId"];
    } else {
      id_organisme = id_entreprise;
    }
    await update_user_entreprise(id_organisme, entreprise);
    //Navigator.pop(context);
  }

  Widget hintText() {
    return _authHint == ""
        ? new Container()
        : new Container(
            //height: 80.0,
            padding: const EdgeInsets.all(32.0),
            child: new Text(_authHint,
                key: new Key('hint'),
                style: new TextStyle(fontSize: 14.0, color: Colors.red[700]),
                textAlign: TextAlign.center));
  }

  showAlert(context) async {
    return showDialog<String>(
        context: context,
        barrierDismissible: false, // user must tap button!
        builder: (BuildContext context) {
          return new AlertDialog(
            actions: <Widget>[],
            content: new Container(
                width: 260.0,
                height: 200.0,
                decoration: new BoxDecoration(
                  shape: BoxShape.rectangle,
                  color: const Color(0xFFFFFF),
                  borderRadius: new BorderRadius.all(new Radius.circular(32.0)),
                ),
                child: new Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      new Text(
                          "Il existe deja un organisme du meme nom, voulez vous rejoindre cet organisme, ou créer un "
                          "autre ?"),
                      RaisedButton(
                        onPressed: () async {
                          gotoprofile();
                        },
                        child: Text("Rejoindre " + _organismecontroller.text),
                      ),
                      Container(
                        height: 12.0,
                      ),
                      RaisedButton(
                        onPressed: () {
                          /* Navigator.pushReplacement(
                              context,
                              new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                //new HomePage(widget.auth,widget.sign)
                                new Details_organisme(
                                  /*com,*/
                                    widget.auth,
                                    widget.sign,
                                    widget.lat,
                                    widget.lng,
                                    widget.analytics,
                                    widget.observer,
                                    widget.list_partner,
                                    _organismecontroller.text,
                                    id_organisme),
                              ));*/
                        },
                        child: Text("Créer un organisme "),
                      )
                    ])),
          );
        });
  }

  save_image(image) async {
    setState(() {
      uploading = true;
    });

    int timestamp = new DateTime.now().millisecondsSinceEpoch;
    StorageReference storageReference = FirebaseStorage.instance
        .ref()
        .child("profile/img_" + timestamp.toString() + ".jpg");
    StorageUploadTask uploadTask = storageReference.put(image);
    await storageReference.put(image).onComplete.then((val) {
      val.ref.getDownloadURL().then((val) {
        //if (!mounted) return;

        setState(() {
          im = val.toString();
          error = "";
          uploading = false;
        });
      });
    });
  }

  gallery() async {
    Navigator.pop(context);
    var platformVersion;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      var fi = await ImagePicker.pickImage();
      if (!this.mounted) return;

      File fil;

      setState(() {
        fil = fi;
      });

      _cropImage(fil);
    } on PlatformException {
//      platformVersion = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;
  }

  Future _cropImage(image) async {
    File compressedFile =
        await FlutterNativeImage.compressImage(image.path, quality: 60);
    save_image(compressedFile);
  }

  ///image
  _handleCameraButtonPressed() async {
    Navigator.of(context).pop(true);
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    _cropImage(image);
  }

  void _handleSubmitted_entreprise() async {
    if (type_profile.toString() != "[]" &&
        type_profile.toString() != "null" &&
        yes_or == true) {
      setState(() {
        _authHint = "";
        yes_or = false;
        _namecontroller.text = type_profile[1];
        _contactcontroller.text = "    ";
      });
    }

    final FormState form = _formKey.currentState;
    if (!form.validate()) {
      _autovalidate = true; // Start validating on every change.
      //showInSnackBar("Veuillez corriger les erreurs en rouge");
    } else if (type_profile.isEmpty) {
      setState(() {
        _authHint = "Choisissez l'entreprise !";
      });
    } else {
      print("jihad");
      setState(() {
        _authHint = "";
      });
      //form.save();
      Widgets.onLoading(context);
      if (type_profile.isNotEmpty) {
        await update_user_entreprise(type_profile[0], type_profile[1]);
      } else {
        await create_entreprise(widget.type, _namecontroller.text,
            _contactcontroller.text, _namecontroller.text);
      }

      gotoprofile();

      /*
         SharedPreferences prefs = await SharedPreferences.getInstance();
           var my_id = prefs.getString("id");
         */

    }
  }

  /*


  void _handleSubmitted() async {
    print(type_profile);

    if (type_profile.toString() != "[]" &&
        type_profile.toString() != "null" &&
        yes_or == true) {
      setState(() {
        _authHint = "";
        yes_or = false;
        _namecontroller.text = type_profile[1];
        _contactcontroller.text = "    ";
      });
    }

    final FormState form = _formKey.currentState;
    if (!form.validate()) {
      _autovalidate = true; // Start validating on every change.
      //showInSnackBar("Veuillez corriger les erreurs en rouge");
    } else if (type_profile.isEmpty) {
      setState(() {
        _authHint = "S'il vous plait choisissez l'entreprise !";
      });
    } else {
      print("jihad");
      setState(() {
        _authHint = "";
      });
      //form.save();
      Widgets.onLoading(context);
      if (type_profile.isNotEmpty) {
        await update_user_entreprise(type_profile[0], type_profile[1]);
      } else {
        await create_entreprise(widget.type, _namecontroller.text,
            _contactcontroller.text, _namecontroller.text);
      }

      gotoprofile();

      /*
         SharedPreferences prefs = await SharedPreferences.getInstance();
           var my_id = prefs.getString("id");
         */

    }
  }

   */

  void _handleSubmitted() async {
    final FormState form = _formKey.currentState;
    if (!form.validate()) {
      _autovalidate = true;

// Start validating on every change.
      //showInSnackBar("Veuillez corriger les erreurs en rouge");
    } else {
      print("jihad");
      setState(() {
        _authHint = "";
      });
      //form.save();
      Widgets.onLoading(context);
      if (type_profile.isNotEmpty) {
        await update_user_entreprise(type_profile[0], type_profile[1]);
      } else {
        await create_entreprise(widget.type, _namecontroller.text,
            _contactcontroller.text, _namecontroller.text);
      }

      gotoprofile();

      /*
         SharedPreferences prefs = await SharedPreferences.getInstance();
           var my_id = prefs.getString("id");
         */

    }
  }

  goto_types() async {
    // Navigator.pop(widget.context);
    type = await Navigator.push(context,
        new MaterialPageRoute(builder: (BuildContext context) {
      return new EntreproseList(null, null, widget.id);
    }));

    setState(() {
      type_profile = type;
    });
  }

  bool verify = false;
  String id_entreprise = "";

  verify_entreprise() async {
    setState(() {
      _authHint = "";
    });
    String name = _namecontroller.text;

    var a = await parse_s.getparse('partners?where={"username":"$name"}');

    if (a["results"].length > 0) {
/*
"username": "$name",
      "email": "$contact",
      "type": "$owner",
      "active": 0,
      "author_id": widget.id,
      "description": _desccontroller.text,
      "imageUrl": im.toString(),
      "address": _adrcontroller.text,
      "ville": _vicontroller.text,
      "pays": _pacontroller.text,
      "ice": _organismecontroller.text,
      "nb_emp": _nbcontroller.text,
      "chiffre": _chcontroller.text,
 */
      setState(() {
        _authHint = "";
        verify = true;
        _adrcontroller.text = a["results"][0]["address"];
        _namecontroller.text = a["results"][0]["username"];
        _vicontroller.text = a["results"][0]["ville"];
        _pacontroller.text = a["results"][0]["pays"];
        _organismecontroller.text = a["results"][0]["ice"];
        _chcontroller.text = a["results"][0]["chiffre"];
        id_entreprise = a["results"][0]["objectId"];
      });
    } else {
      setState(() {
        verify = false;

        _authHint = "Cette entreprise n'existe pas dans la platforme!";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Validators val = new Validators(context: context);

    Widget ice = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield0(
            widget?.type == "Entreprise"
                ? "N° de membre CGEM"
                : "N° de membre CGEM",
            _focusorganise,
            "",
            _organismecontroller,
            TextInputType.text));

    Widget nb_emp = new Container(
        width: MediaQuery.of(context).size.width * 0.44,
        margin: EdgeInsets.only(right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("nb des employés", _focusnb, "", _nbcontroller,
            TextInputType.number, val.validateorganisme));

    Widget nb_cap = new Container(
        //width: MediaQuery.of(context).size.width * 0.85,
        margin: EdgeInsets.only(left: 12.0, right: 12),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield0(
          "Région",
          _focuscap,
          "",
          _capontroller,
          TextInputType.text,
        ));

    Widget Chiffre = new Container(
        width: MediaQuery.of(context).size.width * 0.42,
        margin: EdgeInsets.only(right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield0("Chiffre d'affaires", _focusch, "",
            _chcontroller, TextInputType.number));

    Widget ville = GestureDetector(
        onTap: () async {
          setState(() {
            _authHint = "";
          });
          if (tt.length == 0)
            setState(() {
              _authHint = "Choisir la région !";
            });
          else {
            print(tt[2]);
            print("dyeyye");
            // Navigator.pop(widget.context);
            List vi = await Navigator.push(context,
                new MaterialPageRoute(builder: (BuildContext context) {
              return new VilleLIst(tt[2], null, null, widget.id);
            }));

            print(type);
            setState(() {
              _vicontroller.text = vi[1];
              ville_id = vi[0];
            });
          }

          // nb_cap= await Navigator.push(context, route)
        },
        child: AbsorbPointer(
            child: new Container(
                width: MediaQuery.of(context).size.width * 0.41,
                margin: EdgeInsets.only(left: 12.0),
                decoration: new BoxDecoration(
                    border: new Border.all(color: Colors.grey[400], width: 1.0),
                    borderRadius: new BorderRadius.circular(4.0)),
                child: Widgets.textfield0(
                  "Ville",
                  _focusville,
                  "",
                  _vicontroller,
                  TextInputType.text,
                ))));

    Widget pays = new Container(
        width: MediaQuery.of(context).size.width * 0.41,
        margin: EdgeInsets.only(right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield0(
            "Pays", _focuspa, "", _pacontroller, TextInputType.text));

    Widget drop_down() => _list.isEmpty
        ? Container()
        : new Container(
            color: Colors.white,
            width: 700.0,
            height: 60.0,
            child: Container(
                margin: const EdgeInsets.all(8.0),
                // padding: const EdgeInsets.only(left: 16.0, right: 8.0),
                decoration: new BoxDecoration(
                  // color: Fonts.col_app,
                  border: new Border.all(color: Colors.grey[100], width: 1.0),
                  borderRadius: new BorderRadius.circular(2.0),
                ),
                child: new FixDropDown(
                    iconSize: 32.0,
                    isDense: false,
                    items: _list.map((Sector value) {
                      return new FixDropdownMenuItem(
                        value: value,
                        child: new Text(
                          value.name.toString(),
                          maxLines: 2,
                          textAlign: TextAlign.justify,
                          softWrap: true,
                          style: new TextStyle(color: Colors.black),
                        ),
                      );
                    }).toList(),
                    hint: new Text(
                      selectedValue1 != ""
                          ? selectedValue1
                          : "Choisir un secteur",
                      maxLines: 1,
                      softWrap: true,
                      style: new TextStyle(color: Colors.black),
                    ),
                    onChanged: (Sector value) {
                      setState(() {
                        selectedValue1 = value.name;
                        //depctrl.text = value.name;
                        //Reload();
                      });
                    })));

    Widget titre = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Votre titre / fonction", _focustitre, "",
            _titrecontroller, TextInputType.text, val.validatetitre));

    Widget company = new Container(
        width: MediaQuery.of(context).size.width * 0.44,
        margin: EdgeInsets.only(left: 12.0, right: 4.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Raison sociale", _focusname, "",
            _namecontroller, TextInputType.text, val.validaten));

    Widget address = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Addresse", _focusadr, "", _adrcontroller,
            TextInputType.text, val.validateAddress));

    Widget desc = new Container(
        margin:
            EdgeInsets.only(left: 12.0, right: 12.0, bottom: 12.0, top: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[300], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield_des1("Description", _focusdesc, "",
            _desccontroller, TextInputType.text, val.validatedesc));

    open_bottomsheet() {
      showModalBottomSheet<bool>(
          context: context,
          builder: (BuildContext context) {
            return new Container(
                height: 112.0,
                child: new Container(
                    // padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                    child: new Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                      new ListTile(
                          onTap: _handleCameraButtonPressed,
                          title: new Text("Prendre une photo")),
                      new ListTile(
                          onTap: gallery,
                          title: new Text("Photo depuis la gallerie")),
                    ])));
          });
    }

    Widget pht = new InkWell(
      child: new Column(
        children: <Widget>[
          new Row(
            children: <Widget>[
              new Container(
                width: 12.0,
              ),
              new Text(
                "Photo:",
                style: new TextStyle(color: Colors.grey[600]),
              ),
              new Container(
                width: 12.0,
              ),
              uploading ? new RefreshProgressIndicator() : new Container(),

              /*new Container(
                      color: Colors.grey,
                      width: 70.0,
                      height: 70.0,
                      child: new Image.network(
                        im,
                        width: 70.0,
                        height: 70.0,
                        fit: BoxFit.cover,
                      ),
                    )*/

              new Expanded(child: new Container()),
              new FlatButton(
                onPressed: () {
                  open_bottomsheet();
                },
                child: new Text(
                  "AJOUTER UNE PHOTO",
                  style: new TextStyle(
                    color: const Color(0xffff374e),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
            ],
          ),
        ],
      ),
      onTap: () {},
    );

    Widget contact = new Container(
        margin: EdgeInsets.only(left: 12.0, right: 12.0),
        decoration: new BoxDecoration(
            border: new Border.all(color: Colors.grey[400], width: 1.0),
            borderRadius: new BorderRadius.circular(4.0)),
        child: Widgets.textfield("Email de l'entreprise", _focuscontact, "",
            _contactcontroller, TextInputType.emailAddress, val.validatecont));

    var style = new TextStyle(
        color: const Color(0xffeff2f7),
        fontSize: 20.0,
        fontWeight: FontWeight.w500);
    var clr = Colors.blue[600];

    Widget btn_log = new Padding(
        padding: new EdgeInsets.only(left: 36.0, right: 36.0),
        child: new Material(
            elevation: 12.0,
            shadowColor: clr,
            borderRadius: new BorderRadius.circular(12.0),
            color: clr,
            child: new MaterialButton(
                // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  _handleSubmitted();
                },
                child: new Text("Confirmer", style: style))));

    return Scaffold(
        appBar: new AppBar(
          iconTheme: IconThemeData(color: Fonts.col_app_fon),
          backgroundColor: Fonts.col_app_shadow,
          title: new Text(
            "Informations professionnelles",
            style: TextStyle(color: Fonts.col_app_fon),
          ),
          elevation: 0.0,
        ),
        body: new Container(
            decoration: new BoxDecoration(
                color: Colors.grey[300],
                image: new DecorationImage(
                    fit: BoxFit.cover,
                    colorFilter: new ColorFilter.mode(
                        Colors.white.withOpacity(0.3), BlendMode.dstATop),
                    image: new AssetImage("images/back.jpg"))),
            child: new Stack(fit: StackFit.expand, children: <Widget>[
              ListView(children: <Widget>[
                new Container(
                    height: 700.0,
                    child: new LoginBackground(Widgets.kitGradients1))
              ]),
              ListView(children: <Widget>[
                Column(children: <Widget>[
                  new Padding(
                      padding: new EdgeInsets.only(
                          top: 0.0, left: 18.0, right: 18.0, bottom: 12.0),
                      child: SizedBox(
                          //width: deviceSize.width * 0.98,
                          child: new Material(
                              color: Colors.white.withOpacity(0.95),
                              elevation: 20.0,
                              borderRadius: new BorderRadius.circular(6.0),
                              shadowColor: Fonts.col_app,
                              child: new Form(
                                  key: _formKey,
                                  autovalidate: _autovalidate,
                                  //onWillPop: _warnUserAboutInvalidData,
                                  child: new Column(
                                      //mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        new Container(height: 12.0),
                                        new Center(
                                            child: Widgets.subtitle5(
                                                Fonts.col_app_fonn,
                                                widget.type.toString())),
                                        new Container(height: 12.0),
                                        hintText(),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            company,
                                            Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.40,
                                                child: FlatButton(
                                                  padding: EdgeInsets.all(0.0),
                                                  child: Text(
                                                    "Cliquer ici pour vérifier si le nom existe dans la platforme",
                                                    style: TextStyle(
                                                        color: Fonts.col_app,
                                                        fontSize: 12.0),
                                                  ),
                                                  onPressed: () {
                                                    verify_entreprise();
                                                  },
                                                ))
                                          ],
                                        ),
                                        Container(
                                          height: 12.0,
                                        ),
                                        ice,
                                        Container(
                                          height: 12.0,
                                        ),
                                        titre,
                                        pht,
                                        Container(
                                          height: 12.0,
                                        ),
                                        GestureDetector(
                                            onTap: () async {
                                              // Navigator.pop(widget.context);
                                              tt = await Navigator.push(context,
                                                  new MaterialPageRoute(builder:
                                                      (BuildContext context) {
                                                return new RegionsList(
                                                    null, null, widget.id);
                                              }));

                                              setState(() {
                                                _capontroller.text = tt[1];
                                                _vicontroller.text = "";
                                              });

                                              // nb_cap= await Navigator.push(context, route)
                                            },
                                            child:
                                                AbsorbPointer(child: nb_cap)),
                                        Container(
                                          height: 12,
                                        ),
                                        Row(
                                          children: <Widget>[
                                            ville,
                                            Container(
                                              width: 2,
                                            ),
                                            Expanded(
                                              child: Container(),
                                            ),
                                            pays,
                                          ],
                                        ),
                                        new Container(
                                          height: 12.0,
                                        ),
                                        address,
                                        new Container(
                                          height: 12.0,
                                        ),
                                        btn_log,
                                        new Container(
                                          height: 8.0,
                                        ),
                                      ])))))
                ])
              ])
            ])));
  }
}
