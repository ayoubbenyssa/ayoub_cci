import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/func/parsefunc.dart';


class LoginWithGoogle extends StatefulWidget {
  LoginWithGoogle(
      this.auth, this.sign, this.analytics, this.observer, this.list_partner);

  var auth;
  var sign;
  var analytics;
  var observer;
  List list_partner;

  @override
  _LoginPageState createState() => new _LoginPageState();
}
//await user_service.verify_user_exist_google(googleUser, googleAuth,context,widget.chng );
/*
     await insert_user(googleUser.displayName,
          googleUser.photoUrl, "google", googleUser.email, context,
          idToken: googleAuth.idToken,
          accessToken: googleAuth.accessToken,
          type_user: "1");
     */

class _LoginPageState extends State<LoginWithGoogle> {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn();
  ParseServer parse_s = new ParseServer();
  final FirebaseMessaging _firebaseMessaging = new FirebaseMessaging();

  var response;

  _logWithGoogle() async {
    /* //  RegisterService.onLoading(context);
    GoogleSignInAccount googleUser = await googleSignIn.signIn();
    print(googleUser);
    GoogleSignInAuthentication googleAuth;
    try {//lmochkil hna
      googleAuth = await googleUser.authentication;
      print(googleAuth);

    final FirebaseAuth _auth = FirebaseAuth.instance;

    FirebaseUser userId = await _auth.signInWithGoogle(
        idToken: googleAuth.idToken, accessToken: googleAuth.accessToken);

    SharedPreferences prefs = await SharedPreferences.getInstance();

    String ui = userId.uid;
    //var a = await  auth.currentUser();
    response = await parse_s.getparse('users?where={"id":"$ui"}');

    if (response["results"].length == 0) {
      await Block.insert_block(userId.uid, userId.uid, null, null);
      await RegisterService.insert_user(
          googleUser.displayName.split(" ")[0],
          googleUser.displayName.split(" ")[1],
          googleUser.email,
          context,
          ui,
          googleUser.photoUrl,
          "",
          "",
          phone: "");
      //Communities

      // prefs.setString("id", res2["objectId"]);
      // prefs.setString("user", json.encode(res["results"][0]));

      Navigator.pushReplacement(context,
          new MaterialPageRoute(builder: (BuildContext context) {
        return new Communities(widget.auth, widget.sign, widget.analytics,
            widget.observer, widget.list_partner);
      }));
    } else {
      User user = new User.fromMap(response["results"][0]);
      prefs.setString("id", response["results"][0]["objectId"]);
      if (user.active == 0) {
        if (user.community.toString() != "null" &&
            user.community.toString() != "")
          Navigator.pushReplacement(context,
              new MaterialPageRoute(builder: (BuildContext context) {
            return new Communities(widget.auth, widget.sign, widget.analytics,
                widget.observer, widget.list_partner);
          }));
        else
          Navigator.pushReplacement(context,
              new MaterialPageRoute(builder: (BuildContext context) {
            return new InactiveWidget(
                user.communitykey,
                user.community,
                widget.auth,
                widget.sign,
                widget.analytics,
                widget.observer,
                widget.list_partner);
          }));
        //
      } else {
        var res2 = response["results"][0];

        String token = await _firebaseMessaging.getToken();

        await Firestore.instance
            .collection('user_notifications')
            .document(ui)
            .setData({
          "my_token": token,
          "name": res2["firstname"] + "  " + res2["familyname"],
          "image": res2["photoUrl"],
          "send": "yes"
        });

        var ref = FirebaseDatabase.instance.reference();
        print(res2["communityKey"]);
        ref
            .child('communities/' +
                res2["communityKey"] +
                "/") //.orderByChild('medz').equalTo(true)
            .onValue
            .listen((Event ev) {
          print(
              "----------------------------ffffffff--------------------------------------------------------");
          print(ev.snapshot.value);
          //ev.snapshot.value
        });

        var js = {"token": token, "medz": true};
        await parse_s.putparse("users/" + user.id, js);

        prefs.setString("id", res2["objectId"]);
        prefs.setString("user", json.encode(response["results"][0]));
        Routes.goto_home(context, widget.auth, widget.sign, user,
            widget.analytics, widget.observer, widget.list_partner);
      }
    }

    googleSignIn.signOut();
  } catch (e) {
      print("errrroorooror");
      print(e.toString());
      //  Navigator.of(context);
      // Navigator.pop(context);

    }*/
    GoogleSignIn _googleSignIn = GoogleSignIn(
      scopes: [
        'email',
        'https://www.googleapis.com/auth/contacts.readonly',
      ],
    );
    _googleSignIn.signIn().then((result){
      result.authentication.then((googleKey){
        print(googleKey.accessToken);
        print(googleKey.idToken);
        print(_googleSignIn.currentUser.displayName);
      }).catchError((err){
        print('inner error');
      });
    }).catchError((err){
      print('error occured');
    });
  }

  var style = new TextStyle(
      color: const Color(0xffeff2f7),
      fontSize: 12.0,
      fontWeight: FontWeight.w600);

  @override
  Widget build(BuildContext context) {
    return new Container(
        height: 40.0,
        padding: new EdgeInsets.only(left: 6.0, right: 6.0),
        child: new Material(
            elevation: 6.0,
            shadowColor: Colors.deepOrange[800],
            borderRadius: new BorderRadius.circular(8.0),
            color: Colors.deepOrange[800],

            /*decoration: new BoxDecoration(
            border: new Border.all(color: const Color(0xffeff2f7), width: 1.5),
            borderRadius: new BorderRadius.circular(6.0)),*/
            child: new MaterialButton(
              // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  _logWithGoogle();
                },
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Image.asset(
                      "images/g.png",
                      width: 25.0,
                      height: 25.0,
                      fit: BoxFit.cover,
                    ),
                    new Container(
                      width: 8.0,
                    ),
                    //  new Container(height: 36.0,color: Colors.white,width: 1.5,),
                    new Container(
                      width: 8.0,
                    ),
                    new Text("SE CONNECTER AVEC GOOGLE",
                        textAlign: TextAlign.center, style: style)
                  ],
                ))));

    /*Expanded(
          flex: 1,
          child: new IconButton(
            padding: new EdgeInsets.all(0.0),
            //tooltip: "Soooon",
            onPressed: () {
              _logWithGoogle();
            },
            icon: new Image.asset(
              "images/g.png",
              width: 95.0,
              height: 95.0,
              fit: BoxFit.cover,
            ),
          ))*/
    ;
  }
}
