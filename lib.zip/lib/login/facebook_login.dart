import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:medz/inactive/active_widget.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/login/submit_name_organisme.dart';
import 'package:medz/user/edit_my_profile.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/block.dart';
import 'package:medz/services/login_services.dart';
import 'package:http/http.dart' as http;
import 'package:medz/services/routes.dart';
import 'package:flutter/services.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';

class FaceLogin extends StatefulWidget {
  FaceLogin(this.auth, this.sign, this.list_partner, this._scaffoldKey,
      this.analytics, this.chng);

  var auth;
  var sign;
  var _scaffoldKey;
  List list_partner;
  var analytics;
  var chng;

  @override
  _MyAppState createState() => new _MyAppState();
}

class _MyAppState extends State<FaceLogin> {
  static final FacebookLogin facebookSignIn = new FacebookLogin();
  ParseServer parse_s = new ParseServer();
  var response;
  final FirebaseMessaging _firebaseMessaging = new FirebaseMessaging();

  Future _logOut() async {
    await facebookSignIn.logOut();
  }

  void showInSnackBar(String value) {
    widget._scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  insert_user(userId, resul, ui) async {
    await Block.insert_block(userId.uid, userId.uid, null, null);

    var image = await _loadIm(resul["picture"]["data"]["url"]);

    await RegisterService.insert_user(
      userId.displayName.split(" ")[0],
      userId.displayName.split(" ")[1],
      resul["email"],
      context,
      ui,
      image,
      "",
      "",
      widget.auth,
      widget.sign,
      widget.list_partner,
      widget.analytics,
      widget.chng,

      phone: "",
    );
    //Communities
  }

  update_data(user, ui, prefs) async {
    String token = await _firebaseMessaging.getToken();

    var res2 = response["results"][0];

    print(res2);

    var js = {"token": token, "raja": true};
    parse_s.putparse("users/" + user.id, js);
    await Firestore.instance
        .collection('user_notifications')
        .document(ui)
        .setData({
      "my_token": token,
      "name": res2["firstname"] + "  " + res2["familyname"],
      "image": res2["photoUrl"],
      "send": "yes"
    });

    prefs.setString("id", response["results"][0]["objectId"]);
    prefs.setString("user", json.encode(response["results"][0]));
    Routes.goto_home(context, widget.auth, widget.sign, user,
        widget.list_partner, true, widget.analytics, widget.chng);
  }

  Future _loadIm(image) async {
    final bytes = await _loadFileBytes(
      image,
    );

    final dir = await getApplicationDocumentsDirectory();
    final file = new File('${dir.path}/im.jpeg');

    File fl = await file.writeAsBytes(bytes);
    var im = await save_image(fl);

    print(im);
    return im;
  }

  /**
   *
   * img
   */
  Future<String> save_image(image) async {
    String im;
    int timestamp = new DateTime.now().millisecondsSinceEpoch;
    StorageReference storageReference = FirebaseStorage.instance
        .ref()
        .child("profile/img_" + timestamp.toString() + ".jpg");
    var val = await storageReference.put(image).onComplete;
    var imm = await val.ref.getDownloadURL();

    im = imm.toString();

    return im.toString();
  }

  Future<Uint8List> _loadFileBytes(String url) async {
    Uint8List bytes;
    try {
      bytes = await readBytes(url);
    } on ClientException {
      rethrow;
    }
    return bytes;
  }

  Future login_facebook(auth, sign) async {
    try {
      RegisterService.onLoading(context);

      final FacebookLoginResult result =
          await facebookSignIn.logIn(['email']);
      if (result.status == FacebookLoginStatus.loggedIn) {
        final FacebookAccessToken accessToken = result.accessToken;
        var res = await http.get(
            'https://graph.facebook.com/me?fields=email,picture.width(500).height(500),id,gender,name&access_token=' +
                accessToken.token,
            headers: {'Content-Type': 'applicaton/json'});

        print("jiiiiii-------------------------------------");

        var resul = json.decode(res.body);
        print(resul);
        print(resul.containsKey('email'));

        if (resul.containsKey('email')) {
          if (resul["email"].toString() != "null") {
            /*
          https://graph.facebook.com/
           */

            try {
              FirebaseAuth auth = FirebaseAuth.instance;
              AuthCredential authCredential = FacebookAuthProvider.getCredential(accessToken: accessToken.token);
              FirebaseUser fbUser = (await auth.signInWithCredential(authCredential)).user;
              String ui = fbUser.uid;
              SharedPreferences prefs = await SharedPreferences.getInstance();

              print(ui);

              print(ui);

              response = await parse_s.getparse(
                  'users?where={"id1":"$ui"}&include=commissions&include=fed');

              print(response["results"]);

              if (response["results"].length == 0) {
                print("jdjdjdjjd");
                await insert_user(fbUser, resul, ui);

                Navigator.of(context, rootNavigator: true).pop('dialog');
              } else {
                User user = new User.fromMap(response["results"][0]);
                prefs.setString("id", response["results"][0]["objectId"]);

                if (response["results"][0]["photoUrl"]
                        .toString()
                        .substring(0, 26) ==
                    "https://graph.facebook.com/") {
                  var a = await parse_s.putparse(
                      "users/" + response["results"][0]["objectId"],
                      {"photoUrl": resul["picture"]["data"]["url"]});
                }

                print(user.active);

                if (user.active == 0) {
                  Navigator.of(context, rootNavigator: true).pop('dialog');

                  if (user.des == true) {
                    Navigator.pushReplacement(
                        context,
                        new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              //new HomePage(widget.auth,widget.sign)
                              new ActiveWidget(user, widget.chng),
                        ));
                  } else if (user.entreprise.toString() == "null") {
                    Navigator.of(context, rootNavigator: true).pop('dialog');

                    Navigator.pushReplacement(context,
                        new MaterialPageRoute(builder: (BuildContext context) {
                      return new SubmitNameOrganisme(
                          user.id,
                          user.type_profil,
                          user.fullname + " " + user.firstname,
                          user.email,
                          widget.chng);
                    }));

                    /*

                 goto
                  */

                  } else {
                    Navigator.pushReplacement(
                        context,
                        new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              //new HomePage(widget.auth,widget.sign)
                              new EditMyProfile(
                                  /*com,*/
                                  widget.auth,
                                  widget.sign,
                                  widget.list_partner,
                                  widget.chng),
                        ));
                  }
                } else {
                  prefs.setString("user", json.encode(response["results"][0]));
                  Routes.goto_home(context, widget.auth, widget.sign, user,
                      widget.list_partner, true, widget.analytics, widget.chng);
                }
              }

              _logOut();
            } catch (e) {
              print("error");
              print(e.toString());
            }

            if (res.statusCode != 200) print("error");
            facebookSignIn.logOut();
            return res;
          } else {
            Navigator.of(context, rootNavigator: true).pop('dialog');
            showInSnackBar(
                "veillez accepter les permissions pour accéder à Ahlan");
          }
        } else {
          Navigator.of(context, rootNavigator: true).pop('dialog');
          showInSnackBar(
              "veillez accepter les permissions pour accéder à Ahlan");
        }
      } else if (result.status == FacebookLoginStatus.cancelledByUser)
        print("cancel");
      else if (result.status == FacebookLoginStatus.error) print("error");
    } on PlatformException {
      Navigator.of(context, rootNavigator: true).pop('dialog');
    }
  }

  @override
  Widget build(BuildContext context) {
    var style = new TextStyle(
        color: Colors.blue[700], fontSize: 14.0, fontWeight: FontWeight.w500);

    return new Container(
        height: 40.0,
        padding: new EdgeInsets.only(left: 6.0, right: 6.0),
        child: new Material(
            elevation: 2.0,
            shadowColor: Colors.blue[500],
            borderRadius: new BorderRadius.circular(8.0),

            /*decoration: new BoxDecoration(
            border: new Border.all(color: const Color(0xffeff2f7), width: 1.5),
            borderRadius: new BorderRadius.circular(6.0)),*/
            child: new MaterialButton(
                // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  login_facebook(widget.auth, widget.sign);
                },
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Image.asset(
                      "images/f.png",
                      width: 25.0,
                      height: 25.0,
                      color: Colors.blue[700],
                      fit: BoxFit.cover,
                    ),
                    new Container(
                      width: 8.0,
                    ),
                    //  new Container(height: 36.0,color: Colors.white,width: 1.5,),
                    new Container(
                      width: 8.0,
                    ),
                    new Text(LinkomTexts.of(context).login_facebook(),
                        textAlign: TextAlign.center, style: style)
                  ],
                ))));
    /*new Expanded(
    flex: 1,
    child: new IconButton(
    padding: new EdgeInsets.all(0.0),
      tooltip: "Soooon",

      onPressed: () {
    //_logWithGoogle();
      login_facebook(widget.auth,widget.sign);
    },
    icon: new Image.asset(
    "images/f.png",
    width: 70.0,
    height: 70.0,
    fit: BoxFit.cover,
    ),
    ));*/
  }
}
