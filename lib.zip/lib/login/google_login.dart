import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart';
import 'package:medz/inactive/active_widget.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/login/submit_name_organisme.dart';
import 'package:medz/user/edit_my_profile.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/block.dart';
import 'package:medz/services/login_services.dart';
import 'package:medz/services/routes.dart';

class LoginWithGoogle extends StatefulWidget {
  LoginWithGoogle(this.auth, this.sign, this.list_partner, this._scaffoldKey,
      this.analytics, this.chng);

  var auth;
  var sign;
  var _scaffoldKey;
  List list_partner;
  var analytics;
  var chng;

  @override
  _LoginPageState createState() => new _LoginPageState();
}
//await user_service.verify_user_exist_google(googleUser, googleAuth,context,widget.chng );
/*
     await insert_user(googleUser.displayName,
          googleUser.photoUrl, "google", googleUser.email, context,
          idToken: googleAuth.idToken,
          accessToken: googleAuth.accessToken,
          type_user: "1");
     */

class _LoginPageState extends State<LoginWithGoogle> {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn(/*scopes: [
    'email',
    'https://www.googleapis.com/auth/contacts.readonly',
  ]*/);
  ParseServer parse_s = new ParseServer();
  final FirebaseMessaging _firebaseMessaging = new FirebaseMessaging();

  var response;

  void showInSnackBar(String value) {
    widget._scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  update_data_to_login(res2, ui, user, prefs, res) async {
    String token = await _firebaseMessaging.getToken();

    /*await Firestore.instance
        .collection('user_notifications')
        .document(ui)
        .setData({
      "my_token": token,
      "name": res2["firstname"] + "  " + res2["familyname"],
      "image": res2["photoUrl"],
      "send": "yes"
    });*/

    // String token = await _firebaseMessaging.getToken();
    var js = {"token": token, "raja": true};
    await parse_s.putparse("users/" + user.id, js);

    parse_s.putparse("users/" + user.id, js);
    await Firestore.instance
        .collection('user_notifications')
        .document(ui)
        .setData({
      "send": "yes",
      "my_token": token,
      "name": res2["firstname"] + "  " + res2["familyname"],
      "image": res2["photoUrl"],
    });

    Navigator.of(context, rootNavigator: true).pop('dialog');

    prefs.setString("id", res2["objectId"]);
    prefs.setString("user", json.encode(res["results"][0]));

    Routes.goto_home(context, widget.auth, widget.sign, user,
        widget.list_partner, true, widget.analytics, widget.chng);

    // var js = {"token": token, "apebi": true};
    // await parse_s.putparse("users/" + user.id, js);
  }

  insert_user(userId, googleUser, ui) async {
    String image = await _loadIm(googleUser.photoUrl);
    print(image);
    await Block.insert_block(userId.uid, userId.uid, null, null);
    await RegisterService.insert_user(
        googleUser.displayName.split(" ")[0],
        googleUser.displayName.split(" ")[1],
        googleUser.email,
        context,
        ui,
        image,
        "",
        "",
        null,
        null,
        widget.list_partner,
        widget.analytics,
        widget.chng,
        phone: "");
  }

  /**
   *
   * img
   */
  Future<String> save_image(image) async {
    String im;
    int timestamp = new DateTime.now().millisecondsSinceEpoch;
    StorageReference storageReference = FirebaseStorage.instance
        .ref()
        .child("profile/img_" + timestamp.toString() + ".jpg");
    var val = await storageReference.put(image).onComplete;
    var imm = await val.ref.getDownloadURL();

    im = imm.toString();

    return im.toString();
  }

  Future _loadIm(image) async {
    final bytes = await _loadFileBytes(
      image,
    );

    final dir = await getApplicationDocumentsDirectory();
    final file = new File('${dir.path}/im.jpeg');

    File fl = await file.writeAsBytes(bytes);
    var im = await save_image(fl);

    print(im);
    return im;
  }

  Future<Uint8List> _loadFileBytes(String url) async {
    Uint8List bytes;
    try {
      bytes = await readBytes(url);
    } on ClientException {
      rethrow;
    }
    return bytes;
  }

  _logWithGoogle() async {
    //  RegisterService.onLoading(context);

    GoogleSignInAccount googleUser = await googleSignIn.signIn();
    RegisterService.onLoading(context);

    print(googleUser);
    GoogleSignInAuthentication googleAuth;
    try {
      //lmochkil hna
      googleAuth = await googleUser.authentication;

      final FirebaseAuth _auth = FirebaseAuth.instance;

      FirebaseAuth auth = FirebaseAuth.instance;
      AuthCredential authCredential = GoogleAuthProvider.getCredential(
          idToken: googleAuth.idToken, accessToken: googleAuth.accessToken);
      FirebaseUser fbUser =
          (await auth.signInWithCredential(authCredential)).user;
      SharedPreferences prefs = await SharedPreferences.getInstance();

      String ui = fbUser.uid;
      response = await parse_s.getparse(
          'users?where={"id1":"$ui"}&include=commissions&include=fed');

      print(googleUser.photoUrl);

      if (response["results"].length == 0) {
        await insert_user(fbUser, googleUser, ui);
      } else {
        User user = new User.fromMap(response["results"][0]);
        prefs.setString("id", response["results"][0]["objectId"]);
        if (user.active == 0) {
          Navigator.of(context, rootNavigator: true).pop('dialog');

          if (user.des == true) {
            Navigator.pushReplacement(
                context,
                new MaterialPageRoute(
                  builder: (BuildContext context) =>
                      //new HomePage(widget.auth,widget.sign)
                      new ActiveWidget(user, widget.chng),
                ));
          } else if (user.entreprise.toString() != "null" &&
              user.entreprise.toString() != "") {
            Navigator.pushReplacement(
                context,
                new MaterialPageRoute(
                  builder: (BuildContext context) =>
                      //new HomePage(widget.auth,widget.sign)
                      new EditMyProfile(
                          /*com,*/
                          widget.auth,
                          widget.sign,
                          widget.list_partner,
                          widget.chng),
                ));
          } else {
            Navigator.pushReplacement(context,
                new MaterialPageRoute(builder: (BuildContext context) {
              return new SubmitNameOrganisme(
                  user.id,
                  user.type_profil,
                  user.fullname + " " + user.firstname,
                  user.email,
                  widget.chng);
            }));
          }
        } else {
          var res2 = response["results"][0];
          await update_data_to_login(res2, ui, user, prefs, response);
          // Navigator.of(context, rootNavigator: true).pop('dialog');

          /* prefs.setString("id", res2["objectId"]);
          prefs.setString("user", json.encode(response["results"][0]));
          Routes.goto_home(
              context, widget.auth, widget.sign, user, widget.list_partner);*/
        }
      }

      googleSignIn.signOut();
    } catch (e) {
      print("errrroorooror");
      print(e.toString());
      Navigator.of(context, rootNavigator: true).pop('dialog');

      //  Navigator.of(context);
      // Navigator.pop(context);

    }
  }

  /* GoogleSignIn _googleSignIn = GoogleSignIn(
 scopes: [
   'email',
   'https://www.googleapis.com/auth/contacts.readonly',
 ],
);
     _googleSignIn.signIn().then((result){
          result.authentication.then((googleKey){
              print(googleKey.accessToken);
              print(googleKey.idToken);
              print(_googleSignIn.currentUser.displayName);
          }).catchError((err){
            print('inner error');
          });
      }).catchError((err){
          print('error occured');
      });
  }*/

  var style = new TextStyle(
      color: Colors.deepOrange[800],
      fontSize: 14.0,
      fontWeight: FontWeight.w500);

  @override
  Widget build(BuildContext context) {
    return new Container(
        height: 40.0,
        padding: new EdgeInsets.only(left: 6.0, right: 6.0),
        child: new Material(
            elevation: 2.0,
            shadowColor: Colors.deepOrange[500],
            borderRadius: new BorderRadius.circular(8.0),
            color: Colors.grey[50],

            /*decoration: new BoxDecoration(
            border: new Border.all(color: const Color(0xffeff2f7), width: 1.5),
            borderRadius: new BorderRadius.circular(6.0)),*/
            child: new MaterialButton(
                // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  _logWithGoogle();
                },
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                        child: new Image.asset(
                      "images/g.png",
                      width: 25.0,
                      height: 25.0,
                      color: Colors.deepOrange[800],
                      fit: BoxFit.cover,
                    )),
                    new Container(
                      width: 8.0,
                    ),
                    //  new Container(height: 36.0,color: Colors.white,width: 1.5,),
                    new Container(
                      width: 8.0,
                    ),
                    new Text(LinkomTexts.of(context).login_google(),
                        textAlign: TextAlign.center, style: style)
                  ],
                ))));

    /*Expanded(
          flex: 1,
          child: new IconButton(
            padding: new EdgeInsets.all(0.0),
            //tooltip: "Soooon",
            onPressed: () {
              _logWithGoogle();
            },
            icon: new Image.asset(
              "images/g.png",
              width: 95.0,
              height: 95.0,
              fit: BoxFit.cover,
            ),
          ))*/
    ;
  }
}
