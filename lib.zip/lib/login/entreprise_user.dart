import 'package:flutter/material.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/login/entreprise_form.dart';
import 'package:medz/login/login_w.dart';
import 'package:medz/login/submit_name_organisme.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/widgets.dart';

class Entrepriseoruser extends StatefulWidget {
  Entrepriseoruser(this.id, this.name, this.email, this.chng);

  String id;
  String name;
  String email;
  var chng;

  @override
  _EntrepriseoruserState createState() => _EntrepriseoruserState();
}

class _EntrepriseoruserState extends State<Entrepriseoruser> {
  ParseServer parse_s = new ParseServer();

  @override
  Widget build(BuildContext context) {
    Widget or = new Padding(
        padding: new EdgeInsets.only(left: 12.0, right: 12.0),
        child: new Row(
          children: <Widget>[
            new Expanded(
              child: new Container(
                width: 1.0,
                height: 1.0,
                color: Fonts.col_app_fon,
              ),
              flex: 1,
            ),
            new Container(
              width: 8.0,
            ),
            new Center(
              child: new Text("Ou",
                  style: new TextStyle(
                      color: Fonts.col_app_fon,
                      fontSize: 15.0,
                      fontWeight: FontWeight.w700)),
            ),
            new Container(
              width: 8.0,
            ),
            new Expanded(
              child: new Container(
                width: 1.0,
                height: 1.0,
                color: Fonts.col_app_fon,
              ),
              flex: 1,
            ),
          ],
        ));

    return WillPopScope(
        onWillPop: () {
          Widgets.exitapp(context);
        },
        child: Scaffold(
            appBar: new AppBar(
              iconTheme: IconThemeData(color: Fonts.col_app_fon),
              backgroundColor: Fonts.col_app_shadow,
              title: new Text(
                "Type de profil",
                style: TextStyle(color: Fonts.col_app_fon),
              ),
              elevation: 0.0,
            ),
            body: new Container(
              decoration: new BoxDecoration(
                  color: Colors.grey[300],
                  image: new DecorationImage(
                      fit: BoxFit.cover,
                      colorFilter: new ColorFilter.mode(
                          Colors.white.withOpacity(0.1), BlendMode.dstATop),
                      image: new AssetImage("images/back.jpg"))),
              child: new Stack(fit: StackFit.expand, children: <Widget>[
                ListView(children: <Widget>[
                  new Container(
                      height: 700.0,
                      child: new LoginBackground(Widgets.kitGradients1))
                ]),
                new Container(
                    padding: new EdgeInsets.only(
                        bottom: 24.0, top: 86.0, left: 24.0, right: 24.0),
                    child: new Card(
                        child: new Column(
                      // mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          height: 16.0,
                        ),
                        new Image.asset(
                          "images/ask.png",
                          color: Colors.grey[300],
                          width: 70.0,
                          height: 70.0,
                          fit: BoxFit.cover,
                        ),
                        Container(height: 12.0),
                        new Text(
                          "Vous etes: ",
                          textAlign: TextAlign.center,
                          style: new TextStyle(
                              color: Fonts.col_app_fonn,
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold),
                        ),
                        Container(height: 12.0),

                        Container(
                            height: MediaQuery.of(context).size.height * 0.01),
                        //new Text(,textAlign:TextAlign.center,style: new TextStyle(color: Fonts.col_app,fontWeight: FontWeight.w600,fontSize: 14.0,),),

                        Container(
                            width: MediaQuery.of(context).size.width * 0.82,
                            child: OutlineButton(
                              borderSide: BorderSide(
                                  color: Fonts.col_app_shadow, width: 1.5),
                              shape: new RoundedRectangleBorder(
                                  borderRadius: new BorderRadius.circular(8.0)),
                              padding: EdgeInsets.only(top: 9.0, bottom: 9.0),
                              color: Colors.black,
                              disabledBorderColor: Fonts.col_app,
                              child: Text(
                                "Représentant légal d'une entreprise",
                                style: TextStyle(
                                    color: Fonts.col_app, fontSize: 16),
                              ),
                              onPressed: () async {
                                String my_id = widget.id;

                                parse_s.putparse("users/$my_id",
                                    {"type_profile": "entreprise"});
                                Navigator.push(context, new MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return new EntrepriseForm(
                                      widget.id, "entreprise", widget.chng);
                                }));
                              },
                            )),
                        Container(
                            height: MediaQuery.of(context).size.height * 0.01),

                        or,
                        Container(
                            height: MediaQuery.of(context).size.height * 0.01),

                        Container(
                            width: MediaQuery.of(context).size.width * 0.82,
                            child: OutlineButton(
                              borderSide: BorderSide(
                                  color: Fonts.col_app_shadow, width: 1.5),
                              shape: new RoundedRectangleBorder(
                                  borderRadius: new BorderRadius.circular(8.0)),
                              padding: EdgeInsets.only(top: 9.0, bottom: 9.0),
                              color: Colors.black,
                              disabledBorderColor: Fonts.col_app,
                              child: new Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.81,
                                  child: RichText(
                                      textAlign: TextAlign.center,
                                      text: new TextSpan(
                                        text: "",
                                        children: <TextSpan>[
                                          new TextSpan(
                                            text: "Employé  ",
                                            style: TextStyle(
                                                color: Fonts.col_app,
                                                fontSize: 18),
                                          ),
                                          new TextSpan(
                                              text: //(dans une entreprise déjà inscrite au niveau de la plateforme)
                                                  "",
                                              style: new TextStyle(
                                                  color: Colors.grey[500],
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.w500))
                                        ],
                                      ))),
                              onPressed: () {
                                String my_id = widget.id;
                                parse_s.putparse("users/$my_id",
                                    {"type_profile": "Employé"});
                                Navigator.push(context, new MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return new SubmitNameOrganisme(
                                      widget.id,
                                      "Employé",
                                      widget.name,
                                      widget.email,
                                      widget.chng);
                                }));
                              },
                            )),
                        Container(
                            height: MediaQuery.of(context).size.height * 0.01),

                        or,
                        Container(
                            height: MediaQuery.of(context).size.height * 0.01),
                        Container(
                            width: MediaQuery.of(context).size.width * 0.82,
                            child: OutlineButton(
                              borderSide: BorderSide(
                                  color: Fonts.col_app_shadow, width: 1.5),
                              shape: new RoundedRectangleBorder(
                                  borderRadius: new BorderRadius.circular(8.0)),
                              padding: EdgeInsets.only(top: 9.0, bottom: 9.0),
                              color: Colors.black,
                              disabledBorderColor: Fonts.col_app,
                              child: Text(
                                "Auto Entrepreneur",
                                style: TextStyle(
                                    color: Fonts.col_app, fontSize: 16),
                              ),
                              onPressed: () async {
                                String my_id = widget.id;

                                parse_s.putparse("users/$my_id",
                                    {"type_profile": "Auto entrepreneur"});
                                Navigator.push(context, new MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return new SubmitNameOrganisme(
                                      widget.id,
                                      "Entrepreneur",
                                      widget.name,
                                      widget.email,
                                      widget.chng);
                                }));
                              },
                            )),
                      ],
                    )))
              ]),
            ) /**/));
  }
}
