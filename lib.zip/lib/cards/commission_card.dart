import 'package:flutter/material.dart';
import 'package:medz/cards/details_partner.dart';
import 'package:medz/cards/like_partner_button.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';

class Commission_card_search extends StatefulWidget {
  Commission_card_search(this.commission, this.user,this.lat,this.lng,this.chng);

  Commission commission;
  User user;

  var lat;
  var lng;
  var chng;

  @override
  _Commission_card_search_cardState createState() => _Commission_card_search_cardState();
}

class _Commission_card_search_cardState extends State<Commission_card_search> {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: new EdgeInsets.all(4.0),
        child:  Material(
            elevation: 0.0,
            borderRadius: new BorderRadius.circular(8.0),
            child: Container(
              padding: EdgeInsets.all(4),
              child:
              Row(mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
                GestureDetector(
                    onTap: (){

                    /*  Navigator.push(context,
                          new MaterialPageRoute(builder: (BuildContext context) {
                            return new PartnerCardDetails(widget.commission, widget.lat, widget.lng,
                                widget.user, widget.chng);
                          }));*/
                    },

                    child:  Container(
                      color: Colors.grey[50],
                      child: FadingImage.network(
                       widget.commission.img,
                        fit: BoxFit.contain,
                      ),
                      width: 70,
                      height: 70,
                    )),
                Container(width: 12,),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(
                      width: MediaQuery.of(context).size.width*0.55,
                      child:  Text(
                        widget.commission.name,
                        maxLines: 1,
                        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 14.5,
                        fontFamily: "ab"
                        ),
                      )),
                  Container(height: 4,),
                  Container(
                      width: MediaQuery.of(context).size.width*0.55,
                      child: Text(
                        widget.commission.description.toString()== "null"?"":widget.commission.description,
                        maxLines: 2,

                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: "ralway",
                          color: Colors.grey,
                          fontSize: 14.0,
                        ),
                      )),
                ]),
                Expanded(child: Container(),),
                Container(
                  width: 10,
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                  color: Colors.grey[400],
                ),
                Container(
                  width: 10,
                ),
              ]),
            )));
  }
}
