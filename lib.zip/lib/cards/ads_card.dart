import 'package:flutter/material.dart';
/*

class AdsCard extends StatefulWidget {
  @override
  _MyAppState createState() => new _MyAppState();
}

class _MyAppState extends State<AdsCard> {

  @override
  initState() {
    super.initState();
    setupNativeAd();
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  setupNativeAd() async {
    await FlutterNativeads.setConfiguration(
      admobId: 'ca-app-pub-3940256099942544~3347511713',
      adUnitId: 'ca-app-pub-3940256099942544/8135179316',
      testDeviceId: 'YOUR_TEST_DEVICE_ID',
    );

    await FlutterNativeads.initializeAd();
  }

  @override
  Widget build(BuildContext context) {
    return new AppInstalledAd();
  }
}*/