import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:intl/intl.dart';
import 'package:medz/annonces/details_annonce.dart';
import 'package:medz/cards/details_parc.dart';
import 'package:medz/cards/details_partner.dart';
import 'package:medz/fils_actualit/card_footer.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:timeago/timeago.dart' as ta;
import 'package:video_player/video_player.dart';

class OppCard extends StatefulWidget {
  OppCard(this.offer, this.user, this.lat, this.lng, this.context, this.bl,
      this.chng);

  Offers offer;
  User user;
  var listp;
  var auth;
  var analytics;
  var context;
  var lat;
  var lng;
  var bl;
  var chng;

  @override
  _ParcPubCardState createState() => _ParcPubCardState();
}

class _ParcPubCardState extends State<OppCard> {
  @override
  Widget build(BuildContext context) {
    ScreenUtil.instance = ScreenUtil(width: 750, height: 1334)..init(context);

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    //For ùaking a call
    Future _launched;

    Future _launch(String url) async {
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
    }

    gotomap() {
      var lat = widget.offer.latLng.toString().split(";")[0];
      var lng = widget.offer.latLng.toString().split(";")[1];
      _launched = _launch('https://www.google.com/maps/@$lat,$lng,16z');
    }

    Widget op = Container(
      margin: EdgeInsets.all(8),
      child: Material(
        elevation: 2,
        borderRadius: BorderRadius.all(Radius.circular(8)),
        child: Container(
          // height: ScreenUtil.getInstance().setHeight(236.0),
          child: ClipRRect(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            child: Column(
              children: <Widget>[
                new Container(
                    color: const Color(0xffeefafe),
                    padding: new EdgeInsets.all(8.0),
                    child: new Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                            onTap: () {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new PartnerCardDetails(
                                  widget.offer.partner,
                                  widget.lat,
                                  widget.lng,
                                  widget.user,
                                  widget.chng,
                                );
                              }));
                            },
                            child: new ClipOval(
                                child: new Container(
                                    color: Fonts.col_app,
                                    width: 42.0,
                                    height: 42.0,
                                    child: new Center(
                                        child: FadingImage.network(
                                      widget.offer.partner.logo,
                                      width: 42.0,
                                      height: 42.0,
                                      fit: BoxFit.cover,
                                    ))))),
                        new Container(
                          width: 8.0,
                        ),
                        new Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                                width: MediaQuery.of(context).size.width * 0.25,
                                child: new Text(widget.offer.partner.name,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    style: new TextStyle(
                                        color: Colors.grey[800],
                                        fontWeight: FontWeight.w600,
                                        fontSize: 11.5))),
                            new Container(height: 2.0),
                            ScopedModelDescendant<AppModel1>(
                                builder: (context, child, model) => new Text(
                                      ta.format(widget.offer.create,
                                          locale: model.locale == "ar"
                                              ? "ar"
                                              : "fr"),
                                      style: new TextStyle(
                                          color: Colors.grey[600],
                                          //  fontWeight: FontWeight.bold,
                                          fontSize: 11.0),
                                    )),
                          ],
                        ),
                        new Expanded(child: new Container()),

                        //type()
                        /* widget.offers.pic.isEmpty
                            ? MenuCard(
                            widget.offers, widget.user, delete, Colors.black)*/
                        //   : Container()
                      ],
                    )),
                InkWell(
                    onTap: () {
                      if (widget.bl == false)
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new OppCard(
                              widget.offer,
                              widget.user,
                              widget.lat,
                              widget.lng,
                              context,
                              true,
                              widget.chng);
                        }));
                    },
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          flex: 1,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 0, horizontal: 16),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: <Widget>[
                                Container(
                                  height: 4,
                                ),
                                Text(
                                  widget.offer.name,
                                  maxLines: 2,
                                  style: Theme.of(context)
                                      .textTheme
                                      .display2
                                      .copyWith(
                                          fontSize: 14,
                                          color: Fonts.col_app_fonn,
                                          fontWeight: FontWeight.w700,
                                          height: 1.2),
                                ),
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  children: <Widget>[
                                    Text(
                                      LinkomTexts.of(context).typ()+": ",
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 14,
                                              color: Colors.grey[800],
                                              fontWeight: FontWeight.w900,
                                              height: 1.2),
                                    ),
                                    Container(
                                      width: 8,
                                    ),
                                    Text(
                                      widget.offer.type_op,
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 14,
                                              color: Colors.blue,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2),
                                    ),
                                  ],
                                ),
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  children: <Widget>[
                                    Text(
                                     LinkomTexts.of(context).valid()+ ":  ",
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 14,
                                              color: Colors.black,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2),
                                    ),
                                    Text(
                                      new DateFormat('dd-MM-yyyy')
                                          .format(widget.offer.create),
                                      maxLines: 2,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                              fontSize: 14,
                                              color: const Color(0xffff374e),
                                              fontWeight: FontWeight.w600,
                                              height: 1.2),
                                    ),
                                  ],
                                ),
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: Colors.blue[50],
                                        borderRadius:
                                            BorderRadius.circular(6.0),
                                      ),
                                      child: Row(
                                        children: <Widget>[
                                          Text(
                                            LinkomTexts.of(context).budget()+":  ",
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .display2
                                                .copyWith(
                                                    fontSize: 14,
                                                    color: Colors.black,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2),
                                          ),
                                          Text(
                                            widget.offer.budget.toString() ==
                                                    "null"
                                                ? "0 Dhs"
                                                : widget.offer.budget + " Dhs",
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .display2
                                                .copyWith(
                                                    fontSize: 14,
                                                    color: Colors.amber[700],
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Container(),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: Colors.blue[50],
                                        borderRadius:
                                            BorderRadius.circular(6.0),
                                      ),
                                      child: Row(
                                        children: <Widget>[
                                          Text(
                                           LinkomTexts.of(context).caut()+ ":  ",
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .display2
                                                .copyWith(
                                                    fontSize: 14,
                                                    color: Colors.black,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2),
                                          ),
                                          Text(
                                            widget.offer.cautions.toString() ==
                                                    "null"
                                                ? "0 Dhs"
                                                : widget.offer.cautions
                                                        .toString() +
                                                    " Dhs",
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .display2
                                                .copyWith(
                                                    fontSize: 14,
                                                    color: Colors.amber[700],
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2),
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                                Container(
                                  height: 8,
                                ),
                                HtmlWidget(
                                  widget.bl == true
                                      ? widget.offer.description == ""
                                          ? "----Aucune description ----"
                                          : widget.offer.description
                                      : widget.offer.description == ""
                                          ? "----Aucune description ----"
                                          : widget.offer.description.length <
                                                  270
                                              ? widget.offer.description
                                              : widget.offer.description
                                                      .substring(0, 270) +
                                                  "..",

                                ),
                                Container(
                                  height: 8,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    widget.bl == false
                                        ? InkWell(
                                            child: Text(
                                              LinkomTexts.of(context).details()+" ..",
                                              style: TextStyle(
                                                  color: Fonts.col_app,
                                                  fontWeight: FontWeight.w800,
                                                  decoration:
                                                      TextDecoration.underline,
                                                  fontSize: 16),
                                            ),
                                          )
                                        : Container(),
                                  ],
                                ),
                                /*
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Colors.grey),
                             */

                                /*
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Colors.grey),
                             */
                                Container(
                                  height: 12.0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    )),
                CardFooter(widget.offer, widget.user, null, context,
                    widget.listp, null, widget.lat, widget.lng, widget.chng)
              ],
            ),
          ),
        ),
      ),
    );

    return widget.bl == true
        ? Scaffold(
            appBar: AppBar(
              backgroundColor: Fonts.col_app_shadow,
              elevation: 1,
              title: Text(
                widget.offer.name,
                style: TextStyle(color: Fonts.col_app_fonn, fontSize: 14),
              ),
            ),
            body: op,
          )
        : op;
  }
}
