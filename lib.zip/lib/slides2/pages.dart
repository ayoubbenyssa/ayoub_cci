import 'package:flutter/material.dart';
import 'package:medz/services/Fonts.dart';

final pages = [
  new PageViewModel(
      Fonts.col_app,
      'images/opportunity1.png',
      'MyCGEM ',
      'Bienvenu(e) sur le premier réseau social vertical conçu pour faciliter la mise en relation et le développement des affaires entre les entreprises membres de la confédération générale des entreprises au Maroc!',
      'images/opportunity.png',
      'images/im1_b.jpeg'),
  new PageViewModel(
      Colors.blueGrey[900],
      'images/collaboration.png',
      'Réseautage entreprises/membres',
      'Nous facilitons le networking et l’interaction entre les membres de la confédération dans l’objectif d’augmenter les opportunités d’échange',
      'images/collaboration.png',
      'images/im_b2.jpeg'),
  new PageViewModel(
    // const Color(0xffd6a943),//0xFFd89d9d),
      Colors.teal[900],
      'images/cale.png',
      'Agenda et communiqués',
      'Restez informés des dernières actualités et des événements phares qui vous entourent',
      'images/cale.png',
      'images/cale.jpeg'),

  new PageViewModel(
    // const Color(0xffd6a943),//0xFFd89d9d),
      Colors.indigo[800],
      'images/cost.png',
      'Produits et services divers',
      'Des produits et services sur tous les secteurs vous sont proposés sur votre réseau',
      'images/cost.png',
      'images/cost.jpeg'),
];

class Page extends StatelessWidget {
  final PageViewModel viewModel;
  final double percentVisible;

  Page({
    this.viewModel,
    this.percentVisible = 1.0,
  });

  @override
  Widget build(BuildContext context) {
    return new Container(

        width: double.infinity,
        //color: viewModel.color,
        child: new Container(
          child: new Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // logo,

                /*   new Center(
                    child:   new Text("....................................",
                            style: new  TextStyle(
                              color: Colors.blue[50],
                              fontSize: 22.0,
                              fontWeight: FontWeight.w800,
                              fontFamily: "RapidinhoFontFamily",
                            ))),*/
                //new Container(height: 8.0,),
                new Transform(
                    transform: new Matrix4.translationValues(
                        0.0, 50.0 * (1.0 - percentVisible), 0.0),
                    child: new Container(
                        width: 120.0,
                        height: 120.0,
                        padding: new EdgeInsets.all(4.0),
                        child: new Material(
                          color: const Color(0xfff4f5f6),
                          type: MaterialType.circle,
                          shadowColor: Colors.black,
                          elevation: 8.0,
                          child: new Padding(
                            padding: new EdgeInsets.all(12.0),
                            child: new Image.asset(viewModel.heroAssetPath,
                                 width: 90.0, height: 90.0),
                          ),
                        ))),
                new Container(height: 12.0),

               new Padding(
                    padding: new EdgeInsets.only(top: 12.0, bottom: 4.0,left: 8.0,right: 8.0),
                    child: new Text(
                      viewModel.title,
                      style: new TextStyle(
                        //color: Colors.white,
                        color: Fonts.col_app,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0,
                      ),
                    ),
                  ),

                Container(
                  height: 12.0,
                ),

                new Padding(
                    padding: new EdgeInsets.only(bottom: 4.0,left: 24.0,right: 24.0),
                    child: new Text(
                      viewModel.body,
                      textAlign: TextAlign.center,
                      style: new TextStyle(
                          color: Fonts.col_app,
                          fontWeight: FontWeight.w500,
                          //  color: Colors.white,
                          fontSize: 16.0),
                    ),
                  ),

                new Container(height: 120.0),
              ]),
        ));
  }
}

class PageViewModel {
  final Color color;
  final String heroAssetPath;
  final String title;
  final String body;
  final String iconAssetPath;
  final String background;

  PageViewModel(this.color, this.heroAssetPath, this.title, this.body,
      this.iconAssetPath, this.background);
}
