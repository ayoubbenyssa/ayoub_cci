import 'package:flutter/material.dart';
import 'package:medz/cards/details_partner.dart';
import 'package:medz/cards/like_partner_button.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';

class Entreprise_card_search extends StatefulWidget {
  Entreprise_card_search(this.partner, this.user,this.lat,this.lng,this.chng);

  Partner partner;
  User user;

  var lat;
  var lng;
  var chng;

  @override
  _Entreprise_cardState createState() => _Entreprise_cardState();
}

class _Entreprise_cardState extends State<Entreprise_card_search> {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: new EdgeInsets.all(4.0),
    child:  Material(
        elevation: 0.0,
        borderRadius: new BorderRadius.circular(8.0),
        child: Container(
          padding: EdgeInsets.all(4),
      child:
          Row(mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
       GestureDetector(
           onTap: (){

             Navigator.push(context,
                 new MaterialPageRoute(builder: (BuildContext context) {
                   return new PartnerCardDetails(widget.partner, widget.lat, widget.lng,
                       widget.user, widget.chng);
                 }));
           },

           child:  Container(
          color: Colors.grey[50],
          child: FadingImage.network(
            widget.partner.logo ==
                    "https://cgembusiness.ma//cgem/images/logos/nologo.png"
                ? "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565012657/placeholder_2_seeta8.png"
                : widget.partner.logo,
            fit: BoxFit.contain,
          ),
          width: 70,
          height: 70,
       )),
        Container(width: 12,),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
              width: MediaQuery.of(context).size.width*0.3,
              child:  Text(
            widget.partner.name,
            maxLines: 1,
            style: TextStyle(fontWeight: FontWeight.w900),
          )),
          Container(
              width: MediaQuery.of(context).size.width*0.3,
              child: Text(
            widget.partner.description,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.grey,
              fontSize: 14.0,
            ),
          )),
        ]),
        Expanded(child: Container(),),
            Container(
              width: 10,
            ),
            Icon(
              Icons.arrow_forward_ios,
              size: 20,
              color: Colors.grey[400],
            ),
            Container(
              width: 10,
            ),
      ]),
    )));
  }
}
