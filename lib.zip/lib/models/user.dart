import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/partner.dart';

/*
var stars = [0, 0, 2, 3, 5],
    count = 0,
    sum = 0;

stars.forEach(function(value, index){
  count += value;
  sum += value * (index + 1);
});

console.log(sum / count);
 */
class User {
  User(
      {this.fullname,
      this.id,
      this.image,
      this.email,
        this.respons,
      this.mm,
      this.bio,
        this.fed,
      this.timestamp,
      this.phone,
      this.prenom,
      this.type_profil,
      this.firstname,
      this.item,
        this.updatedAt,
      this.titre,
      this.organisme,
      this.sexe,
      this.age,
        this.des,
      this.objectif,
      this.cmpetences,
      this.block_list,
      this.connect_list,
      this.auth_id,
      this.lat,
      this.token,
      this.entreprise,
      this.createdAt,
      this.lng,
      this.online,
      this.location,
      this.ent,
      this.community,
      this.last_active,
      this.linkedin_link,
      this.communitykey,
      this.instargram_link,
      this.twitter_link,
      this.received_list,
      this.active,
      this.commissions_list,
      this.commissions,
      this.verify,
      this.raja,
      this.anne_exp,
      this.active_loc,
      this.niveau});
  var updatedAt;


  String id = "";
  String niveau;
  String phone = "";
  List<dynamic> commissions_list;
  List<dynamic> commissions;
  List<dynamic> fed;
  var respons;

  bool raja;
  var active_loc;
  var mm = false;
  String password = "";
  String prenom = "";
  String fullname = "";
  String email = "";
  String image = "";
  String bio = "";
  String firstname;
  String linkedin_link;
  String instargram_link;
  String twitter_link;
  bool read;
  var notif_time;
  int ind = 0;
  Partner entreprise;
  var createdAt;
  String notif_id;
  bool accept;
  var type_req;
  var type_profil;
  var token = "";
  var confirm;
  var item;
  String titre = "";
  String organisme = "";
  String sexe;
  var age;
  String anne_exp;
  var cmpetences;
  var objectif;
  String community;
  List<String> list = new List<String>();
  List<String> list_obj = new List<String>();
  var location;
  var lat;
  var online = false;
  var lng;
  String offline = "";
  int last_active = 1;
  String dis;
  var tt = "";
  var active;
  var auth_id;
  bool show = true;
  bool block = true;
  var block_list;
  var connect_list;
  var received_list;
  var communitykey;
  String id_other;
  bool activate = true;
  bool wait = false;
  bool begin = true;
  var cnt = "";
  var ent;
  var verify;
  var des;

  var medz;
  var timestamp;

  static Map<dynamic, dynamic> toMap(User user) => {
        "id1": user.auth_id,
        "token": user.token,
        "objectId": user.id,
        "createdAt": user.createdAt,
        'anne_exp': user.anne_exp,
        "last_active": user.last_active,
        "communityName": user.community,
        "communityKey": user.communitykey,
        'titre': user.titre,
        "lat": double.parse(user.lat),
        "lng": double.parse(user.lng),
        "phone": user.phone,
        "active": int.parse(user.active),
        "location": user.location,
        "linkedin_link": user.linkedin_link,
        "instagram_link": user.instargram_link,
        "twitter_link": user.twitter_link,
        "organisme": user.organisme,
        "familyname": user.fullname,
        "objectif": user.objectif,
        "firstname": user.firstname,
        "age": user.age,
        "email": user.email,
        'sexe': user.sexe,
        "competences": user.cmpetences,
        "bio": user.bio,
        "photoUrl": user.image
      };

  factory User.fromMap(var document) {
    return new User(
      auth_id: document["id1"],
      updatedAt: document["updatedAt"],

      token: document["token"],
      respons: document["respons"],

      commissions_list: document["commissions_list"].toString() == "null"
          ? []
          : document["commissions_list"],
      commissions: document["commissions"].toString() == "null"
          ? []
          : document["commissions"]
              .map((val) => Commission.fromDoc(val))
              .toList(),
      fed: document["fed"].toString() == "null"
          ? []
          : document["fed"]
          .map((val) => Commission.fromDoc(val))
          .toList(),
      verify: document["verify"],
      id: document["objectId"],
      type_profil: document["type_profil"],
      createdAt: document["createdAt"],
      active_loc: document["active_loc"],
      anne_exp: document['anne_exp'],
      entreprise: document["entreprise"].toString() == "null"
          ? null
          : new Partner.fromMap(document["entreprise"]),
      ent: document["ent"],
      niveau: document["niveau"],
      raja: document["raja"],
      des: document["des"],
      community:
          document["communityName"] == null ? "" : document["communityName"],
      communitykey:
          document["communityKey"] == null ? "" : document["communityKey"],
      titre: document['titre'].toString() == "null" ? "" : document['titre'],
      lat: document["lat"].toString() == "null"
          ? ""
          : document["lat"].toString(),
      lng: document["lng"].toString() == "null"
          ? ""
          : document["lng"].toString(),
      phone: document['phone'].toString() == "null" ? "" : document['phone'],
      active: document["active"] == null ? 0 : document["active"],
      location:
          document["location"].toString() == "null" ? "" : document["location"],
      linkedin_link:
          document['linkedin_link'] == "null" ? "" : document['linkedin_link'],
      instargram_link: document['instagram_link'] == "null"
          ? ""
          : document['instagram_link'],
      twitter_link:
          document['twitter_link'] == "null" ? "" : document['twitter_link'],

      organisme: document['organisme'].toString() == "null"
          ? ""
          : document['organisme'],
      fullname: document['familyname'],
      firstname: document['firstname'],
      objectif:
          document["objectif"].toString() == "null" ? "" : document["objectif"],
      age: document["age"].toString() == "null"
          ? ""
          : document["age"].toString(),
      email: document['email'],
      sexe: document['sexe'].toString() == "null" ? "" : document['sexe'],
      //online: document["online"],
      cmpetences: document["competences"].toString() == "null"
          ? []
          : document["competences"],

      bio: document['bio'],

      image:
          document['photoUrl'].toString() == "null" ? "" : document['photoUrl'],
    );
  }

  factory User.fromDoc(var document) {
    return new User(
      id: document.documentID,
      verify: document["verify"],

      community:
          document["communityName"] == null ? "" : document["communityName"],
      titre: document['titre'],
      lat: document["lat"],
      lng: document["lng"],
      phone: document['phone'],
      active: document["active"],
      location: document["location"],
      linkedin_link: document['linkedin_link'],
      organisme: document['organisme'],
      fullname: document['familyname'],
      firstname: document['firstname'],
      objectif: document["objectif"],
      //  date_naissance: document["date_naissance"],
      email: document['email'],
      sexe: document['sexe'],
      image: document['photoUrl'],
      item: new DecorationImage(
        image: new NetworkImage(document['photoUrl']),
        fit: BoxFit.cover,
      ),
    );
  }

  factory User.fromDocument(DocumentSnapshot document) {
    return new User(
        community: document["communityName"],
        email: document['email'],
        titre: document['titre'],
        sexe: document['sexe'],
        objectif: document["objectif"],
        cmpetences: document["competences"],
        //date_naissance: document["date_naissance"],
        organisme: document['organisme'],
        anne_exp: document['anne_exp'],
        timestamp: document["timestamp"],
        fullname: document['familyname'],
        firstname: document['firstname'],
        phone: document['phone'],
        image: document['photoUrl'],
        id: document.documentID,
        bio: document['bio'],
        item: new DecorationImage(
          image: new NetworkImage(document['photoUrl']),
          fit: BoxFit.cover,
        ));
  }
}
