import 'package:cloud_firestore/cloud_firestore.dart';

class Commission {
  String id;
  String name;
  String img;
  var name_ar;
  var desc_ar;

  bool isselected = false;
  String objectId;
  bool check = false;
  var description;
  var docUrl;
  var chef;

  Commission(
      {this.id,
      this.name,
      this.img,
      this.objectId,
      this.docUrl,
      this.description,
      this.chef,
      this.name_ar,
      this.desc_ar});

  factory Commission.fromDoc(Map<String, dynamic> document) {
    return new Commission(
        objectId: document["objectId"],
        name: document["name"],
        name_ar: document["name_ar"],
        desc_ar: document["desc_ar"],
        img: document["picture"],
        description: document["description"],
        docUrl: document["docUrl"],
        chef: document["chef"]);
  }
}


