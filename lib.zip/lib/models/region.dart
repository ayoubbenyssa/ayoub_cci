class Region {
  String id;
  String name;
  var num;
  bool check = false;

  Region(this.id, this.name, this.num);

  Region.fromMap(Map<String, dynamic> map)
      : id = map["objectId"],
        name = map["region"],
        check = false,
        num = map["num"];
}
