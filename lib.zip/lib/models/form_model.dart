// example viewmodel for the form
class PonyModel {
  String name = 'Twilight Sparkle';
  String type = '';
  String fonction="";
  String origine="";
  bool stress = false;
  bool tabac=false;
  var desc_tabac="";
  bool peau=false;
  bool IMC=false;
  bool lait=false;
  bool viande=false;
  bool litre=false;
  bool intolerances=false;
  var intel_desc;

  bool contraception=false;
  var desc_menopause="";
  int age = 7;
  String coatColor = 'D19FE4';
  String maneColor = '273873';
  bool hasSpots = false;
  bool hasFood = false;
  bool hasi = false;

  String spotColor = 'FF5198';
  String desc_cause="";
  String desc_regime="";
  String why_loose="";
  String desc_food_breakfast="";
  String between_food="";
  String like_food="";
  String dislike_food="";
  String food_diner_lunch="";
  String sweet_or_salty="";
  String history="";
  String type_activity="";
  String sexe="";
  bool pattes = false;
  bool grossess = false;


  bool pacemaker= false;
  bool diabete = false;
  bool insuf= false;
  bool prob = false;
  var desc_prob ="";
  bool trouble = false;









  List<String> hobbies = <String>[
    'flying',
    'singing',
    'exploring',
    'hiding',
    'coloring'
  ];
  double height = 3.5;
  int weight = 45;
  int weight2 = 45;

  DateTime showDateTime = DateTime(2010, 10, 10, 20, 30);
  double ticketPrice = 65.99;
  int boxOfficePhone = 8005551212;
  String email = 'me@nowhere.org';
  String password = 'secret1';
}

const List<String> allHobbies = <String>[
  'running',
  'flying',
  'coloring',
  'jumping',
  'eating',
  'hiding',
  'exploring',
  'singing',
  'dancing',
  'acting',
  'cleaning',
  'shopping',
  'sewing',
  'cooking',
];
