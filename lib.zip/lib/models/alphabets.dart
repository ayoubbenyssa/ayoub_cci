class Alphabets {
  static var ll = [
    {
      "url": "/upload/486247729.pdf",
      "image": "/upload/1113704440.jpg",
      "date": "Mardi 10 Janvier 2017"
    },
    {
      "url": "/upload/1229876771.pdf",
      "image": "/upload/1568586958.jpg",
      "date": "Vendredi 6 Janvier 2017"
    },
    {
      "url": "/upload/1549903964.pdf",
      "image": "/upload/2043914997.jpg",
      "date": "Jeudi 5 Janvier 2017"
    },
    {
      "url": "/upload/1541791537.pdf",
      "image": "/upload/1678187788.jpg",
      "date": "Mercredi 4 Janvier 2017"
    },
    {
      "url": "/upload/2052921504.pdf",
      "image": "/upload/1458799014.jpg",
      "date": "Mardi 3 Janvier 2017"
    },
    {
      "url": "/upload/1098248205.pdf",
      "image": "/upload/1689066657.jpg",
      "date": "Lundi 2 Janvier 2017"
    },
    {
      "url": "/upload/1992494525.pdf",
      "image": "/upload/684266623.jpg",
      "date": "Vendredi 23 Décembre 2016"
    },
    {
      "url": "/upload/1111898905.pdf",
      "image": "/upload/1374981822.jpg",
      "date": "Mercredi 21 Décembre 2016"
    },
    {
      "url": "/upload/1055119776.pdf",
      "image": "/upload/1907686283.jpg",
      "date": "Lundi 19 Décembre 2016"
    },
    {
      "url": "/upload/1325546626.pdf",
      "image": "/upload/2095619163.jpg",
      "date": "Jeudi 15 Décembre 2016"
    },
    {
      "url": "/upload/118544273.pdf",
      "image": "/upload/1626837888.jpg",
      "date": "Vendredi 9 Décembre 2016"
    },
    {
      "url": "/upload/528808809.pdf",
      "image": "/upload/572548135.jpg",
      "date": "Jeudi 8 Décembre 2016"
    },
    {
      "url": "/upload/627979352.pdf",
      "image": "/upload/1951814037.jpg",
      "date": "Mercredi 7 Décembre 2016"
    },
    {
      "url": "/upload/384356545.pdf",
      "image": "/upload/1131316689.jpg",
      "date": "Mardi 6 Décembre 2016"
    },
    {
      "url": "/upload/1299745379.pdf",
      "image": "/upload/866008359.jpg",
      "date": "Lundi 5 Décembre 2016"
    },
    {
      "url": "/upload/268989881.pdf",
      "image": "/upload/119694003.jpg",
      "date": "Jeudi 1 Décembre 2016"
    },
    {
      "url": "/upload/1402013929.pdf",
      "image": "/upload/585681765.jpg",
      "date": "Mercredi 30 Novembre 2016"
    },
    {
      "url": "/upload/479677372.pdf",
      "image": "/upload/1610040187.jpg",
      "date": "Lundi 28 Novembre 2016"
    },
    {
      "url": "/upload/1716828069.pdf",
      "image": "/upload/1023076187.jpg",
      "date": "Vendredi 25 Novembre 2016"
    },
    {
      "url": "/upload/966528948.pdf",
      "image": "/upload/1880902602.jpg",
      "date": "Jeudi 24 Novembre 2016"
    },
    {
      "url": "/upload/2140871600.pdf",
      "image": "/upload/1651017157.jpg",
      "date": "Mercredi 23 Novembre 2016"
    },
    {
      "url": "/upload/706551542.pdf",
      "image": "/upload/2137665867.jpg",
      "date": "Mardi 22 Novembre 2016"
    },
    {
      "url": "/upload/486247729.pdf",
      "image": "/upload/1113704440.jpg",
      "date": "Mardi 10 Janvier 2017"
    },
    {
      "url": "/upload/1229876771.pdf",
      "image": "/upload/1568586958.jpg",
      "date": "Vendredi 6 Janvier 2017"
    },
    {
      "url": "/upload/1549903964.pdf",
      "image": "/upload/2043914997.jpg",
      "date": "Jeudi 5 Janvier 2017"
    },
    {
      "url": "/upload/1541791537.pdf",
      "image": "/upload/1678187788.jpg",
      "date": "Mercredi 4 Janvier 2017"
    },
    {
      "url": "/upload/2052921504.pdf",
      "image": "/upload/1458799014.jpg",
      "date": "Mardi 3 Janvier 2017"
    },
    {
      "url": "/upload/1098248205.pdf",
      "image": "/upload/1689066657.jpg",
      "date": "Lundi 2 Janvier 2017"
    },
    {
      "url": "/upload/1992494525.pdf",
      "image": "/upload/684266623.jpg",
      "date": "Vendredi 23 Décembre 2016"
    },
    {
      "url": "/upload/1111898905.pdf",
      "image": "/upload/1374981822.jpg",
      "date": "Mercredi 21 Décembre 2016"
    },
    {
      "url": "/upload/1055119776.pdf",
      "image": "/upload/1907686283.jpg",
      "date": "Lundi 19 Décembre 2016"
    },
    {
      "url": "/upload/1325546626.pdf",
      "image": "/upload/2095619163.jpg",
      "date": "Jeudi 15 Décembre 2016"
    },
    {
      "url": "/upload/118544273.pdf",
      "image": "/upload/1626837888.jpg",
      "date": "Vendredi 9 Décembre 2016"
    },
    {
      "url": "/upload/528808809.pdf",
      "image": "/upload/572548135.jpg",
      "date": "Jeudi 8 Décembre 2016"
    },
    {
      "url": "/upload/627979352.pdf",
      "image": "/upload/1951814037.jpg",
      "date": "Mercredi 7 Décembre 2016"
    },
    {
      "url": "/upload/384356545.pdf",
      "image": "/upload/1131316689.jpg",
      "date": "Mardi 6 Décembre 2016"
    },
    {
      "url": "/upload/1299745379.pdf",
      "image": "/upload/866008359.jpg",
      "date": "Lundi 5 Décembre 2016"
    },
    {
      "url": "/upload/268989881.pdf",
      "image": "/upload/119694003.jpg",
      "date": "Jeudi 1 Décembre 2016"
    },
    {
      "url": "/upload/1402013929.pdf",
      "image": "/upload/585681765.jpg",
      "date": "Mercredi 30 Novembre 2016"
    },
    {
      "url": "/upload/479677372.pdf",
      "image": "/upload/1610040187.jpg",
      "date": "Lundi 28 Novembre 2016"
    },
    {
      "url": "/upload/1716828069.pdf",
      "image": "/upload/1023076187.jpg",
      "date": "Vendredi 25 Novembre 2016"
    },
    {
      "url": "/upload/966528948.pdf",
      "image": "/upload/1880902602.jpg",
      "date": "Jeudi 24 Novembre 2016"
    },
    {
      "url": "/upload/2140871600.pdf",
      "image": "/upload/1651017157.jpg",
      "date": "Mercredi 23 Novembre 2016"
    },
    {
      "url": "/upload/706551542.pdf",
      "image": "/upload/2137665867.jpg",
      "date": "Mardi 22 Novembre 2016"
    },
    {
      "url": "/upload/1262041571.pdf",
      "image": "/upload/1180003461.jpg",
      "date": "Lundi 21 Novembre 2016"
    },
    {
      "url": "/upload/1947961830.pdf",
      "image": "/upload/1785388967.jpg",
      "date": "Jeudi 3 Novembre 2016"
    },
    {
      "url": "/upload/1540911592.pdf",
      "image": "/upload/1762405825.jpg",
      "date": "Mercredi 2 Novembre 2016"
    },
    {
      "url": "/upload/966311473.pdf",
      "image": "/upload/239921179.jpg",
      "date": "Mardi 1 Novembre 2016"
    },
    {
      "url": "/upload/694883238.pdf",
      "image": "/upload/1357819878.jpg",
      "date": "Vendredi 28 Octobre 2016"
    },
    {
      "url": "/upload/1856202485.pdf",
      "image": "/upload/2054872224.jpg",
      "date": "Jeudi 27 Octobre 2016"
    },
    {
      "url": "/upload/1399118102.pdf",
      "image": "/upload/16674849.jpg",
      "date": "Mercredi 26 Octobre 2016"
    },
    {
      "url": "/upload/767884717.pdf",
      "image": "/upload/1178598402.jpg",
      "date": "Mardi 25 Octobre 2016"
    },
    {
      "url": "/upload/2106172030.pdf",
      "image": "/upload/1277883031.jpg",
      "date": "Lundi 24 Octobre 2016"
    },
    {
      "url": "/upload/1754835241.pdf",
      "image": "/upload/261688139.jpg",
      "date": "Vendredi 21 Octobre 2016"
    },
    {
      "url": "/upload/38205935.pdf",
      "image": "/upload/193439395.jpg",
      "date": "Jeudi 20 Octobre 2016"
    },
    {
      "url": "/upload/672103653.pdf",
      "image": "/upload/556883875.jpg",
      "date": "Mercredi 19 Octobre 2016"
    },
    {
      "url": "/upload/140954826.pdf",
      "image": "/upload/197455050.jpg",
      "date": "Mardi 18 Octobre 2016"
    },
    {
      "url": "/upload/366696811.pdf",
      "image": "/upload/880314929.jpg",
      "date": "Lundi 17 Octobre 2016"
    },
    {
      "url": "/upload/1856229385.pdf",
      "image": "/upload/1904822160.jpg",
      "date": "Vendredi 14 Octobre 2016"
    },
    {
      "url": "/upload/985554891.pdf",
      "image": "/upload/700147852.jpg",
      "date": "Jeudi 13 Octobre 2016"
    },
    {
      "url": "/upload/276073142.pdf",
      "image": "/upload/332074338.jpg",
      "date": "Mercredi 12 Octobre 2016"
    },
    {
      "url": "/upload/1033712373.pdf",
      "image": "/upload/254949911.jpg",
      "date": "Vendredi 7 Octobre 2016"
    },
    {
      "url": "/upload/187302204.pdf",
      "image": "/upload/236882873.jpg",
      "date": "Jeudi 6 Octobre 2016"
    },
    {
      "url": "/upload/157662974.pdf",
      "image": "/upload/19941276.jpg",
      "date": "Mercredi 5 Octobre 2016"
    },
    {
      "url": "/upload/155038908.pdf",
      "image": "/upload/957685174.jpg",
      "date": "Mardi 4 Octobre 2016"
    },
    {
      "url": "/upload/1238081877.pdf",
      "image": "/upload/868292433.jpg",
      "date": "Vendredi 30 Septembre 2016"
    },
    {
      "url": "/upload/1125896409.pdf",
      "image": "/upload/1608186670.jpg",
      "date": "Jeudi 29 Septembre 2016"
    },
    {
      "url": "/upload/145917184.pdf",
      "image": "/upload/1307115236.jpg",
      "date": "Mercredi 28 Septembre 2016"
    },
    {
      "url": "/upload/2073585001.pdf",
      "image": "/upload/793968940.jpg",
      "date": "Mardi 27 Septembre 2016"
    },
    {
      "url": "/upload/366642513.pdf",
      "image": "/upload/5268780.jpg",
      "date": "Lundi 26 Septembre 2016"
    },
    {
      "url": "/upload/2144104468.pdf",
      "image": "/upload/144245223.jpg",
      "date": "Vendredi 23 Septembre 2016"
    },
    {
      "url": "/upload/150625540.pdf",
      "image": "/upload/149104529.jpg",
      "date": "Jeudi 22 Septembre 2016"
    },
    {
      "url": "/upload/1308241879.pdf",
      "image": "/upload/175074417.jpg",
      "date": "Mercredi 21 Septembre 2016"
    },
    {
      "url": "/upload/1023228743.pdf",
      "image": "/upload/1315196353.jpg",
      "date": "Vendredi 16 Septembre 2016"
    },
    {
      "url": "/upload/116440796.pdf",
      "image": "/upload/1149012049.jpg",
      "date": "Vendredi 9 Septembre 2016"
    },
    {
      "url": "/upload/735873422.pdf",
      "image": "/upload/277663518.jpg",
      "date": "Jeudi 8 Septembre 2016"
    },
    {
      "url": "/upload/1602556226.pdf",
      "image": "/upload/1837568762.jpg",
      "date": "Mercredi 7 Septembre 2016"
    },
    {
      "url": "/upload/1071392965.pdf",
      "image": "/upload/737558502.jpg",
      "date": "Mardi 6 Septembre 2016"
    },
    {
      "url": "/upload/688842685.pdf",
      "image": "/upload/1851606965.jpg",
      "date": "Lundi 5 Septembre 2016"
    },
    {
      "url": "/upload/1003813325.pdf",
      "image": "/upload/797990225.jpg",
      "date": "Vendredi 2 Septembre 2016"
    },
    {
      "url": "/upload/726898425.pdf",
      "image": "/upload/667844681.jpg",
      "date": "Jeudi 1 Septembre 2016"
    },
    {
      "url": "/upload/1603703826.pdf",
      "image": "/upload/289610577.jpg",
      "date": "Mercredi 31 Août 2016"
    },
    {
      "url": "/upload/1282960953.pdf",
      "image": "/upload/1822450413.jpg",
      "date": "Mardi 30 Août 2016"
    },
    {
      "url": "/upload/864507069.pdf",
      "image": "/upload/1553150556.jpg",
      "date": "Lundi 29 Août 2016"
    },
    {
      "url": "/upload/824819304.pdf",
      "image": "/upload/1744934525.jpg",
      "date": "Vendredi 29 Juillet 2016"
    },
    {
      "url": "/upload/498310953.pdf",
      "image": "/upload/1323433183.jpg",
      "date": "Jeudi 28 Juillet 2016"
    },
    {
      "url": "/upload/1605820950.pdf",
      "image": "/upload/1058023000.jpg",
      "date": "Mercredi 27 Juillet 2016"
    },
    {
      "url": "/upload/864306922.pdf",
      "image": "/upload/851475461.jpg",
      "date": "Mardi 26 Juillet 2016"
    },
    {
      "url": "/upload/1257860520.pdf",
      "image": "/upload/1864678372.jpg",
      "date": "Lundi 25 Juillet 2016"
    },
    {
      "url": "/upload/205604150.pdf",
      "image": "/upload/1627254280.jpg",
      "date": "Vendredi 22 Juillet 2016"
    },
    {
      "url": "/upload/924207566.pdf",
      "image": "/upload/487577243.jpg",
      "date": "Jeudi 21 Juillet 2016"
    },
    {
      "url": "/upload/113416586.pdf",
      "image": "/upload/32073278.jpg",
      "date": "Mercredi 20 Juillet 2016"
    },
    {
      "url": "/upload/709169164.pdf",
      "image": "/upload/686323098.jpg",
      "date": "Lundi 18 Juillet 2016"
    },
    {
      "url": "/upload/1241769956.pdf",
      "image": "/upload/1873406601.jpg",
      "date": "Vendredi 15 Juillet 2016"
    },
    {
      "url": "/upload/1324327324.pdf",
      "image": "/upload/290061312.jpg",
      "date": "Jeudi 14 Juillet 2016"
    },
    {
      "url": "/upload/1967635042.pdf",
      "image": "/upload/1261770724.jpg",
      "date": "Mercredi 13 Juillet 2016"
    },
    {
      "url": "/upload/1967635042.pdf",
      "image": "/upload/1261770724.jpg",
      "date": "Mercredi 13 Juillet 2016"
    },
    {
      "url": "/upload/2034201029.pdf",
      "image": "/upload/1096630810.jpg",
      "date": "Lundi 11 Juillet 2016"
    },
    {
      "url": "/upload/143391300.pdf",
      "image": "/upload/201316382.jpg",
      "date": "Mardi 5 Juillet 2016"
    },
    {
      "url": "/upload/61725757.pdf",
      "image": "/upload/1001791149.jpg",
      "date": "Lundi 4 Juillet 2016"
    },
    {
      "url": "/upload/774696847.pdf",
      "image": "/upload/694045550.jpg",
      "date": "Vendredi 1 Juillet 2016"
    },
    {
      "url": "/upload/241137907.pdf",
      "image": "/upload/114279979.jpg",
      "date": "Jeudi 30 Juin 2016"
    },
    {
      "url": "/upload/705142426.pdf",
      "image": "/upload/1858603020.jpg",
      "date": "Mercredi 29 Juin 2016"
    },
    {
      "url": "/upload/1838964141.pdf",
      "image": "/upload/1615809550.jpg",
      "date": "Mardi 28 Juin 2016"
    },
    {
      "url": "/upload/732330553.pdf",
      "image": "/upload/1698987808.jpg",
      "date": "Lundi 27 Juin 2016"
    },
    {
      "url": "/upload/1101047597.pdf",
      "image": "/upload/806652597.jpg",
      "date": "Vendredi 24 Juin 2016"
    },
    {
      "url": "/upload/672819291.pdf",
      "image": "/upload/548730910.jpg",
      "date": "Mercredi 22 Juin 2016"
    },
    {
      "url": "/upload/830016689.pdf",
      "image": "/upload/302468883.jpg",
      "date": "Lundi 20 Juin 2016"
    },
    {
      "url": "/upload/28317179.pdf",
      "image": "/upload/433152768.jpg",
      "date": "Vendredi 17 Juin 2016"
    },
    {
      "url": "/upload/1276997148.pdf",
      "image": "/upload/203783266.jpg",
      "date": "Mercredi 15 Juin 2016"
    },
    {
      "url": "/upload/1905062877.pdf",
      "image": "/upload/347876324.jpg",
      "date": "Lundi 13 Juin 2016"
    },
    {
      "url": "/upload/666404860.pdf",
      "image": "/upload/1829908203.jpg",
      "date": "Mercredi 8 Juin 2016"
    },
    {
      "url": "/upload/2052134428.pdf",
      "image": "/upload/788804620.jpg",
      "date": "Lundi 6 Juin 2016"
    },
    {
      "url": "/upload/931947177.pdf",
      "image": "/upload/1150977381.jpg",
      "date": "Vendredi 3 Juin 2016"
    },
    {
      "url": "/upload/1041836073.pdf",
      "image": "/upload/1311137793.jpg",
      "date": "Jeudi 2 Juin 2016"
    },
    {
      "url": "/upload/1642874427.pdf",
      "image": "/upload/2002646596.jpg",
      "date": "Mercredi 1 Juin 2016"
    },
    {
      "url": "/upload/1111297853.pdf",
      "image": "/upload/1050083979.jpg",
      "date": "Lundi 30 Mai 2016"
    },
    {
      "url": "/upload/2020919243.pdf",
      "image": "/upload/1118760165.jpg",
      "date": "Vendredi 27 Mai 2016"
    },
    {
      "url": "/upload/1689939328.pdf",
      "image": "/upload/1836119627.jpg",
      "date": "Jeudi 26 Mai 2016"
    },
    {
      "url": "/upload/338758324.pdf",
      "image": "/upload/776809709.jpg",
      "date": "Mercredi 25 Mai 2016"
    },
    {
      "url": "/upload/902864156.pdf",
      "image": "/upload/761360797.jpg",
      "date": "Mardi 24 Mai 2016"
    },
    {
      "url": "/upload/1935789321.pdf",
      "image": "/upload/615068648.jpg",
      "date": "Lundi 23 Mai 2016"
    },
    {
      "url": "/upload/1793795671.pdf",
      "image": "/upload/888371300.jpg",
      "date": "Vendredi 20 Mai 2016"
    },
    {
      "url": "/upload/261841741.pdf",
      "image": "/upload/2025971471.jpg",
      "date": "Vendredi 20 Mai 2016"
    },
    {
      "url": "/upload/261841741.pdf",
      "image": "/upload/2025971471.jpg",
      "date": "Vendredi 20 Mai 2016"
    },
    {
      "url": "/upload/261841741.pdf",
      "image": "/upload/2025971471.jpg",
      "date": "Vendredi 20 Mai 2016"
    },
    {
      "url": "/upload/261841741.pdf",
      "image": "/upload/2025971471.jpg",
      "date": "Vendredi 20 Mai 2016"
    },
    {
      "url": "/upload/2045068519.pdf",
      "image": "/upload/1079598016.jpg",
      "date": "Jeudi 19 Mai 2016"
    },
    {
      "url": "/upload/1902033110.pdf",
      "image": "/upload/1625679526.jpg",
      "date": "Mercredi 18 Mai 2016"
    },
    {
      "url": "/upload/887350962.pdf",
      "image": "/upload/1161944377.jpg",
      "date": "Mardi 17 Mai 2016"
    },
    {
      "url": "/upload/1431501140.pdf",
      "image": "/upload/821115020.jpg",
      "date": "Lundi 16 Mai 2016"
    },
    {
      "url": "/upload/1918303909.pdf",
      "image": "/upload/1246707463.jpg",
      "date": "Vendredi 13 Mai 2016"
    },
    {
      "url": "/upload/707684468.pdf",
      "image": "/upload/608696680.jpg",
      "date": "Jeudi 31 Mars 2016"
    },
    {
      "url": "/upload/760261288.pdf",
      "image": "/upload/1498499972.jpg",
      "date": "Mercredi 30 Mars 2016"
    },
    {
      "url": "/upload/1270892673.pdf",
      "image": "/upload/720975984.jpg",
      "date": "Mardi 29 Mars 2016"
    },
    {
      "url": "/upload/1692138185.pdf",
      "image": "/upload/775254345.jpg",
      "date": "Lundi 28 Mars 2016"
    },
    {
      "url": "/upload/1377881278.pdf",
      "image": "/upload/780591487.jpg",
      "date": "Vendredi 25 Mars 2016"
    },
    {
      "url": "/upload/502543266.pdf",
      "image": "/upload/449157206.jpg",
      "date": "Jeudi 24 Mars 2016"
    },
    {
      "url": "/upload/1366765592.pdf",
      "image": "/upload/1493003463.jpg",
      "date": "Mercredi 23 Mars 2016"
    },
    {
      "url": "/upload/572434093.pdf",
      "image": "/upload/1689952224.jpg",
      "date": "Mardi 22 Mars 2016"
    },
    {
      "url": "/upload/1223623296.pdf",
      "image": "/upload/162254778.jpg",
      "date": "Lundi 21 Mars 2016"
    },
    {
      "url": "/upload/320838978.pdf",
      "image": "/upload/1862754763.jpg",
      "date": "Mardi 15 Mars 2016"
    },
    {
      "url": "/upload/619135635.pdf",
      "image": "/upload/595274534.jpg",
      "date": "Lundi 14 Mars 2016"
    },
    {
      "url": "/upload/1138404982.pdf",
      "image": "/upload/1465860591.jpg",
      "date": "Vendredi 11 Mars 2016"
    },
    {
      "url": "/upload/1592892761.pdf",
      "image": "/upload/220826171.jpg",
      "date": "Mercredi 9 Mars 2016"
    },
    {
      "url": "/upload/1708633010.pdf",
      "image": "/upload/1775023059.jpg",
      "date": "Mardi 8 Mars 2016"
    },
    {
      "url": "/upload/1171816177.pdf",
      "image": "/upload/50573199.jpg",
      "date": "Lundi 7 Mars 2016"
    },
    {
      "url": "/upload/75440084.pdf",
      "image": "/upload/921370577.jpg",
      "date": "Vendredi 4 Mars 2016"
    },
    {
      "url": "/upload/75440084.pdf",
      "image": "/upload/921370577.jpg",
      "date": "Vendredi 4 Mars 2016"
    },
    {
      "url": "/upload/127856757.pdf",
      "image": "/upload/1133724631.jpg",
      "date": "Jeudi 3 Mars 2016"
    },
    {
      "url": "/upload/1347733674.pdf",
      "image": "/upload/651981633.jpg",
      "date": "Mercredi 2 Mars 2016"
    },
    {
      "url": "/upload/517579565.pdf",
      "image": "/upload/1485666922.jpg",
      "date": "Mardi 1 Mars 2016"
    },
    {
      "url": "/upload/253062315.pdf",
      "image": "/upload/723852137.jpg",
      "date": "Lundi 29 Février 2016"
    },
    {
      "url": "/upload/223004105.pdf",
      "image": "/upload/566929917.jpg",
      "date": "Vendredi 26 Février 2016"
    }
  ];

  static var list = [
    {
      "a":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263219/Stulton_Coffee_4_ryap9e.png",
      "b":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263253/Stulton_Coffee_5_oozmwu.png",
      "c":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263289/Stulton_Coffee_6_nh1sv1.png",
      "d":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263337/Stulton_Coffee_7_lpxikh.png",
      "e":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263372/Stulton_Coffee_8_azawpw.png",
      "f":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263418/Stulton_Coffee_9_npdmep.png",
      "g":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565264993/Stulton_Coffee_20_cvvpmc.png",
      "h":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263516/Stulton_Coffee_11_en51ef.png",
      "i":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263561/Stulton_Coffee_12_xibol7.png",
      "j":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263599/Stulton_Coffee_13_tunf1j.png",
      "k":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263644/Stulton_Coffee_14_mrqopl.png",
      "l":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265574/Stulton_Coffee_30_najggw.png",
      "m":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263009/Stulton_Coffee_2_w3mu1l.png",
      "n":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263730/Stulton_Coffee_16_kdkpt3.png",
      "o":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263897/Stulton_Coffee_17_vvtbaf.png",
      "p":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263993/Stulton_Coffee_18_mvngqr.png",
      "q":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265479/Stulton_Coffee_29_dhktew.png",
      "r":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265048/Stulton_Coffee_22_c2jgjc.png",
      "s":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265078/Stulton_Coffee_23_ynwzqz.png",
      "t":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265125/Stulton_Coffee_24_oguw2b.png",
      "u":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265157/Stulton_Coffee_25_x5jqcs.png",
      "v":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265222/Stulton_Coffee_26_qqxjzs.png",
      "w":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565262610/Stulton_Coffee_ktqyxh.png",
      "x":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265231/Stulton_Coffee_27_w10jvr.png",
      "y":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565263094/Stulton_Coffee_3_czn9da.png",
      "z":
          "https://res.cloudinary.com/dgxctjlpx/image/upload/v1565265332/Stulton_Coffee_28_vdkmsm.png",
    }
  ];
}
