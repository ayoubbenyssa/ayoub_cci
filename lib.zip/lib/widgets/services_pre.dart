import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/home/conventions.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/models/serv.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/widgets.dart';
import 'package:scoped_model/scoped_model.dart';

class ServicesPre extends StatefulWidget {
  ServicesPre(this.lat, this.lng, this.user, this.chng);

  var lat, lng;
  User user;
  var chng;


  @override
  _ServicesPreState createState() => _ServicesPreState();
}

class _ServicesPreState extends State<ServicesPre> {
  ParseServer services = new ParseServer();
  List<Serv> serv = new List<Serv>();
  bool load = true;

  getservices() async {
    var a = await services.getparse("services");
    if (!this.mounted) return;
    List res = a["results"];
    print("<3");
    print(res);
    List<dynamic> list =
        res.map((var contactRaw) => new Serv.fromMap(contactRaw)).toList();
    setState(() {
      serv = list;
      load = false;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getservices();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text(
          LinkomTexts.of(context).services() +
              ' (' +
              serv.length.toString() +
              ')',
          style: TextStyle(color: Fonts.col_app_fonn,fontWeight: FontWeight.w500),
        ),
        iconTheme: IconThemeData(color: Fonts.col_app_fonn),
        backgroundColor: Fonts.col_app_shadow,
      ),
      body: Container(
          child: load
              ? Center(
                  child: Widgets.load(),
                )
              : ListView(
                  children: serv
                      .map((Serv a) => Padding(
                          padding: EdgeInsets.all(2),
                          child: ScopedModelDescendant<AppModel1>(
                              builder: (context, child, model) => Card(
                                  color: Colors.blue[50],
                                  child: new ExpansionTile(
                                    title: Container(
                                        padding: EdgeInsets.all(8),
                                        color: Colors.blue[50],
                                        child: Text(
                                          model.locale == "ar"
                                              ? a.name_ar
                                              : a.name,
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    children: <Widget>[
                                      Container(
                                        padding: EdgeInsets.all(12),
                                        color: Colors.white,
                                        child: Column(
                                          children: <Widget>[
                                            Text(
                                              model.locale == "ar"
                                                  ? a.desc_ar
                                                  : a.desc,
                                              style: TextStyle(
                                                  color: Colors.grey[600]),
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: <Widget>[
                                                RaisedButton(
                                                  color: Fonts.col_app,
                                                  onPressed: () {
                                                    if (a.name ==
                                                        "Tarifs préférentiels") {
                                                      Navigator.push(context,
                                                          new MaterialPageRoute(
                                                              builder:
                                                                  (BuildContext
                                                                      context) {
                                                        return new Conventions(
                                                            widget.lat,
                                                            widget.lng,
                                                            widget.user,
                                                            null,
                                                            null,
                                                            "cgem",widget.chng,
                                                        );
                                                      }));
                                                    } else
                                                      Navigator.push(context,
                                                          new MaterialPageRoute<
                                                                  String>(
                                                              builder:
                                                                  (BuildContext
                                                                      context) {
                                                        return new WebviewScaffold(
                                                          url: a.lien,
                                                          appBar: new AppBar(
                                                            title: new Text(
                                                                model.locale ==
                                                                        "ar"
                                                                    ? a.name_ar
                                                                    : a.name),
                                                          ),
                                                        );
                                                      }));
                                                  },
                                                  child: Text(
                                                    LinkomTexts.of(context)
                                                        .details(),
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.w800),
                                                  ),
                                                )
                                              ],
                                            )
                                          ],
                                        ),
                                      )
                                    ],
                                  )))))
                      .toList())),
    );
  }
}
