// ignore_for_file: constant_identifier_names
class GlobalVariables {
  static const String URL_LINKED_IN_GET_ACCESS_TOKEN =
      'https://www.linkedin.com/oauth/v2/accessToken';
  static const String URL_LINKED_IN_GET_AUTH_TOKEN =
      'https://www.linkedin.com/oauth/v2/authorization';
}
