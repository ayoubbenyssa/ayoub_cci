import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/services/Fonts.dart';
import 'package:scoped_model/scoped_model.dart';

class Presentation extends StatefulWidget {
  @override
  _PresentationState createState() => _PresentationState();
}

class _PresentationState extends State<Presentation> {
  var summary = null;
  ParseServer parse_server = new ParseServer();

  getpr() async {
    var a = await parse_server.getparse("presentation");
    if (!this.mounted) return;

    print(a["results"]);

    setState(() {
      summary = a["results"][0];
    });
  }

  @override
  void initState() {
    super.initState();
    getpr();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          elevation: 1.0,
          iconTheme: IconThemeData(color: Fonts.col_app_fon),
          backgroundColor: Fonts.col_app_shadow,
          title: Text(
            LinkomTexts.of(context).pres(),
            style: TextStyle(
                color: Fonts.col_app_fonn,
                fontSize: 18.0,
                fontWeight: FontWeight.w400),
          )),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: <Widget>[
          ScopedModelDescendant<AppModel1>(
              builder: (context, child, model) => HtmlWidget(

                    summary == null
                        ? ""
                        : model.locale == "ar"
                            ? summary["text_ar"]
                                .toString()
                                .replaceAll(RegExp(r'(\\n)+'), '')
                            : summary["text"]
                                .toString()
                                .replaceAll(RegExp(r'(\\n)+'), ''),


                  ))
        ],
      ),
    );
  }
}
