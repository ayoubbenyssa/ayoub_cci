import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:medz/annonces/details_annonce.dart';
import 'package:medz/cards/buy_button.dart';
import 'package:medz/cards/commande_button.dart';
import 'package:medz/cards/details_parc.dart';
import 'package:medz/cards/like_partner_button.dart';
import 'package:medz/cards/like_widget.dart';
import 'package:medz/cards/participatebutton.dart';
import 'package:medz/cards/prom_details.dart';
import 'package:medz/chat/chatscreen.dart';
import 'package:medz/co_voiturage/alert_rate.dart';
import 'package:medz/co_voiturage/comments/comments.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/models/video.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/commentsfunctions.dart';
import 'package:medz/services/like_wall_function.dart';
import 'package:medz/shop/pages/product_page.dart';

class CardFooter extends StatefulWidget {
  CardFooter(this.an, this.user, this.deletepost, this.context, this.list,
      this.analytics, this.lat, this.lng, this.onLocaleChange,
      {this.ratefunc});

  var an;
  var deletepost;
  var context;
  User user;
  var list;
  var analytics;
  double lat;
  double lng;
  var onLocaleChange;
  var ratefunc;

  @override
  _CardFooterState createState() => new _CardFooterState();
}

class _CardFooterState extends State<CardFooter> {
  String _value1 = 'addfav';
  CommentFunctions commentFunctions = new CommentFunctions();

  //likes
  LikeFunctions likeFunctions = new LikeFunctions();

  var likestext = "Likes";

  var load = true;

  isliked() async {
    var onValue =
        await likeFunctions.isliked(widget.an.objectId, widget.user.id);
    try {
      setState(() => widget.an.isLiked = onValue);
    } catch (e) {}
    return onValue;
  }

  toggletar() async {
    /* _heartAnimationController.forward().whenComplete(() {
      _heartAnimationController.reverse();
    });*/
    var res =
        await likeFunctions.like(widget.an.objectId, context, widget.user.id);
    if (res == "nointernet") {
    } else if (res == "error") {
    } else {
      try {
        setState(() {
          widget.an.isLiked = res["isLiked"];
          widget.an.likesCount = res["numberLikes"];
        });
      } catch (e) {}
    }
  }

  rate() async {
    List off = await AlertRate.dialog2(
        context,
        widget.an.name,
        widget.an.pic[0],
        widget.an.rating,
        widget.an.objectId,
        widget.an.count_r,
        context,
        my_id: widget.user.id,
        id_other: widget.an.objectId);
    setState(() {
      widget.an.rating = off[0];
      widget.an.count_r = off[1];
    });

    widget.ratefunc(widget.an);
  }

  @override
  initState() {
    super.initState();
    isliked();
    getnumbers();
    getNumbeComments();
  }

  func() {
    setState(() {
      widget.an.numbercommenttext =
          (int.parse(widget.an.numbercommenttext) + 1).toString();
    });
  }

  getnumbers() async {
    var count = await likeFunctions.numberLikes(widget.an.objectId);
    try {
      setState(() {
        widget.an.likesCount = count;
        likestext = " Likes";
        if (widget.an.likesCount.toString() == "1") likestext = " like";
      });
    } catch (e) {}
  }

  getNumbeComments() {
    commentFunctions.numberComments(widget.an.objectId).then((count) {
      try {
        setState(() {
          widget.an.numbercommenttext = count.toString() /*+" Comments"*/;
        });
      } catch (e) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget numbercomments = new Text(
      "  ( " + widget.an.numbercommenttext.toString() + " )",
      style: new TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
    );

    Widget textlike = new Text(
        widget.an.likesCount.toString() == "null"
            ? "0"
            : widget.an.likesCount.toString(),
        style: new TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500));

    Widget decodertoggletar = new Container(
        child: widget.an.isLiked
            ? new Image.asset("images/hand.png", width: 18.0, height: 18.0)
            : new Image.asset("images/handn.png", width: 18.0, height: 18.0));

    Widget iconlike = decodertoggletar;

    goto() {}

    return new Container(
        padding: EdgeInsets.only(left: 8),
        color: /*const Color(0xffedd9ac)*/ Colors.white,
        child: new Container(
            height: MediaQuery.of(context).size.height * 0.06,
            margin: new EdgeInsets.only(
                left: 4.0, right: 4.0, bottom: 6.0, top: 4.0),
            child: new Row(mainAxisAlignment: MainAxisAlignment.start,
                //crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  FavoriteButton(widget.an, widget.user),
                  /* new InkWell(
                      onTap: () => toggletar(),
                    */
                  new Container(
                    width: 8.0,
                  ),
                  //  textlike,

                  new InkWell(
                    child: new Image.asset("images/cht.png",
                        width: 18.0, height: 18.0),
                    onTap: () async {
                      Navigator.push(
                          context,
                          new MaterialPageRoute<Null>(
                              builder: (BuildContext context) => new Comments(
                                  widget.an, "", true, widget.user, func)));

                      //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                    },
                  ),
                  new Container(
                    width: 2.0,
                  ),
                  numbercomments,
                  new Container(width: 4.0),

                  /* widget.an.type == "event"
                      ? CircleAvatar(
                          backgroundColor: Colors.white,
                          child: InkWell(
                              onTap: () {
                                rate();
                              },
                              child: new Image.asset(
                                "images/medal.png",
                                color: Colors.black,
                                width: 18.0,
                                height: 18.0,
                              )))
                      : Container(),*/

                  Container(
                    width: 2,
                  ),
                /*  widget.an.type == "event"
                      ? widget.an.docUrl == null || widget.an.docUrl == ""
                          ? Container()
                          : CircleAvatar(
                              backgroundColor: Colors.white,
                              // backgroundColor: Colors.amber[400],
                              child: InkWell(
                                  onTap: () {
                                    Navigator.push(context, new MaterialPageRoute<String>(
                                        builder: (BuildContext context) {
                                          return new WebviewScaffold(
                                            url: widget.an.docUrl,
                                            appBar: new AppBar(
                                              title: new Text(widget.an.name),
                                            ),
                                          );
                                        }));
                                  },
                                  child: new Image.asset(
                                    "images/pdf.png",
                                    color: Colors.black,
                                    width: 18.0,
                                    height: 18.0,
                                  )))*/


                  /*

                    Navigator.push(context, new MaterialPageRoute<String>(
                  builder: (BuildContext context) {
                return new  Scaffold(
                  appBar: AppBar(
                    title: const Text('Plugin example app'),
                  ),
                  body: SimplePdfViewerWidget(
                    completeCallback: (bool result){
                      print("completeCallback,result:${result}");
                    },
                    initialUrl: "https://www.orimi.com/pdf-test.pdf",
                  ),
                );
              }));
                   */
                  new Container(width: 8.0),

                  /* widget.an.author.toString() == "null"
                      ? Container()
                      : widget.user.auth_id == widget.an.author.auth_id
                          ? Container()
                          : new InkWell(
                              child: new Image.asset("images/cht.png",
                                  color: Colors.green[600],
                                  width: 26.0,
                                  height: 26.0),
                              onTap: () async {
                                Navigator.push(context, new MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return new ChatScreen(
                                      widget.user.auth_id,
                                      widget.an.author.auth_id,
                                      goto,
                                      false,
                                      null,
                                      widget.analytics,
                                      widget.onLocaleChange,
                                      user: widget.user);
                                }));

                                //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                              },
                            ),*/
                  Container(
                    width: 12,
                  ),
                  widget.an.author.toString() == "null"
                      ? Container()
                      : widget.an.author.id == widget.user.id
                          ? new InkWell(
                              child: new Image.asset("images/icons/delete.png",
                                  color: Colors.red[700],
                                  width: 22.0,
                                  height: 22.0),
                              onTap: () async {
                                await showDialog<String>(
                                      context: context,
                                      child: new AlertDialog(
                                        title: const Text(''),
                                        content: const Text(
                                            'Voulez vous supprimer ce post ?'),
                                        actions: <Widget>[
                                          new FlatButton(
                                              child: const Text('Ok'),
                                              onPressed: () {
                                                widget.deletepost();

                                                Navigator.of(context,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              }),
                                          new FlatButton(
                                            child: const Text('Cancel'),
                                            onPressed: () {
                                              Navigator.of(context,
                                                      rootNavigator: true)
                                                  .pop('dialog');
                                            },
                                          ),
                                        ],
                                      ),
                                    ) ??
                                    false;

                                //  rt.gotocomment(context, widget.news, widget.news.author["objectId"],false,false);
                              },
                            )
                          : Container(),
                  new Expanded(
                      child: new Container(
                    width: 6.0,
                  )),

                  widget.an.type == "event"
                      ? ParticipateButton(widget.an, widget.user, null, context)
                      : Container(),
                  widget.an.type != "sondage" &&
                          widget.an.type != "opportunite" &&
                          widget.an.type != "video" &&
                          widget.an.type != "prod_service"
                      ? new RaisedButton(
                          color: Colors.grey[100],
                          elevation: 1,
                          shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.all(
                            Radius.circular(6.0),
                          )),
                          // padding: EdgeInsets.all(0),
                          onPressed: () {
                            if (widget.an.type == "Annonces" ||
                                widget.an.type == "Objets perdus" ||
                                widget.an.type == "Général" ||
                                widget.an.type == "Général") {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new DetailsAnnonce(
                                    widget.an,
                                    widget.user,
                                    widget.list,
                                    null,
                                    widget.analytics,
                                    widget.onLocaleChange);
                              }));
                            } else if (widget.an.type == "news" ||
                                widget.an.type == "event") {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new DetailsParc(
                                    widget.an,
                                    widget.user,
                                    widget.an.type,
                                    widget.list,
                                    null,
                                    widget.analytics,
                                    widget.onLocaleChange,
                                    widget.lat,
                                    widget.lng);
                              }));
                            } else if (widget.an.type == "promotion") {
                              Navigator.push(context, new MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return new Promo_details(
                                    widget.an,
                                    widget.user,
                                    widget.lat,
                                    widget.lng,
                                    widget.onLocaleChange);
                              }));
                            } else if (widget.an.type == "boutique") {
                              Navigator.push(
                                  context,
                                  new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          ProductPage(
                                              widget.an,
                                              widget.user,
                                              widget.lat,
                                              widget.lng,
                                              widget.onLocaleChange)));
                            }
                          },
                          child: Container(
                              child: Text(
                            LinkomTexts.of(context).details(),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: ScreenUtil.getInstance().setSp(26),
                              color: Fonts.col_app_green,
                            ),
                          )))
                      : Container(),
                  Container(
                    width: 8,
                  )
                ]))); //2E9E51
  }
}
