import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:medz/communities/details_com.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/language_params/scope_model_wrapper.dart';
import 'package:medz/login/join_com.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/community.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';
import 'package:medz/widgets/groups_commission.dart';
import 'package:scoped_model/scoped_model.dart';

class Fedwidget extends StatefulWidget {
  Fedwidget(this.com, this.auth, this.sign, this.id, this.user, this.show,
      this.list, this.view, this.chng);

  Commission com;
  var auth;
  var sign;
  String id = "";
  ParseServer parse_s = new ParseServer();
  User user;
  bool show;
  List<Commission> list = [];
  bool view;
  var chng;

  @override
  _CommunitywidgetState createState() => _CommunitywidgetState();
}

class _CommunitywidgetState extends State<Fedwidget> {
  @override
  Widget build(BuildContext context) {
    var style = new TextStyle(
        fontWeight: FontWeight.w900, color: Colors.black, fontSize: 18.0);

    var checkk = widget.view
        ? Container()
        : new InkWell(
            onTap: () {
              //widget.func();

              if (widget.com.check == true) {
                setState(() {
                  widget.com.check = false;
                });
                /*
            {
              "__type": "Pointer",
              "className": "apebi_communities",
              "objectId": widget.com.objectId
            }
             */
                print(widget.list.remove(widget.com));
              } else {
                setState(() {
                  widget.com.check = true;
                });
                widget.list.add(widget.com);
              }
            },
            child: new Container(
              margin: new EdgeInsets.only(left: 8.0, right: 0.0),
              child: new Row(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  new Container(
                    // height: 70.0,
                    //width: 70.0,
                    child: new RaisedButton(
                      shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(10.0)),
                      child: Text(LinkomTexts.of(context).rej_c()),
                      color: widget.com.check == true
                          ? Colors.blue
                          : Colors.grey[300],
                    ),
                    decoration: new BoxDecoration(
                      color: widget.com.check
                          ? Colors.grey[100]
                          : Colors.grey[100],
                      border: new Border.all(
                          width: 2.0,
                          color: widget.com.check
                              ? Colors.blue[300]
                              : Colors.grey[300]),
                      borderRadius:
                          const BorderRadius.all(const Radius.circular(36.0)),
                    ),
                  )
                ],
              ),
            ),
          );

    return Container(
      padding: EdgeInsets.only(left: 4, right: 4, top: 4),
      child: Card(
          child: Column(children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new InkWell(
                onTap: () {},
                child: ClipRRect(
                    //<--clipping image
                    borderRadius:
                        BorderRadius.horizontal(left: Radius.circular(8)),
                    child: new Container(
                        color: Colors.white,
                        height: MediaQuery.of(context).size.height * 0.1,
                        width: MediaQuery.of(context).size.width * 0.24,
                        child: new Center(
                            child: Hero(
                                tag: widget.com.objectId,
                                child: FadingImage.network(
                                  widget.com.img,
                                  width:
                                      MediaQuery.of(context).size.width * 0.24,
                                  fit: BoxFit.cover,
                                )))))),
            Container(
              width: 8,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  height: 4,
                ),
                ScopedModelDescendant<AppModel1>(
                  builder: (context, child, model) =>  Container(
                            width: MediaQuery.of(context).size.width * 0.65,
                            child: Text(
                              model.locale == "ar"
                                  ? widget.com.name_ar.toString()
                                  : widget.com.name.toString(),
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold),
                            ))),
                Container(
                  height: 4,
                ) ,
               /* ScopedModelDescendant<AppModel1>(
                  builder: (context, child, model) => ScopedModel<AppModel1>(
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.68,
                      child:     HtmlWidget(

                       model.locale=="ar"?widget.com.desc_ar.toString():widget.com.description.toString()
                            .replaceAll(RegExp(r'(\\n)+'), '').toString().substring(0,270)+"...",
                        config: new Config(
                          baseUrl: Uri.parse('/'),
                          onLinkTap: (String url) {},
                        ),
                      ), /*Text(
                      widget.com.description.toString() == 'null'
                          ? "Aucune description trouvée                                          "
                              "                                                      "
                          : widget.com.description.toString(),
                      maxLines: 3,
                      style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                    )*/)))*/

              ],
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
                width: MediaQuery.of(context).size.width * 0.44,
                child: RaisedButton(
                  shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(4.0)),
                  padding: EdgeInsets.all(4),
                  color: Fonts.col_app,
                  child: Text(
                    LinkomTexts.of(context).details(),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                new ComDetails(widget.com, true)));
                  },
                )),
            Container(
              width: 16,
            ),
            Container(
                width: MediaQuery.of(context).size.width * 0.44,
                child: OutlineButton(
                  padding: EdgeInsets.all(4),
                  borderSide: BorderSide(color: Fonts.col_app, width: 1.5),
                  shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(4.0)),
                  color: Colors.black,
                  disabledBorderColor: Fonts.col_app,
                  child: Text(LinkomTexts.of(context).rej_f(),
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: Fonts.col_app)),
                  onPressed: () {
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                new GroupCommissions(
                                    0.0,
                                    0.0,
                                    widget.user,
                                    [],
                                    null,
                                    widget.com.objectId,
                                    "federation",
                                    widget.chng)));
                    //JoinCom
                  },
                ))
          ],
        )
      ])),
    ) /*new GestureDetector(
        onTap: () {
          // nearDistance();
        },
        child: new Container(
          margin: EdgeInsets.only(top: 1,bottom: 1),
          height: MediaQuery.of(context).size.height*0.2,
            decoration: new BoxDecoration(
                color: Colors.grey[800],
                image: new DecorationImage(
                    fit: BoxFit.fitWidth,
                    colorFilter: new ColorFilter.mode(
                        Colors.black.withOpacity(0.24), BlendMode.dstATop),
                    image: new NetworkImage(widget.com.img))),
            child:  Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[

                Container(width: 8,),
               Container(width: MediaQuery.of(context).size.width*0.75,
                 child:_buildTextContainer(context)),
                checkk,
                Expanded(child: Container()),

                ],)

            ))*/
        ;

    /*
    new Material(

              elevation: 4.0,
              borderRadius: new BorderRadius.circular(2.0),
              child:
               new Padding(
            padding: const EdgeInsets.all(
              // vertical: 4.0,
              0.0,
            ),
            child:
     */
  }
}
