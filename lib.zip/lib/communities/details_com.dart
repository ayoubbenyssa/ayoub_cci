import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';

class ComDetails extends StatefulWidget {
  ComDetails(this.com,this.bl);

  Commission com;
  bool bl = false;

  @override
  _ComDetailsState createState() => _ComDetailsState();
}

class _ComDetailsState extends State<ComDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey[50],
        appBar: AppBar(
          backgroundColor: Fonts.col_app_shadow,
          iconTheme: IconThemeData(color: Fonts.col_app_fonn),
          title: Text(
            LinkomTexts.of(context).details(),
            style: TextStyle(color: Fonts.col_app_fonn),
          ),
        ),
        body: ListView(
          children: <Widget>[
            new Hero(
              tag: widget.com.objectId,
              child: FadingImage.network(
                widget.com.img,
                height: MediaQuery.of(context).size.height * 0.3,
                fit: BoxFit.cover,
              ),
            ),
            Container(
                padding: EdgeInsets.all(12),
                width: MediaQuery.of(context).size.width * 0.65,
                child: Text(
                  widget.com.name,
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                )),
          widget.bl?      HtmlWidget(
            widget.com.description
                .toString()
                .replaceAll(RegExp(r'(\\n)+'), ''),

          ) :Container(
                padding: EdgeInsets.all(12),
                width: MediaQuery.of(context).size.width * 0.68,
                child: Text(
                  widget.com.description.toString() == 'null'
                      ? "Aucune description trouvée                                          "
                          "                                                      "
                      : widget.com.description.toString(),
                  style: TextStyle(fontSize: 15, color: Colors.grey[600]),
                )),
            widget.com.docUrl==null?Container():   Container(
                padding: EdgeInsets.only(left: 12, right: 12),
                child: InkWell(
                  child: Text(
                    LinkomTexts.of(context).here(),
                    style: TextStyle(
                        color: Fonts.col_app,
                        decoration: TextDecoration.underline,
                        fontWeight: FontWeight.w800),
                  ),
                  onTap: () {

                    if(Platform.isIOS)
                      Navigator.push(context,
                          new MaterialPageRoute<String>(
                              builder: (BuildContext context) {
                                return new WebviewScaffold(
                                  url: widget.com.docUrl,
                                  appBar: new AppBar(
                                    title: new Text(widget.com.name),
                                  ),
                                );
                              }));

                  },
                ))
          ],
        ));
  }
}
