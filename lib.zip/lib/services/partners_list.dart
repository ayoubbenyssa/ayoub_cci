import 'dart:convert';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/objectif.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/pro.dart';
import 'package:medz/models/region.dart';
import 'package:medz/models/resp.dart';
import 'package:medz/models/shop.dart';
import 'package:medz/models/ville.dart';





class PartnersList{
  static ParseServer parse_s = new ParseServer();


  static get_list_partners() async {//,"sponsored":1
    String url = 'partners?where={"active":1}&order=-createdAt';
    var getcity = await parse_s.getparse(url);
    if (getcity == "No") return "No";
    if (getcity == "error") return "error";
    List res =  getcity["results"];

    return res.map((var contactRaw) => new Partner.fromMap(contactRaw))
        .toList();
  }


  static get_list_entreprise(skip) async {//,"sponsored":1
    String url =         'partners?where={"active":1,"type":"entreprise","imageUrl":{"\$ne":"https://res.cloudinary.com/dgxctjlpx/image/upload/v1565012657/placeholder_2_seeta8.png"}}&order=-createdAt&limit=24&skip=$skip';

    var getcity = await parse_s.getparse(url);
    if (getcity == "No") return "No";
    if (getcity == "error") return "error";
    List res =  getcity["results"];

    return res.map((var contactRaw) => new Partner.fromMap(contactRaw))
        .toList();
  }

  static get_list_entreprise1(skip) async {//,"sponsored":1
    String url = 'partners?where={"active":1,"type":"entreprise"}&order=-createdAt&limit=3400&skip=$skip';
    var getcity = await parse_s.getparse(url);
    if (getcity == "No") return "No";
    if (getcity == "error") return "error";
    List res =  getcity["results"];

    return res.map((var contactRaw) => new Partner.fromMap(contactRaw))
        .toList();
  }


  static get_list_resp(skip) async {//,"sponsored":1
    String url = 'responsabilities?order=-createdAt&limit=3400';
    var getcity = await parse_s.getparse(url);
    if (getcity == "No") return "No";
    if (getcity == "error") return "error";
    List res =  getcity["results"];

    return res.map((var contactRaw) => new Resp.fromDoc(contactRaw))
        .toList();
  }

  static get_list_regions() async {//,"sponsored":1
    String url = 'region?order=-createdAt&limit=3400';
    var getcity = await parse_s.getparse(url);
    if (getcity == "No") return "No";
    if (getcity == "error") return "error";
    List res =  getcity["results"];

    return res.map((var contactRaw) => new Region.fromMap(contactRaw))
        .toList();
  }


  static get_list_ville(num) async {//,"sponsored":1
    String url = 'ville?where={"region":"$num"}&order=-createdAt&limit=3400';
    var getcity = await parse_s.getparse(url);
    if (getcity == "No") return "No";
    if (getcity == "error") return "error";
    List res =  getcity["results"];

    return res.map((var contactRaw) => new Ville.fromMap(contactRaw))
        .toList();
  }

  static get_objectifs() async {
    String url = 'objectifs2';
    var getcity = await parse_s.getparse(url);

    if (getcity == "No Internet") return "No Internet";
    if (getcity == "error") return "error";
    List res =  getcity["results"];
    return res.map((var contactRaw) => new Objectif.fromDoc(contactRaw))
        .toList();
  }


  static get_type() async {
    String url = 'type_pro1';
    var getcity = await parse_s.getparse(url);
    print(getcity);
    if (getcity == "No") return "No";
    if (getcity == "error") return "error";
    List res =  getcity["results"];
    return res.map((var contactRaw) => new Pro.fromDoc(contactRaw))
        .toList();
  }



  static get_list_shop(id,objectId) async {

    String url ="";
    if(id.toString() == "null")
      {
     url = 'offers?where={"partnerKey":"$objectId","type":"shop"}';
      }else {
      url =
      'offers?where= {"\$or":[{"partnerKey":{"\$eq":"$id"}},{"partnerKey":{"\$eq":"$objectId"}}],"type":"shop"}';
    }
    var getcity = await parse_s.getparse(url);
    if (getcity == "No Internet") return "No Internet";
    if (getcity == "error") return "error";
    List res =  getcity["results"];
    return res.map((var contactRaw) => new Shop.fromMap(contactRaw))
        .toList();
  }



  static getShp_details(id,objectId) async {
    String url = 'shops?where= {"\$or":[{"partnerKey":{"\$eq":"$id"}},{"partnerKey":{"\$eq":"$objectId"}}]}';
    var getcity = await parse_s.getparse(url);
    if (getcity == "No Internet") return "No Internet";
    if (getcity == "error") return "error";
    var res =  getcity["results"][0];
    return new Shop.fromMap(res);

  }




}


