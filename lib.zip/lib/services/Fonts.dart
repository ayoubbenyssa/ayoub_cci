import 'package:flutter/material.dart';


class Fonts {

  static const Color col_app =     const Color(0xff3b7ab3);//0b72a4);
  static const Color col_app_fon =const Color(0xff0a6396);
  static const Color col_app_shadow = const Color(0xffd0e9f9);
  static const Color col_app_fonn = const Color(0xff05356a);
  static const Color col_app_green = const Color(0xff3e92ca);//Color(0xff00b281);
  static const Color col_green = const Color(0xfffdfdff);
  static const Color col_grey = const Color(0xffb0b6c5);
  static const Color col_gr = const Color(0xff3e92ca);

  static TextStyle st(size) => TextStyle(
      color: Colors.black,
      fontFamily: "ab",
      fontSize: size,
      fontWeight: FontWeight.w600);
  static const Color col_cl = const Color(0xffebebeb);
  static var footer = new TextStyle(
      color: col_app, fontWeight: FontWeight.w600, fontSize: 9.5);

  static List<Color> kitGradients = [
    // new Color.fromRGBO(103, 218, 255, 1.0),
    // new Color.fromRGBO(3, 169, 244, 1.0),
    // new Color.fromRGBO(0, 122, 193, 1.0),
    col_app,
    Colors.blue[200],
  ];


}
