import 'package:http/http.dart' as clientHttp;


class EmailService {


  static sendCustomMail(emails, subject, message)  async{
   var res =  await clientHttp.post(
        "https://us-central1-fluttergram-18608.cloudfunctions.net/sendCustomMailToUser",
        body: {"subject": subject, "message": message, "email": emails});


   print(res.body);

   return res.body;

  }
}
