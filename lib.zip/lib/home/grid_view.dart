import 'dart:async';

import 'package:flutter/material.dart';
import 'package:medz/annonces/annonces_tabs.dart';
import 'package:medz/biblio_videos/BiblioThequevideos.dart';
import 'package:medz/co_voiturage/covoiturages.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/home/conventions.dart';
import 'package:medz/home/events.dart';
import 'package:medz/home/opportunite.dart';
import 'package:medz/home/parc.dart';
import 'package:medz/home/publications.dart';
import 'package:medz/home/revuepress.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/user.dart';
import 'package:medz/products/products_services.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/app_services.dart';
import 'package:medz/shop/principal.dart';
import 'package:medz/widgets/apebi_pre.dart';

class Grid_view extends StatefulWidget {
  Grid_view(this._pageController, this.lat, this.lng, this.user, this.auth,
      this.list_partner, this.analytics, this.func, this.index, this.chng);

  var _pageController;
  var lat;
  var lng;
  User user;
  var auth;
  var list_partner;
  var analytics;
  var func;
  int index = 0;
  var chng;

  @override
  _Grid_viewState createState() => _Grid_viewState();
}

class _Grid_viewState extends State<Grid_view> {
  String verify;
  ParseServer parse_s = new ParseServer();

  getUser(id) async {
    var a = await parse_s.getparse('users?where={"objectId":"$id"}&include=respons');
    if (!this.mounted) return;
    print(a);

    setState(() {
      verify = a["results"][0]["verify"].toString();
      print(verify);
    });
  }

  @override
  void initState() {
    //getcurrentuser();

    super.initState();

    getUser(widget.user.id);
  }

  _showDialog1() async {
    return await showDialog(
        context: context,
        child: new AlertDialog(
            contentPadding: const EdgeInsets.all(16.0),
            content: Container(
                height: 160,
                child: Column(children: <Widget>[
                  Text(
                      LinkomTexts.of(context).option()),
                ]))));
  }

  Widget clmn(clr1, clr2, img, text, size, {go}) => Container(
          //padding: EdgeInsets.only(left:8.0,right: 24.0),
          child: new Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                InkWell(
                    onTap: () {
                      Navigator.pop(context);

                      if (go == "gerer") {
                        widget.index = 3;
                        widget.func(3);

                        new Timer(const Duration(milliseconds: 200), () {
                          widget._pageController.animateToPage(3,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.ease);
                        });
                      } else if (go == "prod") {
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new ProductServices(
                            widget.lat,
                            widget.lng,
                            widget.user,
                            widget.list_partner,
                            widget.analytics,
                            widget.chng,
                          );
                        }));
                      }

                      if (go == "pro") {
                        if (verify == "1")
                          Navigator.push(context, new MaterialPageRoute(
                              builder: (BuildContext context) {
                            return new Opportunite(
                              widget.lat,
                              widget.lng,
                              widget.user,
                              widget.list_partner,
                              widget.analytics,
                              widget.chng,
                            );
                          }));
                        else
                          _showDialog1();
                      } else if (go == "net") {
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new Presentation();
                        }));
                      } else if (go == "fils") {
                        widget.index = 0;
                        widget.func(0);
                        new Timer(const Duration(milliseconds: 200), () {
                          widget._pageController.animateToPage(0,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.ease);
                        });
                      } else if (go == "mes") {
                        widget.index = 2;
                        widget.func(2);
                        new Timer(const Duration(milliseconds: 200), () {
                          widget._pageController.animateToPage(2,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.ease);
                        });
                      } else if (go == "fl") {
                        widget.index = 0;
                        widget.func(0);
                        new Timer(const Duration(milliseconds: 200), () {
                          widget._pageController.animateToPage(0,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.ease);
                        });
                      } else if (go == "nett") {
                        widget.index = 1;
                        widget.func(1);
                        new Timer(const Duration(milliseconds: 200), () {
                          widget._pageController.animateToPage(1,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.ease);
                        });
                      } else if (go == "parc") {
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new Events(
                            widget.lat,
                            widget.lng,
                            widget.user,
                            widget.list_partner,
                            widget.auth,
                            0,
                            widget.analytics,
                            widget.chng,
                          );
                        }));
                      } else if (go == "pub")
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new Publications(
                              widget.lat,
                              widget.lng,
                              widget.user,
                              widget.list_partner,
                              widget.auth,
                              0,
                              widget.analytics,                    widget.chng,
                          );
                        }));
                      else if (go == "co")
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new RevuePress(
                              widget.user,
                              widget.lat,
                              widget.lng,
                              widget.list_partner,

                              widget.analytics,                    widget.chng,
                          );
                        }));
                      else if (go == "con") {
                        if (verify == "1")
                          Navigator.push(context, new MaterialPageRoute(
                              builder: (BuildContext context) {
                            return new Conventions(
                              widget.lat,
                              widget.lng,
                              widget.user,
                              widget.list_partner,
                              widget.analytics,
                              "cgem",
                              widget.chng,
                            );
                          }));
                        else
                          _showDialog1();
                      } else if (go == "av") {
                        if (verify == "1")
                          Navigator.push(context, new MaterialPageRoute(
                              builder: (BuildContext context) {
                            return new Conventions(
                              widget.lat,
                              widget.lng,
                              widget.user,
                              widget.list_partner,
                              widget.analytics,
                              "linkommunity",
                              widget.chng,
                            );
                          }));
                        else
                          _showDialog1();
                      } else if (go == "ad")
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new AnnoncesTabs(
                            widget.user,
                            widget.auth,
                            null,
                            widget.lat,
                            widget.lng,
                            widget.list_partner,
                            0,
                            widget.analytics,
                            widget.chng,
                          );
                        }));
                      else if (go == "bt")
                        Navigator.push(context, new MaterialPageRoute(
                            builder: (BuildContext context) {
                          return new BiblioVideos(
                            widget.user,
                            widget.lat,
                            widget.lng,
                            widget.list_partner,
                            widget.analytics,
                            widget.chng,
                          );
                        }));

                    },
                    child: Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: clr2,
                            borderRadius:
                                BorderRadius.all(Radius.circular(16.0))),
                        width: 60.0,
                        height: 60.0,
                        child: new Image.asset(
                          img,
                          color: clr1,
                          width: go == "fils" ? 45.0 : 60.0,
                          height: go == "fils" ? 45.0 : 60.0,
                          // fit: BoxFit.contain,
                        )))
              ]),
            ],
          ),
          Container(
            height: 4.0,
          ),
          Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 12.0,
                fontWeight: FontWeight.w500,
                color: Fonts.col_app_fonn),
          ),
        ],
      ));

  @override
  Widget build(BuildContext context) {
    //
    Widget clmn2(clr1, clr2, img, text, size, go) => Container(
            //padding: EdgeInsets.only(left:8.0,right: 24.0),
            child: new Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Column(
              children: <Widget>[
                Row(children: [
                  new Container(
                    width: 2.0,
                    height: 50.0,
                    decoration: new BoxDecoration(
                      color: clr1,
                      borderRadius: BorderRadius.only(
                        topLeft: new Radius.circular(52.0),
                        bottomLeft: new Radius.circular(52.0),
                      ),
                    ),
                  ),
                  InkWell(
                      onTap: () {},
                      child: Container(
                          width: 60.0,
                          height: 60.0,
                          child: new Image.asset(
                            img,
                            color: clr1,
                            width: size,
                            height: size,
                            // fit: BoxFit.contain,
                          )))
                ]),
              ],
            ),
            Container(
              height: 4.0,
            ),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.0, fontWeight: FontWeight.w600),
            ),
          ],
        ));

    //

    return new GridView.count(
        primary: false,
        padding: const EdgeInsets.all(0),
        crossAxisCount: 4,
        childAspectRatio: MediaQuery.of(context).size.width <= 600 ? 0.76 : 1.6,
        mainAxisSpacing: 2.0,
        //crossAxisSpacing: 6.0,
        children: <Widget>[
          clmn(Colors.white, Colors.grey[800], "images/aa.png",
              LinkomTexts.of(context).fils(), 60.0,
              go: "fl"),
          clmn(Colors.white, Colors.teal[800], "images/res.png",
              LinkomTexts.of(context).netw(), 60.0,
              go: "nett"),
          clmn(Colors.white, Colors.deepPurple[800], "images/mes.png",
              LinkomTexts.of(context).messg(), 60.0,
              go: "mes"),
          clmn(Colors.white, Colors.blue[800], "images/usere.png",
              LinkomTexts.of(context).profile(), 60.0,
              go: "gerer"),
          clmn(Colors.white, Colors.purple[600], "images/pub.png",
              LinkomTexts.of(context).pres(), 60.0,
              go: "net"),
          clmn(Colors.white, Colors.cyan[800], "images/icons/appointment.png",
              LinkomTexts.of(context).agenda(), 60.0,
              go: "parc"),
          clmn(Colors.white, Colors.yellow[700], "images/pp.png",
              LinkomTexts.of(context).publi(), 20.0,
              go: "pub"),
          clmn(Colors.white, Colors.orange[800], "images/icons/serv.png",
              LinkomTexts.of(context).prodss(), 40.0,
              go: "prod"),
          clmn(Colors.white, Colors.indigo, "images/icons/opportunity.png",
              LinkomTexts.of(context).oppo(), 20.0,
              go: "pro"),
          clmn(Colors.white, Colors.indigoAccent[700], "images/icons/video.png",
              LinkomTexts.of(context).vids(), 0.0,
              go: "bt"),
          clmn(Colors.white, Colors.red[900], "images/sale.png",
              LinkomTexts.of(context).tarifs(), 20.0,
              go: "con"),
          clmn(Colors.white, Colors.black26, "images/mic.png",
              LinkomTexts.of(context).ava(), 20.0,
              go: "av"),
          clmn(Colors.white, Colors.green[900], "images/ad.png",
              LinkomTexts.of(context).ann(), 20.0,
              go: "ad"),
          clmn(Colors.white, Colors.brown[600], "images/pi.png",
              LinkomTexts.of(context).cartem(), 0.0,
              go: "map"),
        ]);
  }


/**
 *
 * Map code end
 */
}
