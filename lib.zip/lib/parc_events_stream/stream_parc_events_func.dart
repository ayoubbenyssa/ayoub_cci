import 'dart:convert';

import 'package:medz/func/parsefunc.dart';
import 'package:medz/models/annonces.dart';
import 'package:medz/models/commission.dart';
import 'package:medz/models/conversation_g.dart';
import 'package:medz/models/favorite.dart';
import 'package:medz/models/offers.dart';
import 'package:medz/models/partner.dart';
import 'package:medz/models/revue.dart';
import 'package:medz/models/user.dart';
import 'package:medz/models/video.dart';
import 'package:medz/services/search_apis.dart';
import 'package:youtube_api/youtube_api.dart';

class StreamPostsFunctions {
  ParseServer parseFunctions = new ParseServer();

  YoutubeAPI ytApi = new YoutubeAPI(key, maxResults: 20);
  List<YT_API> ytResult = [];

  static String key = "AIzaSyBP-USv93bW62QGsFja7AALATGwv1WzWpQ";

  callAPI(skip) async {
    print('UI callled');

    print(skip);
    print("ndndndn");

    var res;
    // if (skip == 0)

    print(66666);
    print('AIzaSyDI51TS3pNwxFzlFgM3XKnIHmGog1v3kCk');

    res = await ytApi.channel(
        "UCZd6KbdnDNzyG2JJMTJNLRA", "AIzaSyDI51TS3pNwxFzlFgM3XKnIHmGog1v3kCk");
    //else*/
    //res = await ytApi.nextPage();

    print(res[0]);
    return {"results": res, "count": 1267};
  }

  urlpost(
      User user,
      String category,
      String type,
      String sector,
      skip,
      dep,
      dest,
      da,
      user_cov_id,
      cat,
      boutique,
      favorite,
      search,
      entreprise,
      suivis,
      search_posts,
      search_type,
      idp,
      type_promo,
      sector_promo,
      search_entreprise,
      type_groupe,
      verify,
      user_stream) async {
    var url = '';
    int number = DateTime.now().millisecondsSinceEpoch;

    if (favorite == true) {
      String id = user.id;
      url +=
          '"author":{"\$inQuery":{"where":{"objectId":"$id"},"className":"users"}}';
      return 'save_fav?limit=20&skip=$skip&count=1&where={$url}&include=post';
    } else if (boutique == true && category == "Tous les produits") {
      url += '"type":"boutique"';
      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=partner&order=-createdDate';
    } else if (boutique == true && category != "") {
      url += '"type":"boutique","sector":"$category"';
      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=partner&order=-createdDate';
    } else if (category != "" &&
        category != null &&
        category == "cov" &&
        dep.toString() != "null" &&
        dep != "") {
      url +=
          '"type":"${category.toLowerCase()}","depart":"$dep","idp":"$idp","destination":{"\$regex": "$dest"},"time_dep":"$da","raja":true';
      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=author&order=-boostn';
    } else if (category != "" &&
        category != null &&
        category == "cov" &&
        user_cov_id.toString() != "null" &&
        user_cov_id.toString() != "") {
      url +=
          '"type":"${category.toLowerCase()}","idp":"$idp","author":{"\$inQuery":{"where":{"objectId":"$user_cov_id"},"className":"users"}}';
      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=author&order=-createdAt';
    } else if (category != "" && category != null && category == "cov") {
      url += '"type":"${category.toLowerCase()}","raja":true,"idp":"$idp"';

      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=author&order=-boostn';
    } else if (category == "promotion") {
      if (sector_promo != null && sector_promo != "")
        url +=
            '"type":"${category.toLowerCase()}","type_promo":"$type_promo","sector_":{"\$inQuery":{"where":{"name":"$sector_promo"},"className":"sectors_convention"}}';
      else //"type":"${category.toLowerCase()}",
        url += '"type_promo":"$type_promo"';

      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=partner&order=-createdDate&include=sector_';
    } else if (category != "" &&
        category != null &&
        category == "opportunite") {
      if (sector == "") {
        if (cat != "" && cat.toString() != "null") {
          url +=
              '"type":"${category.toLowerCase()}","startDate":{"\$lte":$number},"partner":{"\$inQuery":{"where":{"objectId":"$cat"},"className":"partners"}}';
        } else
          url +=
              '"type":"${category.toLowerCase()}","startDate":{"\$lte":$number}';
      } else {
        url +=
            '"type_op":"$sector","type":"${category.toLowerCase()}","startDate":{"\$lte":$number}';
      }

      var a, sk;

      if (verify != "1") {
        a = 2;
        sk = skip;
      } else {
        a = 20;
        sk = 0;
      }

      return 'offers?limit=$a&skip=$sk&count=1&where={$url}&include=partner&order=-createdDate';
    } else if (search_posts != "" && search_posts.toString() != "null") {
      print("-----------------------------------------------");
      print(search_posts);
      var resultsearch = await SearchApis.searchposts_posts(search_posts);

      var wherecondition = '"objectId":{"\$in":$resultsearch}';

      return 'offers?limit=20&skip=$skip&count=1&where={$wherecondition,"type":"$search_type"}&include=partner';
    } else if (category != "" &&
        category != null &&
        category == "opportunite") {
      var kkey = user.communitykey;

      url +=
          '"type":"${category}","communitiesKey":"$kkey","startDate":{"\$lte":$number}';

      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=partner&order=-createdDate';
    } else if (category != "" && category != null) {
      var key = user.communitykey;

      int number = DateTime.now().millisecondsSinceEpoch;

      if (category == "event") {
        if (cat != "" &&
            cat.toString() != "null" &&
            suivis.toString() != "null" &&
            suivis == true) {
          String myid = user.id;
          url +=

              ///,"startDate":{"\$lte":$number},"endDate": {"\$gte": $number}
              '"type":"${category.toLowerCase()}","partner": {"\$inQuery": {"where": {"objectId":  {"\$select":{"query":{"className":"likepartner","where":{"idUser":"$myid"}},"key":"iden"}}     },"className": "partners"}}';

          //"objectId":{"\$select":{"query":{"className":"likepartner","where":{"iden":"$cat"}}}}';
        } else if (cat != "" && cat.toString() != "null") {
          url +=
              '"type":"${category.toLowerCase()}","startDate":{"\$lte":$number},"endDate": {"\$gte": $number},"partner":{"\$inQuery":{"where":{"objectId":"$cat"},"className":"partners"}}';
        } else
          url += '"type":"${category.toLowerCase()}"';
      } else if (category == "prod_service") {
        if (cat != "" &&
            cat.toString() != "null" &&
            suivis.toString() != "null" &&
            suivis == true) {
          String myid = user.id;
          url +=
              '"type":"${category.toLowerCase()}","endDate": {"\$gte": $number},"startDate":{"\$lte":$number}, "partner": {"\$inQuery": {"where": {"objectId":  {"\$select":{"query":{"className":"likepartner","where":{"idUser":"$myid"}},"key":"iden"}}     },"className": "partners"}}';

          //"objectId":{"\$select":{"query":{"className":"likepartner","where":{"iden":"$cat"}}}}';
        } else if (cat != "" && cat.toString() != "null") {
          url +=
              '"type":"${category.toLowerCase()}","partner":{"\$inQuery":{"where":{"objectId":"$cat"},"className":"partners"}}';
        } else
          url += '"type":"${category.toLowerCase()}"';
      } else if (category == "news") {
        if (cat != "" &&
            cat.toString() != "null" &&
            suivis.toString() != "null" &&
            suivis == true) {
          String myid = user.id;
          url +=
              '"type":"${category.toLowerCase()}", "partner": {"\$inQuery": {"where": {"objectId":  {"\$select":{"query":{"className":"likepartner","where":{"idUser":"$myid"}},"key":"iden"}}     },"className": "partners"}}';

          //"objectId":{"\$select":{"query":{"className":"likepartner","where":{"iden":"$cat"}}}}';
        } else if (cat != "" && cat.toString() != "null") {
          url +=
              '"type":"${category.toLowerCase()}","partner":{"\$inQuery":{"where":{"objectId":"$cat"},"className":"partners"}}';
        } else
          url += '"type":"${category.toLowerCase()}"';
      } else if (category == "news") {
        if (cat != "" &&
            cat.toString() != "null" &&
            suivis.toString() != "null" &&
            suivis == true) {
          String myid = user.id;
          url +=
              '"type":"${category.toLowerCase()}", "partner": {"\$inQuery": {"where": {"objectId":  {"\$select":{"query":{"className":"likepartner","where":{"idUser":"$myid"}},"key":"iden"}}     },"className": "partners"}}';

          //"objectId":{"\$select":{"query":{"className":"likepartner","where":{"iden":"$cat"}}}}';
        } else if (cat != "" && cat.toString() != "null") {
          url +=
              '"type":"${category.toLowerCase()}","partner":{"\$inQuery":{"where":{"objectId":"$cat"},"className":"partners"}}';
        } else
          url += '"type":"${category.toLowerCase()}"';
      } else
        url += '"type":"${category.toLowerCase()}"';

      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=partner&order=-sponsorise&order=-createdDate';
    } else if (type == "an" && user_cov_id.toString() != "null") {
      var qu = [
        {"type": "$user_cov_id"},
      ];

      String iduser = user.id;

      var url = jsonEncode({
        "\$or": qu,
        "author": {
          "\$inQuery": {
            "where": {"objectId": "$iduser"},
            "className": "users"
          }
        },
        "active": 1
      });
      return 'offers?limit=20&skip=$skip&count=1&where=$url&include=author&order=-sponsorise';
    } else if (type != "" && type != null) {
      url += '"type":"${type}","active":1,"raja":true';
      return 'offers?limit=20&skip=$skip&count=1&where={$url}&include=author&order=-boostn&include=partner';
    }
  }

  /*
  "partner":{"\$inQuery":{"where":{"order_partner":{"\$lte":0}},"className":"partners"}}
   */

  /*
   var genre;
  var type_groupe;
  var tpe_group;
   */
  fetchposts(User user, active,
      {String category = "",
      idpost,
      filter,
      revue,
      video,
      String type = "",
      int skip = 0,
      search_entreprise,
      var entreprise,
      partner_id,
      member,
      idp,
      suivis = false,
      sector,
      dep,
      dest,
      genre,
      type_groupe,
      tpe_group,
      da,
      user_cov_id,
      sector_promo,
      cat,
      search,
      boutique,
      type_promo,
      search_posts,
      search_type,
      favorite,
      user_stream,
        obj,
      lat,
      lng}) async {
    var url = "";
    String ur = "";

    if (user_stream.toString() != "null" && user_stream == "users") {
      String id = user.auth_id;
      String my_id = user.id;

      print(filter);

      if (filter == "proche") {
        /***
         * ,"id1":{"\$dontSelect":{"query":{"className":"block","where":{"userS":{"\$eq":"$id"}}},"key":"blockedS"}},'
            '"idblock":{"\$dontSelect":{"query":{"className":"block","where":{"blockedS":{"\$eq":"$id"}}},"key":"userS"}},'
            '"objectId":{"\$dontSelect":{"query":{"className":"connect","where":{"send_requ":{"\$eq":"$my_id"}}},"key":"receive_req"}}'
            '
         */

        print("----77777777---");
        print(lat);
        if (lat.toString() == "null") {
          ur = //"medz":true,
              'where={"raja":true,"active":1}&limit=20&skip=$skip&include=entreprise&include=respons&include=commissions&include=fed&count=1';
        } else {
          ur = //"medz":true,
              'where={"location": {"\$nearSphere": {"__type": "GeoPoint","latitude": $lat,"longitude":$lng}},"raja":true,"active":1}&limit=20&skip=$skip&include=entreprise&include=respons&include=commissions&include=fed';
        }
      } else if (filter == "new") {
        ur = //"medz":true,
            'where={"raja":true,"active":1}&limit=20&skip=$skip&include=respons&include=entreprise&include=commissions&include=fed&count=1&order=-createdAt';
      } else if (filter == "old") {
        ur = //"medz":true,
            'where={"raja":true,"active":1}&limit=20&skip=$skip&include=respons&include=entreprise&include=commissions&include=fed&count=1&order=createdAt';
      } else if (filter == "last") {
        ur = //"medz":true,
            'where={"raja":true,"active":1}&limit=20&skip=$skip&include=respons&include=entreprise&include=commissions&include=fed&count=1&order=-updatedAt';
      }
      else if (filter == "objectifs") {
        ur = //"medz":true,
        'where={"raja":true,"active":1,"objectif":"$obj"}&limit=20&skip=$skip&include=respons&include=entreprise&include=commissions&include=fed&count=1&order=-updatedAt';
      }
      url = "users?" + ur;

      print(ur);
    } else if (user_stream.toString() != "null" &&
        user_stream == "entreprise") {
      String id = user.auth_id;
      String my_id = user.id;

      url = 'partners?where={"active":1}&order=-createdAt&count=1';
    }
    else if (user_stream.toString() != "null" &&
        user_stream == "commission") {
      String id = user.auth_id;
      String my_id = user.id;

      url = 'commissions?order=name';
    }

    else if (user_stream.toString() != "null" &&
        user_stream == "federation") {
      String id = user.auth_id;
      String my_id = user.id;

      url = 'federation?order=name';
    }
    else if (type_groupe.toString() != "null" &&
        type_groupe.toString() != "") {
      String ii = user.id;
      var com = type_groupe;

      if (genre == "commission")
        url =
            'conversation_g?limit=20&skip=$skip&count=1&include=authors&include=demandes&order=-last_time&where={"disactivate":false,"commission_id":"$com","type_group":"$tpe_group","type":"commission"}';
      else
        url =
            'conversation_g?limit=20&skip=$skip&count=1&include=authors&include=demandes&order=-last_time&where={"disactivate":false,"federation_id":"$com","type_group":"$tpe_group","type":"federation"}';
    } else if (type == "sondage") {
      String ii = user.id;
      String tt = genre;
      url =
          'offers?limit=20&skip=$skip&count=1&where={"type":"sondage","author":{"\$inQuery":{"where":{"objectId":"$ii"},"className":"users"}}}&include=author&order=-createdAt&include=options&include=options.users';
    } else if (revue != false && revue != null) {
      url = 'revue?limit=20&skip=$skip&count=1&order=-createdAt';
    } else if (video != false && video != null) {
      url = 'videos?limit=20&skip=$skip&count=1';
    } else if (idpost != "" && idpost != null) {
      url =
          'participate?limit=20&include=author&skip=$skip&count=1&where={"post":{"\$inQuery":{"where":{"objectId":"$idpost"},"className":"offers"}}}';
    } else if (member != "" && member != null) {
      url =
          'users?limit=20&skip=$skip&count=1&where={"entreprise":{"\$inQuery":{"where":{"objectId":"$member"},"className":"partners"}},"active":1}&include=fed&include=commissions';
    } else if (search_entreprise != "" && search_entreprise != null) {
      var resultsearch = await SearchApis.searchentreprise(search_entreprise);

      var wherecondition = '"objectId":{"\$in":$resultsearch}';

      url =
          'partners?limit=20&skip=$skip&count=1&where={$wherecondition,"active":1,"type":"entreprise"}';
    } else if (search != "" && search != null) {
      var resultsearch = await SearchApis.searchposts(search);

      var wherecondition = '"objectId":{"\$in":$resultsearch}';

      url =
          'users?limit=20&skip=$skip&count=1&where={$wherecondition,"raja":true,"active":1}';
    } else if (entreprise.toString() != "[]" &&
        entreprise.toString() != "null") {
      url =
          'partners?limit=3500&skip=$skip&count=1&where={"active":1}&order=-createdAt';
    } else {
      url = await urlpost(
          user,
          category,
          type,
          sector,
          skip,
          dep,
          dest,
          da,
          user_cov_id,
          cat,
          boutique,
          favorite,
          search,
          entreprise,
          suivis,
          search_posts,
          search_type,
          idp,
          type_promo,
          sector_promo,
          search_entreprise,
          type_groupe,
          active,
          user_stream);
    }

    /*


    */
    var results;

    if (revue != false && revue != null) {
      results = await parseFunctions.getparse(url + "&order=createdAt");
    } else if (user_stream.toString() != "null" && user_stream == "users") {
      results = await parseFunctions.getparse(url);
    }

    else if (video != false && video != null) {
      results = await callAPI(skip);
    } else {
      results = await parseFunctions.getparse(url + "&order=-createdAt");
    }
    return data(
        category,
        type,
        results,
        favorite,
        search,
        entreprise,
        member,
        idpost,
        video,
        revue,
        search_entreprise,
        type_groupe,
        active,
        user_stream,
        filter);
  }

  data(category, type, results, favorite, search, entreprise, member, idpost,
      video, revue, search_entreprise, type_groupe, active, user_stream, filter
      /*report, likes, favorite*/) {
    if (results == "nointernet") return "nointernet";
    if (results == "error") return "error";
    if (results["count"] == 0) return "empty";
    if (results["results"].length > 0) {
      List postsItems = results['results'];

      if (user_stream.toString() != "null" && user_stream == "users") {
        if (filter == "proche") {
          return {
            'results': postsItems.map((raw) => new User.fromMap(raw)).toList(),
            'count': 10000
          };
        }
        return {
          'results': postsItems.map((raw) => new User.fromMap(raw)).toList(),
          'count': results['count']
        };
      } else if (user_stream.toString() != "null" &&
          user_stream == "entreprise") {
        return {
          'results': postsItems.map((raw) => new Partner.fromMap(raw)).toList(),
          'count': results['count']
        };
      }

      else if (
          user_stream == "commission"  ||   user_stream == "federation") {
        return {
          'results': postsItems.map((raw) => new Commission.fromDoc(raw)).toList(),
          'count': results['count']
        };
      }
      else if (type_groupe != false && type_groupe != null) {
        return {
          'results':
              postsItems.map((raw) => new Conversationg.fromMap(raw)).toList(),
          'count': results['count']
        };
      } else if (revue != false && revue != null) {
        return {
          'results': postsItems.map((raw) => new Revue.fromMap(raw)).toList(),
          'count': results['count']
        };
      } else if (search_entreprise != null) {
        return {
          'results': postsItems.map((raw) => new Partner.fromMap(raw)).toList(),
          'count': results['count']
        };
      } else if (video != false && video != null) {
        return {'results': postsItems, 'count': 1267};
      } else if (idpost != "" && idpost != null) {
        return {
          'results':
              postsItems.map((raw) => new User.fromMap(raw["author"])).toList(),
          'count': results['count']
        };
      } else if (member != "" && member != null) {
        return {
          'results': postsItems.map((raw) => new User.fromMap(raw)).toList(),
          'count': results['count']
        };
      }
      if (search != "" && search != null) {
        return {
          'results': postsItems.map((raw) => new User.fromMap(raw)).toList(),
          'count': results['count']
        };
      }
      if (favorite == true) {
        return {
          'results':
              postsItems.map((raw) => new Favorite.fromMap(raw)).toList(),
          'count': results['count']
        };
      } else if (category != "" && category != null) {
        return {
          'results': postsItems.map((raw) => new Offers.fromMap(raw)).toList(),
          'count': results['count']
        };
      } else if (entreprise.toString() != "[]" &&
          entreprise.toString() != 'null') {
        return {
          'results': postsItems.map((raw) => new Partner.fromMap(raw)).toList(),
          'count': results['count']
        };
      } else if (type != "" && type != null) {
        if (type == "Annonces" && active != "1") {
          return {
            'results':
                postsItems.map((raw) => new Offers.fromMap(raw)).toList(),
            'count': results['count']
          };
        } else
          return {
            'results':
                postsItems.map((raw) => new Offers.fromMap(raw)).toList(),
            'count': results['count']
          };
      } else {
        return {
          'results': postsItems.map((raw) => new Offers.fromMap(raw)).toList(),
          'count': results['count']
        };
      }
    }
    return "nomoreresults";
  }
}
