
import 'package:flutter/material.dart';
import 'package:medz/co_voiturage/rating.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/widgets/common.dart';


class AlertRate{


  static dialog(context, name, photo, id, user,rating,offer_id,count,context1,{my_id,id_other}) async {
    return await showDialog<List>(
      barrierDismissible: false,
        context: context,
        child: new AlertDialog(
          content: new Container(
            width: 260.0,
            height: 260.0,
            decoration: new BoxDecoration(
              shape: BoxShape.rectangle,
              color: const Color(0xFFFFFF),
              borderRadius: new BorderRadius.all(new Radius.circular(32.0)),
            ),
            child: new Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Text(
                  "Evaluer:  ",
                  style: new TextStyle(
                    color: Fonts.col_app,
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                new Container(height: 12.0),
                new Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      new ClipOval(
                          child: new Container(
                              color: Colors.grey[300],
                              width: 80.0,
                              height: 80.0,
                              child: new FadingImage.network(photo,
                                  fit: BoxFit.cover)))
                    ]),
                new Container(height: 4.0),
                new Text(
                  name,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                  ),
                  textAlign: TextAlign.center,
                ),

                // dialog centre
                new Expanded(
                  child: new Rating(my_id,id_other,rating,offer_id,context1,count),
                  flex: 1,
                ),
                new Container(height: 12.0),

              ],
            ),
          ),
        ));
  }





  static dialog2(context, name, photo,rating,offer_id,count,context1,{my_id,id_other}) async {
    return await showDialog<List>(
        barrierDismissible: false,
        context: context,
        child: new AlertDialog(
          content: new Container(
            width: 260.0,
            height: MediaQuery.of(context).size.height*0.65,
            decoration: new BoxDecoration(
              shape: BoxShape.rectangle,
              color: const Color(0xFFFFFF),
              borderRadius: new BorderRadius.all(new Radius.circular(32.0)),
            ),
            child: new Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Text(
                  "Evaluer:  ",
                  style: new TextStyle(
                    color: Fonts.col_app,
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                new Container(height: 16.0),
                new Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      new ClipRect(
                          child: new Container(
                              color: Colors.grey[300],
                              width: 80.0,
                              height: 80.0,
                              child: new FadingImage.network(photo,
                                  fit: BoxFit.cover)))
                    ]),

                new Container(height: 4.0),
                new Text(
                  name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                  ),
                  textAlign: TextAlign.center,
                ),
                new Container(height: 16.0),

                // dialog centre
                new Expanded(
                  child: new Rating(my_id,id_other,rating,offer_id,context1,count),
                ),
                new Container(height: 12.0),

              ],
            ),
          ),
        ));
  }




}