import 'package:flutter/material.dart';
import 'package:medz/co_voiturage/serach_result_co.dart';
import 'package:medz/func/parsefunc.dart';
import 'package:medz/language_params/linkom_texts.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/validators.dart';
import 'package:medz/widgets/widgets.dart';

class SearchForm extends StatefulWidget {
  SearchForm(this.user, this.auth, this.sign, this.lat, this.lng,this.analytics,this.list_partner);

  User user;
  var auth;
  var sign;
  var lat;
  var lng;
  var analytics;
  List list_partner;

  @override
  _SearchFormState createState() => _SearchFormState();
}

class _SearchFormState extends State<SearchForm> {
  String ta = "";

  var error = "";
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  bool _autovalidate = false;
  final depctrl = new TextEditingController();
  FocusNode depfocus = new FocusNode();

  final destctrl = new TextEditingController();
  FocusNode destfocus = new FocusNode();

  String da = "";

  confirm() async {
    final FormState form = _formKey.currentState;
    if (!form.validate()) {
      _autovalidate = true; // Start validating on every change.
    } else if (da == "") {
      setState(() {
        error = "Choisir la date de départ";
      });
    } else {

    }
  }

  @override
  Widget build(BuildContext context) {
    Validators val = new Validators(context: context);
    var style = new TextStyle(
        color: const Color(0xffeff2f7),
        fontSize: 14.0,
        fontWeight: FontWeight.w600);

    Widget dep = Widgets.textfield_dec(
        "Départ", depfocus, "", depctrl, TextInputType.text, val.titrre);

    Widget dest = Widgets.textfield_dec(
        "Destination", destfocus, "", destctrl, TextInputType.text, val.titrre);

    showd() async {
      var a = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime.now().subtract(new Duration(days: 30)),
        lastDate: new DateTime.now().add(new Duration(days: 30)),
      );

      setState(() {
        da = a.toString().split(" ")[0];
        error = "";
      });
    }

    Widget date_d = new InkWell(
      child: new Column(
        children: <Widget>[
          new Row(
            children: <Widget>[
              new Container(
                width: 8.0,
              ),
              new Text(
                "Date de départ:",
                style: new TextStyle(color: Colors.grey[600]),
              ),
              new Container(
                width: 12.0,
              ),
              new Text(da == "" ? "" : da),
              new Expanded(child: new Container()),
              new Icon(Icons.arrow_drop_down)
            ],
          ),
          new Container(height: 12.0),
          new Container(
            height: 1.2,
            width: 1000.0,
            color: Colors.grey,
          )
        ],
      ),
      onTap: () {
        showd();
      },
    );

    Widget btn_log = new Container(
        height: 40.0,
        padding: new EdgeInsets.only(left: 6.0, right: 6.0),
        child: new Material(
            elevation: 2.0,
            shadowColor: Fonts.col_app_fon,
            borderRadius: new BorderRadius.circular(4.0),
            color: Fonts.col_app,

            /*decoration: new BoxDecoration(
            border: new Border.all(color: const Color(0xffeff2f7), width: 1.5),
            borderRadius: new BorderRadius.circular(6.0)),*/
            child: new MaterialButton(
                // color:  const Color(0xffa3bbf1),
                onPressed: () {
                  confirm();
                },
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new Container(
                      width: 8.0,
                    ),
                    //  new Container(height: 36.0,color: Colors.white,width: 1.5,),
                    new Container(
                      width: 8.0,
                    ),
                    new Text(LinkomTexts.of(context).search(), style: style)
                  ],
                ))));

    return Scaffold(
      key: _scaffoldKey,
      appBar: new AppBar(),
      body: new Form(
          key: _formKey,
          autovalidate: _autovalidate,
          //onWillPop: _warnUserAboutInvalidData,
          child: new Column(children: <Widget>[
            new Expanded(
              child: new ListView(
                padding: new EdgeInsets.all(6.0),
                children: <Widget>[
                  new Container(height: 16.0),
                  dep,
                  new Container(height: 20.0),
                  dest,
                  new Container(height: 32.0),
                  date_d,
                  new Container(height: 20.0),
                  new Center(
                    child: new Text(
                      error,
                      style: new TextStyle(
                          color: Colors.red[900], fontWeight: FontWeight.bold),
                    ),
                  ),
                  new Container(height: 16.0),
                  btn_log
                ],
              ),
            )
          ])),
    );
  }
}
