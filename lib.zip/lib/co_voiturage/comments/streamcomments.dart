import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:medz/co_voiturage/comments/comment_widget.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/Fonts.dart';
import 'package:medz/services/commentsfunctions.dart';
import 'package:medz/services/streamcommentsfunctions.dart';
import 'package:medz/widgets/widgets.dart';



class StreamComments extends StatefulWidget {
  StreamComments(
      {this.widgetheader,
        this.scrollController,
        this.idpost,
        this.idcurrent,
        this.addcomments,
        Key key})
      : super(key: key);
  Widget widgetheader = new Container();
  ScrollController scrollController;
  String idpost;
  String idcurrent;
  bool addcomments = false;
  @override
  _StreamCommentsState createState() => new _StreamCommentsState();
}

class _StreamCommentsState extends State<StreamComments> {
  StreamCommentsFunctions streamComments = new StreamCommentsFunctions();
  CommentFunctions commentFunctions = new CommentFunctions();
  SliverPersistentHeaderDelegate delegate;
  List listWidget = new List();
  bool isLoading = true;
  var skip = 0;
  var skip2 = 0;
  var count = 0;
  var count2 = 0;
  var created = "";
  var nomore = "";
  var errorWithYourRequest = "";
  var noresultfound = "";
  bool getmore = false;

  getdata() async {
    try {
      setState(() => widget.addcomments = false);
    } catch (e) {}
    widget.scrollController.addListener(() {
      if (count2 < count) streampost();
    });
    streampost();
  }

  getrefresh() {
    setState(() {
      isLoading = true;
      listWidget = new List();
      skip = 0;
      count = 0;
      count2 = 0;
      nomore = "";
      errorWithYourRequest = "";
      noresultfound = "";
    });
    streampost();
    final Completer<Null> completer = new Completer<Null>();
    new Timer(const Duration(seconds: 2), () => completer.complete(null));
    return completer.future.then((_) {});
  }

  streampost() async {
    var result = await streamComments.fetchcomments(
        skip: skip, created: created, idPost: widget.idpost);
    try {
      setState(() => isLoading = false);
    } catch (e) {}
    fetchresult(result);
  }

  fetchresult(result) {
    if (result == "nointernet")
      errorrequest("nointernet");
    else if (result == "error")
      errorrequest("error");
    else if (result == "empty")
      noresult();
    else if (result == "nomoreresults")
      nomorepost();
    else
      showwidgets(result);
  }

  errorrequest(text) {
    try {
      setState(() => errorWithYourRequest =
      "there's an error with your request please try again");
      if (text == "nointernet")
        setState(() => errorWithYourRequest =
        "there's an error with your internet connection, please verifie it and try again");
    } catch (e) {}
  }

  noresult() {
    try {
      // setState(() => noresultfound = WupeeStrings.of(context).nocommentsfound());
    } catch (e) {}
  }

  List l = new List();
  showwidgets(result) {

    try {
      if (skip == 0) setState(() => count = result["count"]);
    } catch (e) {}
    if (result["results"].length != 0) {
      for (var comment in result["results"]) {
        try {
          setState(() => count2++);
        } catch (e) {}
        // if(l.contains(!comment.id))

        listWidget.add(new GestureDetector(
            child: new CommentsWidget(
                comment, new User.fromMap(comment.author1), widget.idcurrent),
            onLongPress: () {
              displaybottomsheet(comment.text, comment.id, comment.idUser,
                  widget.idcurrent, comment.idPost);
            }));
        l.add(comment.id);
      }
      try {
        if (result["results"].length < 20) {
          setState(() => skip += result["results"].length);
        } else
          setState(() => skip += 20);
      } catch (e) {}
    }
    if (count2 >= count) {
      nomorepost();
    }
  }

  nomorepost() {
    try {
      // setState(() => nomore = WupeeStrings.of(context).nomorocomments());
    } catch (e) {}
  }

  @override
  initState() {
    super.initState();
    getdata();
  }

  displaybottomsheet(text, idcomment, idauthor, idcurrent, idpost) async {
    Widget copywidget = new FlatButton(
        onPressed: () {
          Clipboard.setData(new ClipboardData(text: text));
          Navigator.of(context).pop(true);
          Scaffold
              .of(context)
              .showSnackBar(new SnackBar(content: new Text("copié")));
        },
        child: new Row(children: <Widget>[
          new Icon(Icons.content_copy, color: Fonts.col_app),
          new Text("Copy", style: new TextStyle(color: Fonts.col_app))
        ]));
    Widget editwidget = idcurrent == idauthor
        ? new FlatButton(
        onPressed: () {
          Navigator.of(context).pop(true);
        },
        child: new Row(children: <Widget>[
          new Icon(Icons.border_color, color: Fonts.col_app),
          new Text("Edit",
              style: new TextStyle(color: Fonts.col_app))
        ]))
        : new Container();
    Widget deletewidget = idcurrent == idauthor
        ? new FlatButton(
        onPressed: () {
          commentFunctions.deletecomment(idcomment, idpost, idauthor);
          Navigator.of(context).pop(true);
        },
        child: new Row(children: <Widget>[
          new Icon(Icons.delete_forever, color:Fonts.col_app),
          new Text("Delete",
              style: new TextStyle(color: Fonts.col_app))
        ]))
        : new Container();
    showModalBottomSheet<Null>(
        context: context,
        builder: (BuildContext context) {
          return new Container(
              height: 50.0,
              child: new Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: new Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        copywidget,
                        editwidget,
                        deletewidget
                      ])));
        });
  }

  loadingwidget() {
    return new SliverToBoxAdapter(
        child:  Widgets.load(),);
  }

  bottomwidget() {
    if (errorWithYourRequest != "")
      return new Container();
    else if (nomore != "")
      return new Container();
    else if (noresultfound != "")
      return new Center(
          child: new Container(
              padding: const EdgeInsets.only(
                  top: 45.0, left: 16.0, right: 16.0, bottom: 16.0),
              child: new Text(noresultfound,
                  style: new TextStyle(fontSize: 16.0))));
  }

  @override
  Widget build(BuildContext context) {
    if (widget.addcomments) getdata();
    Widget buildBody(BuildContext context) {
      Widget bottom = bottomwidget();
      Widget listposts = new SliverList(
          delegate:
          new SliverChildListDelegate(new List<Widget>.from(listWidget)));
      Widget scrollview =
      new CustomScrollView(controller: widget.scrollController, slivers: [
        new SliverToBoxAdapter(child: widget.widgetheader),
        isLoading ? loadingwidget() : listposts,
        new SliverToBoxAdapter(child: isLoading ? new Container() : bottom)
      ]);
      return new RefreshIndicator(
          displacement: 65.0, onRefresh: ()=>getrefresh(), child: scrollview);
      // return scrollview;
    }

    return new Builder(builder: buildBody);
  }
}
