import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
//import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'package:flutter/material.dart';


import 'package:timeago/timeago.dart' as ta;
import 'package:medz/models/comment.dart';
import 'package:medz/models/user.dart';
import 'package:medz/services/app_services.dart';
import 'package:medz/services/commentsfunctions.dart';



class CommentsWidget extends StatefulWidget {
  CommentsWidget(this.comment, this.user, this.idcurrent, {Key key})
      : super(key: key);
   Comment comment;
   User user;
  var idcurrent;

  @override
  _CommentsWidgetState createState() => new _CommentsWidgetState();
}

class _CommentsWidgetState extends State<CommentsWidget> {
  CommentFunctions commentFunctions = new CommentFunctions();

  Future<Null> _launch(String url) async {
    /*  if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }*/
  }

  TapGestureRecognizer gourl(item) {
    var tap = new TapGestureRecognizer()
      ..onTap = () {
        _launch(item);
      };
    return tap;
  }



  Widget build(BuildContext context) {
    List<TextSpan> texts = new List<TextSpan>();
    var text = widget.comment.text.split(" ");

    Widget photouser = new ClipOval(
        child: new Image.network(widget.user.image.toString(),
            fit: BoxFit.cover, width: 32.0, height: 32.0));
    Widget avatar =  new GestureDetector(
        onTap: ()=> null,//routesFunctions.gotoparams2("profile", context, widget.user,widget.user.objectId),
        child: new Container(
            margin: const EdgeInsets.only(right: 8.0),
            child:photouser)) ;

    TextSpan returnurl(text) {
      return new TextSpan(
        style: new TextStyle(color: Colors.black87),
        recognizer: gourl(text),
        text: text + " ",
        // style: styleapp.styleurlhash()
      );
    }

    /* TextSpan returnhashtag(text) {
      return new TextSpan(
          recognizer: gohashtag(text.substring(1, text.length)),
          text: text + " ",
          style: styleapp.styleurlhash());
    }*/

    TextSpan returntext(text) {
      return new TextSpan(text: text + " ", style: new TextStyle(color: Colors.black87,fontSize: 16.0),);
    }

    for (int i = 0; i < text.length; i++) {
      if (AppServices.matchUrl(text[i]) == true) {
        texts.add(returnurl(text[i]));
      } else if (text[i].contains("#")) {
        //texts.add(returnhashtag(text[i]));
      } else {
        texts.add(returntext(text[i]));
      }
    }

    Widget textwidget = new Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        mainAxisSize: MainAxisSize.max,
        children: [new RichText(text: new TextSpan(children: texts))]);

    Widget username =
    new Text(widget.user.firstname.toString()+" "+widget.user.fullname.toString(),style: new TextStyle(fontSize: 13.0,color: Colors.grey[800],fontWeight: FontWeight.w900),/* style: styleapp.styleusername1()*/);

    Widget timecomment = new Text(ta.format(widget.comment.createdat),
        style: new TextStyle(fontSize: 10.0,color: Colors.grey[600],fontWeight: FontWeight.w700)
      /*style: styleapp.styletime()*/);

    return new Container(
        padding: new EdgeInsets.all(2.0),
        margin: new EdgeInsets.all(2.0),
        child: new Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              new Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    avatar,
                    new Container(
                        padding: new EdgeInsets.all(1.0),
                        child: new Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [new Container(height: 2.0,),username, new Container(height: 2.0,),timecomment]))
                  ]),
              new Container(
                  padding: new EdgeInsets.only(
                      top: 4.0, bottom: 4.0, left: 42.0),
                  child: textwidget)
              , new Container(height: 2.0,),
              new Divider(height: 1.0,color: Colors.grey,),

            ]));
  }
}
