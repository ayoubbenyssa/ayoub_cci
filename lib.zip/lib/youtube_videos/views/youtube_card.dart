import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:intl/intl.dart';
import 'package:medz/models/user.dart';
import 'package:medz/widgets/common.dart';
import 'package:medz/youtube_videos/models/youtube_card_content.dart';
import 'package:youtube_api/youtube_api.dart';

class YoutubeCard extends StatelessWidget {
  YoutubeCard(this.user, this.content,this.chng);

  final YT_API content;
  User user;
  var chng;

  void playYoutubeVideo(text,context) {
    Navigator.push(context, new MaterialPageRoute<String>(
        builder: (BuildContext context) {
          return new WebviewScaffold(
            url: text,
            appBar: new AppBar(
              title: new Text(""),
            ),
          );
        }));
  }


  Widget build(BuildContext context) {
    return  Container(
      padding: EdgeInsets.only(bottom: 12),
      // margin: EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
      child: GestureDetector(
          onTap: (){

            print(content.url);

            if(Platform.isAndroid)
            playYoutubeVideo(content.url.replaceAll(" ", ""),context);
            else
              Navigator.push(context,
                  new MaterialPageRoute<String>(
                      builder: (BuildContext
                      context) {
                        return new WebviewScaffold(
                          url:content.url.replaceAll(" ", ""),
                          appBar: new AppBar(
                            title: new Text(""),
                          ),
                        );
                      }));

          },

          child:  Material(
        color: Color(0XFFFFFFFF),
        elevation: 5.0,
        borderRadius: BorderRadius.circular(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            //Container which video tumbnail

            Container(
              padding: EdgeInsets.only(bottom: 2.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.0),
                  child: Stack(children: <Widget>[
                  Container(
                    height: MediaQuery.of(context).size.height*0.36,
                      width: MediaQuery.of(context).size.width,
                      color: Colors.grey[200],
                      child:   FadingImage.network(
                      content.thumbnail["high"]["url"],
                      fit: BoxFit.cover,
                    )),
                    Positioned.fill(
                      child: Align(
                          alignment: Alignment.center,
                          child: Image.asset(
                            "images/thumb.png",
                            width: 54,
                          )),
                    ),
                  ])),
            ),

            //Row which contain channel tumbnail along with video information
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  //Container of Channel Tubmnail
                  Column(children: <Widget>[

                    Container(height: 10,),
                    CircleAvatar(
                      backgroundImage: NetworkImage(
                        "https://res.cloudinary.com/dgxctjlpx/image/upload/v1583616159/unnamed_hlg7e6.jpg",
                      ),
                      radius: 28,
                    ),
                  ],),
                  SizedBox(width: 12.0),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        SizedBox(height: 4.0),
                        Text(
                          content.title,
                          overflow: TextOverflow.clip,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 16.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 4.0),
                        Text(
                          content.channelTitle.toUpperCase(),
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Color(0XFF646464),
                            fontSize: 13.0,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 4.0),
                        Text(
                          content.publishedAt.toString().substring(0,10),
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Color(0XFFBBBBBB),
                            fontWeight: FontWeight.w800,
                            fontSize: 14.0,
                          ),
                        ),
                        SizedBox(height: 8.0),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      )),
    );
  }
}
